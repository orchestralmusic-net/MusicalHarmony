/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

import java.io.File;

/**
 *
 * @author Dominik Kruppa
 */
public class MyFileFilter extends javax.swing.filechooser.FileFilter {

    public boolean accept(File file) {
        return file.isDirectory() || file.getName().toLowerCase().endsWith(".har");
    }

    public String getDescription() {
        return "Súbory .har";
    }

}
