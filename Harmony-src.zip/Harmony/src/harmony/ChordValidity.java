/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public enum ChordValidity {

    VALID, OTHERCHORD, TONECROSSING, NOTAWIDEHARMONY, LEADINGTONEDOUBLED,
    LEADINGTONENOTRESOLVED, NOTCANTABILE, PARALLELEIGHTS, PARALLELFIFTHS;

    private String errMessage = "";
    private String hint = "";

    public Boolean isValid(){
        if(this==VALID){
            return true;
        }else return false;
    }

    public String getInfo(){

        switch (this){

            case VALID: return getHint();
            case OTHERCHORD: return getErrMessage();
            case TONECROSSING: return getErrMessage();
            case NOTAWIDEHARMONY: return getErrMessage();
            case LEADINGTONEDOUBLED: return getErrMessage();
            case LEADINGTONENOTRESOLVED: return getErrMessage();
            case NOTCANTABILE: return getErrMessage();
            case PARALLELEIGHTS: return getErrMessage();
            case PARALLELFIFTHS: return getErrMessage();

        }

        return "interná chyba programu 1";

    }

    /**
     * @return error message
     */
    private String getErrMessage() {
        return errMessage;
    }

    /**
     * @param error message (for other than VALID enum)
     */
    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    /**
     * @return hint
     */
    private String getHint() {
        return hint;
    }

    /**
     * @param hint (for VALID enum). Can be empty.
     */
    public void setHint(String hint) {
        this.hint = hint;
    }

}
