/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public class GroundNotSupportedException extends Exception {

    /**
     * Creates a new instance of <code>GroundNotImplementedException</code> without detail message.
     */
    public GroundNotSupportedException() {
    }


    /**
     * Constructs an instance of <code>GroundNotImplementedException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public GroundNotSupportedException(String msg) {
        super(msg);
    }
}
