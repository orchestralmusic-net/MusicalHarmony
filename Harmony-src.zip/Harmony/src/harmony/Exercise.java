/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

import java.util.List;

/**
 *
 * @author Dominik Kruppa
 */
public class Exercise {

    private String name;
    private Key key;
    private List<String> basses;
    private List<ChordType> types;

    public Exercise(String name, Key key, List<String> basses, List<ChordType> types){
        this.name = name;
        this.key = key;
        this.basses = basses;
        this.types = types;
    }

    public boolean isValid(){
        if(basses.size()!=types.size()){
            return false;
        }
        if(basses.isEmpty() || types.isEmpty()){
            return false;
        }
        if(basses.contains("")){
            return false;
        }
        if(types.contains(null)){
            return false;
        }
        return true;
    }

    /**
     * @return the name
     */
    public String getName(){
        return name;
    }

    /**
     * @return the key
     */
    public Key getKey() {
        return key;
    }

    /**
     * @return the basses
     */
    public List<String> getBasses() {
        return basses;
    }

    /**
     * @return the types of chords
     */
    public List<ChordType> getTypes() {
        return types;
    }

    /**
     * @return number of chords in the exercise
     */
    public Integer getSize() {
        return basses.size();
    }

    public void setName(String name) {
        this.name=name;
    }

    

}
