/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public class OmitErrors {

    private boolean otherChord;
    private boolean toneCrossing;
    private boolean notAWideHarmony;
    private boolean leadingToneDoubled;
    private boolean leadingToneNotResolved;
    private boolean notCantabile;
    private boolean parallelEights;
    private boolean parallelFifths;
    private boolean omitTone;

    public OmitErrors(boolean otherChord, boolean toneCrossing, boolean notAWideHarmony,
            boolean leadingToneDoubled, boolean leadingToneNotResolved, boolean notCantabile,
            boolean parallelEights, boolean parallelFifths, boolean omitTone){

        this.otherChord=otherChord;
        this.toneCrossing=toneCrossing;
        this.notAWideHarmony=notAWideHarmony;
        this.leadingToneDoubled=leadingToneDoubled;
        this.leadingToneNotResolved=leadingToneNotResolved;
        this.notCantabile=notCantabile;
        this.parallelEights=parallelEights;
        this.parallelFifths=parallelFifths;
        this.omitTone=omitTone;

    }

    public boolean otherChord(){
        return otherChord || Global.otherChord;
    }

    public boolean toneCrossing(){
        return toneCrossing || Global.toneCrossing;
    }

    public boolean notAWideHarmony(){
        return notAWideHarmony || Global.notAWideHarmony;
    }

    public boolean leadingToneDoubled(){
        return leadingToneDoubled || Global.leadingToneDoubled;
    }

    public boolean leadingToneNotResolved(){
        return leadingToneNotResolved || Global.leadingToneNotResolved;
    }
    public boolean notCantabile(){
        return notCantabile || Global.notCantabile;
    }

    public boolean parallelEights(){
        return parallelEights || Global.parallelEights;
    }

    public boolean parallelFifths(){
        return parallelFifths || Global.parallelFifths;
    }

    public boolean omitTone(){
        return omitTone || Global.omitTone;
    }

    public void allowToneOmission(){
        omitTone = true;
    }

    public void forbidToneOmission(){
        omitTone = false;
    }

    public void allowError(ChordValidity error){

        switch (error){

            case VALID: allowNoError(); return;
            case OTHERCHORD: otherChord = true; return;
            case TONECROSSING: toneCrossing = true; return;
            case NOTAWIDEHARMONY: notAWideHarmony = true; return;
            case LEADINGTONEDOUBLED: leadingToneDoubled = true; return;
            case LEADINGTONENOTRESOLVED: leadingToneNotResolved = true; return;
            case NOTCANTABILE: notCantabile = true; return;
            case PARALLELEIGHTS: parallelEights = true; return;
            case PARALLELFIFTHS: parallelFifths = true; return;

        }
    }

    public void allowNoError(){

        otherChord = false;
        toneCrossing = false;
        notAWideHarmony = false;
        leadingToneDoubled = false;
        leadingToneNotResolved = false;
        notCantabile = false;
        parallelEights = false;
        parallelFifths = false;
        omitTone = false;
    }




    public static class Global{

        private static boolean otherChord = false;
        private static boolean omitTone = false;
        private static boolean toneCrossing = false;
        private static boolean notAWideHarmony = false;
        private static boolean leadingToneDoubled = true;
        private static boolean leadingToneNotResolved = true;
        private static boolean notCantabile = true;
        private static boolean parallelEights = true;
        private static boolean parallelFifths = true;

        public static boolean otherChord() {
            return otherChord;
        }

        public static void setOtherChord(boolean aOtherChord) {
            otherChord = aOtherChord;
        }

        public static boolean toneCrossing() {
            return toneCrossing;
        }

        public static void setToneCrossing(boolean aToneCrossing) {
            toneCrossing = aToneCrossing;
        }

        public static boolean notAWideHarmony() {
            return notAWideHarmony;
        }

        public static void setNotAWideHarmony(boolean aNotAWideHarmony) {
            notAWideHarmony = aNotAWideHarmony;
        }

        public static boolean leadingToneDoubled() {
            return leadingToneDoubled;
        }

        public static void setLeadingToneDoubled(boolean aLeadingToneDoubled) {
            leadingToneDoubled = aLeadingToneDoubled;
        }

        public static boolean leadingToneNotResolved() {
            return leadingToneNotResolved;
        }

        public static void setLeadingToneNotResolved(boolean aLeadingToneNotResolved) {
            leadingToneNotResolved = aLeadingToneNotResolved;
        }

        public static boolean notCantabile() {
            return notCantabile;
        }

        public static void setNotCantabile(boolean aNotCantabile) {
            notCantabile = aNotCantabile;
        }

        public static boolean parallelEights() {
            return parallelEights;
        }

        public static void setParallelEights(boolean aParallelEights) {
            parallelEights = aParallelEights;
        }

        public static boolean parallelFifths() {
            return parallelFifths;
        }

        public static void setParallelFifths(boolean aParallelFifths) {
            parallelFifths = aParallelFifths;
        }

        public static boolean omitTone() {
            return omitTone;
        }

        public static void setOmitTone(boolean aOmitTone) {
            omitTone = aOmitTone;
        }

    }
}
