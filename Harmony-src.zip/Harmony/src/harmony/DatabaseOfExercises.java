/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;


/**
 *
 * @author Dominik Kruppa
 */
public class DatabaseOfExercises extends AbstractListModel implements ComboBoxModel {

    private List<Exercise> exercises = new ArrayList<Exercise>();
    private String selection = null;
    private boolean defaultDeleted = false;

    public DatabaseOfExercises(){

        exercises.add(0, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("<ZVOĽTE>"), null, null, null));
        exercises.add(1, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 1  ZÁKLADY"), Key.G,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G")),
                Arrays.asList(ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,
                ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5)));
        exercises.add(2, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 2  KVINTAKORDY"), Key.F,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("F"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("F")),
                Arrays.asList(ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,
                ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,ChordType._5,
                ChordType._5,ChordType._5,ChordType._5,ChordType._5)));
        exercises.add(3, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 3  MOLL HARMONICKÁ"), Key.g,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("D"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g")),
                Arrays.asList(ChordType._5,ChordType._5,ChordType._a,ChordType._5a,ChordType._5,ChordType._a,
                ChordType._5,ChordType._5,ChordType._a,ChordType._5,ChordType._5,ChordType._a,ChordType._5,
                ChordType._5,ChordType._5,ChordType._a,ChordType._5)));
        exercises.add(4, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 4  MOLL MELODICKÁ"), Key.fis,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS")),
                Arrays.asList(ChordType._5,ChordType._5,ChordType._a,ChordType._a,ChordType._5,ChordType._a,
                ChordType._5a,ChordType._5,ChordType._a,ChordType._5,ChordType._5a,ChordType._a,ChordType._5,
                ChordType._a,ChordType._a,ChordType._5)));
        exercises.add(5, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 5  SEXTAKORDY"), Key.C,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c")),
                Arrays.asList(ChordType._5,ChordType._6,ChordType._6,ChordType._5,ChordType._6,ChordType._5,
                ChordType._6,ChordType._6,ChordType._5,ChordType._5,ChordType._6,ChordType._6,ChordType._6,
                ChordType._5,ChordType._6,ChordType._6,ChordType._5,ChordType._5,ChordType._5)));
        exercises.add(6, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 6  KVARTSEXTAKORD"), Key.A,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A")),
                Arrays.asList(ChordType._5,ChordType._5,ChordType._6,ChordType._5,ChordType._5,ChordType._6,
                ChordType._64,ChordType._64,ChordType._53,ChordType._64,ChordType._53,ChordType._5,ChordType._6,
                ChordType._64,ChordType._5,ChordType._64,ChordType._6,ChordType._6,ChordType._5,
                ChordType._64,ChordType._53,ChordType._53,ChordType._64,ChordType._53)));
        exercises.add(7, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 7  DOMINANTNÝ SEPTAKORD"), Key.B,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("F"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B")),
                Arrays.asList(ChordType._53,ChordType._64,ChordType._7,ChordType._5,ChordType._5,ChordType._7,
                ChordType._5,ChordType._6,ChordType._7,ChordType._6,ChordType._7,ChordType._5,ChordType._5,
                ChordType._7,ChordType._5)));
        exercises.add(8, new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE 8  SEPTAKORD II. STUPŇA"), Key.Fis,
                Arrays.asList(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AIS"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis"),java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS")),
                Arrays.asList(ChordType._5,ChordType._2,ChordType._5,ChordType._6,ChordType._65,ChordType._6,
                ChordType._5,ChordType._5,ChordType._65,ChordType._5,ChordType._5,ChordType._6,ChordType._5,
                ChordType._5,ChordType._7,ChordType._7,ChordType._6,ChordType._6,ChordType._8,ChordType._7,ChordType._5)));

    }

    public Exercise getExcercise(Integer numberOfExcercise){

        return exercises.get(numberOfExcercise);

    }

    /**Removes exercise chooser.*/
    public void removeDefaultExcercise(){

        if(!defaultDeleted){
            exercises.remove(0);
            defaultDeleted = true;
        }

    }

    public void addExercise(Exercise exercise){

        if(defaultDeleted){
            exercises.add(0, exercise);
        }else{
            exercises.remove(0);
            exercises.add(0, exercise);
        }
        
    }

    public Object getElementAt(int index) {

        return exercises.get(index).getName();

  }

    public int getSize() {

        return exercises.size();

  }

    public void setSelectedItem(Object anItem) {

        selection = (String) anItem;

  }


    public Object getSelectedItem() {

        return selection;

  }

}
