/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public class Translation {

    /**Default language showed after application startup. */
    private static String language = "en";
    /**Default tone system showed after application startup. */
    private static ToneSystem toneSystem = ToneSystem.MAJOR12;

    public static void setLanguage(String lang){
        language = lang;
    }

    public static String getLanguage(){
        return language;
    }

    public static void setToneSystem(ToneSystem system){
        toneSystem = system;
    }

    public static ToneSystem getToneSystem(){
        return toneSystem;
    }

    /**
     * @return _ + code of enum representing tone system in lower case
     */
    public static String getToneSystemString(){
        return "_" + toneSystem.name().toLowerCase();
    }

    public static boolean isToneSystemUsed(String system){
        return toneSystem.toString().equals(system);
    }

    public static boolean isToneSystemCorrect(String system){
        for(Translation.ToneSystem correctSystem : Translation.ToneSystem.values()){
            if(correctSystem.toString().equals(system)){
                return true;
            }
        }
        return false;
    }

    public static ToneSystem getToneSystemFromToStringMethod(String name){
        for(Translation.ToneSystem system : Translation.ToneSystem.values()){
            if(system.toString().equals(name)){
                return system;
            }
        }
        return null;
    }


    public static enum ToneSystem {
        DUR {@Override public String toString(){return "Dur/Moll ,.";}
                       public String getToneSystemString(){return "_" + this.name().toLowerCase();}},
        DUR12 {@Override public String toString(){return "Dur/Moll 12";}
                         public String getToneSystemString(){return "_" + this.name().toLowerCase();}},
        MAJOR {@Override public String toString(){return "Major/Minor ,.";}
                         public String getToneSystemString(){return "_" + this.name().toLowerCase();}},
        MAJOR12 {@Override public String toString(){return "Major/Minor 12";}
                         public String getToneSystemString(){return "_" + this.name().toLowerCase();}};

        public abstract String getToneSystemString();
    }

}
