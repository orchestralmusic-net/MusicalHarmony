/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public enum Key {

    C, G, D, A, E, H, Fis, Cis, F, B, Es, As, Des, Ges, Ces,
    a, e, h, fis, cis, gis, dis, ais, d, g, c, f, b, es, as,
    empty;


    public DurMoll isDurOrMoll(){

        switch (this){

            case C: return DurMoll.DUR;
            case G: return DurMoll.DUR;
            case D: return DurMoll.DUR;
            case A: return DurMoll.DUR;
            case E: return DurMoll.DUR;
            case H: return DurMoll.DUR;
            case Fis: return DurMoll.DUR;
            case Cis: return DurMoll.DUR;
            case F: return DurMoll.DUR;
            case B: return DurMoll.DUR;
            case Es: return DurMoll.DUR;
            case As: return DurMoll.DUR;
            case Des: return DurMoll.DUR;
            case Ges: return DurMoll.DUR;
            case Ces: return DurMoll.DUR;
            case a: return DurMoll.MOLL;
            case e: return DurMoll.MOLL;
            case h: return DurMoll.MOLL;
            case fis: return DurMoll.MOLL;
            case cis: return DurMoll.MOLL;
            case gis: return DurMoll.MOLL;
            case dis: return DurMoll.MOLL;
            case ais: return DurMoll.MOLL;
            case d: return DurMoll.MOLL;
            case g: return DurMoll.MOLL;
            case c: return DurMoll.MOLL;
            case f: return DurMoll.MOLL;
            case b: return DurMoll.MOLL;
            case es: return DurMoll.MOLL;
            case as: return DurMoll.MOLL;

        }

        return null;

    }


    public String getGroundToneString(){

        switch (this){

            case C: return t("C");
            case G: return t("G");
            case D: return t("D");
            case A: return t("A");
            case E: return t("E");
            case H: return t("H");
            case Fis: return t("FIS");
            case Cis: return t("CIS");
            case F: return t("F");
            case B: return t("B");
            case Es: return t("ES");
            case As: return t("AS");
            case Des: return t("DES");
            case Ges: return t("GES");
            case Ces: return t("CES");
            case a: return t("A");
            case e: return t("E");
            case h: return t("H");
            case fis: return t("FIS");
            case cis: return t("CIS");
            case gis: return t("GIS");
            case dis: return t("DIS");
            case ais: return t("AIS");
            case d: return t("D");
            case g: return t("G");
            case c: return t("C");
            case f: return t("F");
            case b: return t("B");
            case es: return t("ES");
            case as: return t("AS");

        }

        return "interná chyba programu 3";


    }

    public Integer getGroundTone(){

        return Tones.getTone(getGroundToneString());

    }

    
    public String getInfo(){

        switch (this){

            case empty: return java.util.ResourceBundle.getBundle("harmony/resources/"+Translation.getLanguage()+"/"+DatabaseOfExercises.class.getSimpleName()).getString("<ZVOĽTE>");
            case C: return "    "+tSpec("C")+" "+dur();
            case G: return "1# "+tSpec("G")+" "+dur();
            case D: return "2# "+tSpec("D")+" "+dur();
            case A: return "3# "+tSpec("A")+" "+dur();
            case E: return "4# "+tSpec("E")+" "+dur();
            case H: return "5# "+tSpec("H")+" "+dur();
            case Fis: return "6# "+tSpec("FIS")+" "+dur();
            case Cis: return "7# "+tSpec("CIS")+" "+dur();
            case F: return "1b "+tSpec("F")+" "+dur();
            case B: return "2b "+tSpec("B")+" "+dur();
            case Es: return "3b "+tSpec("ES")+" "+dur();
            case As: return "4b "+tSpec("AS")+" "+dur();
            case Des: return "5b "+tSpec("DES")+" "+dur();
            case Ges: return "6b "+tSpec("GES")+" "+dur();
            case Ces: return "7b "+tSpec("CES")+" "+dur();
            case a: return "    "+tSpec("a")+" "+moll();
            case e: return "1# "+tSpec("e")+" "+moll();
            case h: return "2# "+tSpec("h")+" "+moll();
            case fis: return "3# "+tSpec("fis")+" "+moll();
            case cis: return "4# "+tSpec("cis")+" "+moll();
            case gis: return "5# "+tSpec("gis")+" "+moll();
            case dis: return "6# "+tSpec("dis")+" "+moll();
            case ais: return "7# "+tSpec("ais")+" "+moll();
            case d: return "1b "+tSpec("d")+" "+moll();
            case g: return "2b "+tSpec("g")+" "+moll();
            case c: return "3b "+tSpec("c")+" "+moll();
            case f: return "4b "+tSpec("f")+" "+moll();
            case b: return "5b "+tSpec("b")+" "+moll();
            case es: return "6b "+tSpec("es")+" "+moll();
            case as: return "7b "+tSpec("as")+" "+moll();

        }

        return "interná chyba programu 4";

    }


    public static Key getKey(String string){

        for(Key key : values()){
            if(string.equals(key.getInfo())){
                return key;
            }
        }

        return empty;

    }


    /** Tests, whether the tone do not belong to this key*/
    public boolean isChromatic(Integer tone){

        if(isDurOrMoll()==DurMoll.DUR){
            if((tone+48)%12==(0+getGroundTone())%12 || (tone+48)%12==(2+getGroundTone())%12 ||
                    (tone+48)%12==(4+getGroundTone())%12 || (tone+48)%12==(5+getGroundTone())%12 ||
                    (tone+48)%12==(7+getGroundTone())%12 || (tone+48)%12==(9+getGroundTone())%12 ||
                    (tone+48)%12==(11+getGroundTone())%12){
                return false;
            }else{
                return true;
            }
        }else{ //its moll
             if((tone+48)%12==(0+getGroundTone())%12 || (tone+48)%12==(2+getGroundTone())%12 ||
                     (tone+48)%12==(3+getGroundTone())%12 || (tone+48)%12==(5+getGroundTone())%12 ||
                     (tone+48)%12==(7+getGroundTone())%12 || (tone+48)%12==(8+getGroundTone())%12 ||
                     (tone+48)%12==(10+getGroundTone())%12){
                return false;
            }else{
                return true;
            }
        }
    }


    /** Gets leading tone (7th grade) of this key in lowest octave*/
    public int getLeadingTone(){

        return (11+getGroundTone())%12;

    }


    /** Returns position of the tone in this key, result is number 0-11 */
    public int getTonePosition(int tone){

        return (( ((tone+48)%12)+12 - (getGroundTone()+48)%12 )%12);

    }


    /** Returns position of the tone in entire tone system, result is number 0-11 */
    public static int getAbsoluteTonePosition(int tone){

        return tone % 12;

    }

    /** Base tone is beginning, number 0.
     * Other tones return 0-11, representing how far it is to go there from base tone, when going up the scale.*/
    public static int getRelativeTonePosition(int tone, int baseTone){

        return (((tone%12)  - (baseTone%12)) +48) %12;

    }

  
    private String t(String toneToTranslate){
        return java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString(toneToTranslate);
    }

    /**What you want to see when choosing key from box.*/
    private String tSpec(String toneToTranslate){
        if(Translation.getToneSystem().equals(Translation.ToneSystem.DUR12)){
            return java.util.ResourceBundle.getBundle("harmony/resources/Tones_dur").getString(toneToTranslate);
        }
        if(Translation.getToneSystem().equals(Translation.ToneSystem.MAJOR12)){
            return java.util.ResourceBundle.getBundle("harmony/resources/Tones_major").getString(toneToTranslate);
        }
        return java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString(toneToTranslate);
    }

    private String dur(){
        return java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dur");
    }

    private String moll(){
        return java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("moll");
    }

}
