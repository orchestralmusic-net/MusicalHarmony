/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dominik Kruppa
 */
public class Tones {

    public static Integer getTone(String tone){

        if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("C,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("C."))){
            return 0;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("CIS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DES,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("CIS.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DES."))){
            return 1;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("D,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("D."))){
            return 2;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DIS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DIS.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES."))){
            return 3;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("E,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FES,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("E.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FES."))){
            return 4;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("EIS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("F,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("EIS.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("F."))){
            return 5;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GES,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GES."))){
            return 6;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G."))){
            return 7;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GIS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GIS.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AS."))){
            return 8;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A."))){
            return 9;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AIS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HES,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AIS.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HES."))){
            return 10;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("CES,"))){
            return 11;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HIS,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HIS.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("C,"))){
            return 12;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("CIS,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DES,"))){
            return 13;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("D,"))){
            return 14;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DIS,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES,"))){
            return 15;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("E,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FES,"))){
            return 16;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("EIS,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("F,"))){
            return 17;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GES,"))){
            return 18;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G,"))){
            return 19;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GIS,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AS,"))){
            return 20;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A,"))){
            return 21;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AIS,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HES,"))){
            return 22;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("CES"))){
            return 23;
        }
        if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HIS,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("C"))){
            return 24;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("CIS")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DES"))){
            return 25;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("D"))){
            return 26;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("DIS")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES"))){
            return 27;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("E")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FES"))){
            return 28;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("EIS")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("F"))){
            return 29;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("FIS")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GES"))){
            return 30;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("G"))){
            return 31;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("GIS")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AS"))){
            return 32;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("A"))){
            return 33;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("AIS")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("B")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HES"))){
            return 34;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("H")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces"))){
            return 35;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("HIS")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c"))){
            return 36;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des"))){
            return 37;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d"))){
            return 38;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es"))){
            return 39;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes"))){
            return 40;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f"))){
            return 41;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges"))){
            return 42;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g"))){
            return 43;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as"))){
            return 44;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a"))){
            return 45;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes"))){
            return 46;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces,"))){
            return 47;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c,"))){
            return 48;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des,"))){
            return 49;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d,"))){
            return 50;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,"))){
            return 51;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes,"))){
            return 52;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f,"))){
            return 53;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges,"))){
            return 54;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g,"))){
            return 55;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as,"))){
            return 56;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a,"))){
            return 57;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes,"))){
            return 58;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces."))){
            return 59;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c."))){
            return 60;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des."))){
            return 61;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d."))){
            return 62;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es."))){
            return 63;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes."))){
            return 64;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f."))){
            return 65;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges."))){
            return 66;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g."))){
            return 67;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as."))){
            return 68;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a."))){
            return 69;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes."))){
            return 70;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces.,"))){
            return 71;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his.")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c.,"))){
            return 72;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des.,"))){
            return 73;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d.,"))){
            return 74;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es.,"))){
            return 75;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes.,"))){
            return 76;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f.,"))){
            return 77;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges.,"))){
            return 78;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g.,"))){
            return 79;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as.,"))){
            return 80;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a.,"))){
            return 81;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes.,"))){
            return 82;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces.."))){
            return 83;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his.,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c.."))){
            return 84;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("cis..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("des.."))){
            return 85;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("d.."))){
            return 86;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("dis..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es.."))){
            return 87;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("e..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fes.."))){
            return 88;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("eis..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("f.."))){
            return 89;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("fis..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ges.."))){
            return 90;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("g.."))){
            return 91;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("gis..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("as.."))){
            return 92;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("a.."))){
            return 93;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ais..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("b..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("hes.."))){
            return 94;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("h..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces,,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ces..,"))){
            return 95;
        }
        else if (tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("his..")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c,,,,,")) || tone.equals(java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c..,"))){
            return 96;
        }
        else {
            return null;
        }
    }

    public static List<Integer> getListOfTones(List<String> tones){

        List<Integer> result = new ArrayList<Integer>();
        for(int i = 0; i<tones.size(); i++){
            result.add(getTone(tones.get(i)));
        }
        return result;
    }

}
