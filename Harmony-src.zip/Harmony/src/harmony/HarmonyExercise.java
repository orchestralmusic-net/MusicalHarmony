/*
 * HarmonyView.java
 */

package harmony;

import java.awt.Color;
import java.awt.Dimension;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 * The application's main frame.
 */
public class HarmonyExercise extends FrameView {

    public HarmonyExercise(SingleFrameApplication app, HarmonyView hv) {
        super(app);

        superFrame = hv;

        //sets frame title
        getFrame().setTitle(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + "HarmonyView").getString("HARMÓNIA"));

        initComponents();

        this.getFrame().setMinimumSize(new Dimension(800, 400));

        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZVOĽTE NIEKTORÉ Z PREDVOLENÝCH CVIČENÍ."));

        this.getFrame().addWindowListener(new MyWindowListenerWithoutConfirmation());

        //tones[0] will non be used
        tones[1]=t11;
        tones[2]=t12;
        tones[3]=t13;
        tones[4]=t14;
        tones[5]=t15;
        tones[6]=t21;
        tones[7]=t22;
        tones[8]=t23;
        tones[9]=t24;
        tones[10]=t25;
        tones[11]=t31;
        tones[12]=t32;
        tones[13]=t33;
        tones[14]=t34;
        tones[15]=t35;
        tones[16]=t41;
        tones[17]=t42;
        tones[18]=t43;
        tones[19]=t44;
        tones[20]=t45;
        tones[21]=t51;
        tones[22]=t52;
        tones[23]=t53;
        tones[24]=t54;
        tones[25]=t55;
        tones[26]=t61;
        tones[27]=t62;
        tones[28]=t63;
        tones[29]=t64;
        tones[30]=t65;
        tones[31]=t71;
        tones[32]=t72;
        tones[33]=t73;
        tones[34]=t74;
        tones[35]=t75;
        tones[36]=t81;
        tones[37]=t82;
        tones[38]=t83;
        tones[39]=t84;
        tones[40]=t85;
        tones[41]=t91;
        tones[42]=t92;
        tones[43]=t93;
        tones[44]=t94;
        tones[45]=t95;
        tones[46]=ta1;
        tones[47]=ta2;
        tones[48]=ta3;
        tones[49]=ta4;
        tones[50]=ta5;
        tones[51]=tb1;
        tones[52]=tb2;
        tones[53]=tb3;
        tones[54]=tb4;
        tones[55]=tb5;
        tones[56]=tc1;
        tones[57]=tc2;
        tones[58]=tc3;
        tones[59]=tc4;
        tones[60]=tc5;
        tones[61]=td1;
        tones[62]=td2;
        tones[63]=td3;
        tones[64]=td4;
        tones[65]=td5;
        tones[66]=te1;
        tones[67]=te2;
        tones[68]=te3;
        tones[69]=te4;
        tones[70]=te5;
        tones[71]=tf1;
        tones[72]=tf2;
        tones[73]=tf3;
        tones[74]=tf4;
        tones[75]=tf5;
        tones[76]=tg1;
        tones[77]=tg2;
        tones[78]=tg3;
        tones[79]=tg4;
        tones[80]=tg5;
        tones[81]=th1;
        tones[82]=th2;
        tones[83]=th3;
        tones[84]=th4;
        tones[85]=th5;
        tones[86]=ti1;
        tones[87]=ti2;
        tones[88]=ti3;
        tones[89]=ti4;
        tones[90]=ti5;
        tones[91]=tj1;
        tones[92]=tj2;
        tones[93]=tj3;
        tones[94]=tj4;
        tones[95]=tj5;
        tones[96]=tk1;
        tones[97]=tk2;
        tones[98]=tk3;
        tones[99]=tk4;
        tones[100]=tk5;
        tones[101]=tl1;
        tones[102]=tl2;
        tones[103]=tl3;
        tones[104]=tl4;
        tones[105]=tl5;
        tones[106]=tm1;
        tones[107]=tm2;
        tones[108]=tm3;
        tones[109]=tm4;
        tones[110]=tm5;
        tones[111]=tn1;
        tones[112]=tn2;
        tones[113]=tn3;
        tones[114]=tn4;
        tones[115]=tn5;
        tones[116]=to1;
        tones[117]=to2;
        tones[118]=to3;
        tones[119]=to4;
        tones[120]=to5;
        tones[121]=tp1;
        tones[122]=tp2;
        tones[123]=tp3;
        tones[124]=tp4;
        tones[125]=tp5;
        tones[126]=tr1;
        tones[127]=tr2;
        tones[128]=tr3;
        tones[129]=tr4;
        tones[130]=tr5;
        tones[131]=ts1;
        tones[132]=ts2;
        tones[133]=ts3;
        tones[134]=ts4;
        tones[135]=ts5;
        tones[136]=tt1;
        tones[137]=tt2;
        tones[138]=tt3;
        tones[139]=tt4;
        tones[140]=tt5;
        tones[141]=tu1;
        tones[142]=tu2;
        tones[143]=tu3;
        tones[144]=tu4;
        tones[145]=tu5;
        tones[146]=tv1;
        tones[147]=tv2;
        tones[148]=tv3;
        tones[149]=tv4;
        tones[150]=tv5;

        //at start is nothing to edit until is selected a exercise
        for (int i = 1; i<151; i++){
            tones[i].setEditable(false);
        }
        checkButton.setEnabled(false);
        nextButton.setEnabled(false);
        previousButton.setEnabled(false);

        toneOmitButton.setVisible(false);

        //junctors should never be editable
        junctor0.setEditable(false);
        junctor1.setEditable(false);

        //translation of JFileChooser
        UIManager.getDefaults().addResourceBundle("harmony/resources/" + Translation.getLanguage() + "/" + "FileDialog");
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        checkButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        exerciseChoice = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        keyLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        communication = new javax.swing.JTextArea();
        t11 = new javax.swing.JTextField();
        t12 = new javax.swing.JTextField();
        t13 = new javax.swing.JTextField();
        t14 = new javax.swing.JTextField();
        t15 = new javax.swing.JTextField();
        t21 = new javax.swing.JTextField();
        t22 = new javax.swing.JTextField();
        t23 = new javax.swing.JTextField();
        t24 = new javax.swing.JTextField();
        t25 = new javax.swing.JTextField();
        t31 = new javax.swing.JTextField();
        t32 = new javax.swing.JTextField();
        t33 = new javax.swing.JTextField();
        t34 = new javax.swing.JTextField();
        t35 = new javax.swing.JTextField();
        t41 = new javax.swing.JTextField();
        t42 = new javax.swing.JTextField();
        t43 = new javax.swing.JTextField();
        t44 = new javax.swing.JTextField();
        t45 = new javax.swing.JTextField();
        t51 = new javax.swing.JTextField();
        t52 = new javax.swing.JTextField();
        t53 = new javax.swing.JTextField();
        t54 = new javax.swing.JTextField();
        t55 = new javax.swing.JTextField();
        t61 = new javax.swing.JTextField();
        t62 = new javax.swing.JTextField();
        t63 = new javax.swing.JTextField();
        t64 = new javax.swing.JTextField();
        t65 = new javax.swing.JTextField();
        t71 = new javax.swing.JTextField();
        t72 = new javax.swing.JTextField();
        t73 = new javax.swing.JTextField();
        t74 = new javax.swing.JTextField();
        t75 = new javax.swing.JTextField();
        t81 = new javax.swing.JTextField();
        t82 = new javax.swing.JTextField();
        t83 = new javax.swing.JTextField();
        t84 = new javax.swing.JTextField();
        t85 = new javax.swing.JTextField();
        t91 = new javax.swing.JTextField();
        t92 = new javax.swing.JTextField();
        t93 = new javax.swing.JTextField();
        t94 = new javax.swing.JTextField();
        t95 = new javax.swing.JTextField();
        ta1 = new javax.swing.JTextField();
        ta2 = new javax.swing.JTextField();
        ta3 = new javax.swing.JTextField();
        ta4 = new javax.swing.JTextField();
        ta5 = new javax.swing.JTextField();
        tb1 = new javax.swing.JTextField();
        tb2 = new javax.swing.JTextField();
        tb3 = new javax.swing.JTextField();
        tb4 = new javax.swing.JTextField();
        tb5 = new javax.swing.JTextField();
        tc1 = new javax.swing.JTextField();
        tc2 = new javax.swing.JTextField();
        tc3 = new javax.swing.JTextField();
        tc4 = new javax.swing.JTextField();
        tc5 = new javax.swing.JTextField();
        td1 = new javax.swing.JTextField();
        td2 = new javax.swing.JTextField();
        td3 = new javax.swing.JTextField();
        td4 = new javax.swing.JTextField();
        td5 = new javax.swing.JTextField();
        te1 = new javax.swing.JTextField();
        te2 = new javax.swing.JTextField();
        te3 = new javax.swing.JTextField();
        te4 = new javax.swing.JTextField();
        te5 = new javax.swing.JTextField();
        tf1 = new javax.swing.JTextField();
        tf2 = new javax.swing.JTextField();
        tf3 = new javax.swing.JTextField();
        tf4 = new javax.swing.JTextField();
        tf5 = new javax.swing.JTextField();
        tg1 = new javax.swing.JTextField();
        tg2 = new javax.swing.JTextField();
        tg3 = new javax.swing.JTextField();
        tg4 = new javax.swing.JTextField();
        tg5 = new javax.swing.JTextField();
        th1 = new javax.swing.JTextField();
        th2 = new javax.swing.JTextField();
        th3 = new javax.swing.JTextField();
        th4 = new javax.swing.JTextField();
        th5 = new javax.swing.JTextField();
        ti1 = new javax.swing.JTextField();
        ti2 = new javax.swing.JTextField();
        ti3 = new javax.swing.JTextField();
        ti4 = new javax.swing.JTextField();
        ti5 = new javax.swing.JTextField();
        tj1 = new javax.swing.JTextField();
        tj2 = new javax.swing.JTextField();
        tj3 = new javax.swing.JTextField();
        tj4 = new javax.swing.JTextField();
        tj5 = new javax.swing.JTextField();
        tk1 = new javax.swing.JTextField();
        tk2 = new javax.swing.JTextField();
        tk3 = new javax.swing.JTextField();
        tk4 = new javax.swing.JTextField();
        tk5 = new javax.swing.JTextField();
        tl1 = new javax.swing.JTextField();
        tl2 = new javax.swing.JTextField();
        tl3 = new javax.swing.JTextField();
        tl4 = new javax.swing.JTextField();
        tl5 = new javax.swing.JTextField();
        tm1 = new javax.swing.JTextField();
        tm2 = new javax.swing.JTextField();
        tm3 = new javax.swing.JTextField();
        tm4 = new javax.swing.JTextField();
        tm5 = new javax.swing.JTextField();
        tn1 = new javax.swing.JTextField();
        tn2 = new javax.swing.JTextField();
        tn3 = new javax.swing.JTextField();
        tn4 = new javax.swing.JTextField();
        tn5 = new javax.swing.JTextField();
        to1 = new javax.swing.JTextField();
        to2 = new javax.swing.JTextField();
        to3 = new javax.swing.JTextField();
        to4 = new javax.swing.JTextField();
        to5 = new javax.swing.JTextField();
        tp1 = new javax.swing.JTextField();
        tp2 = new javax.swing.JTextField();
        tp3 = new javax.swing.JTextField();
        tp4 = new javax.swing.JTextField();
        tp5 = new javax.swing.JTextField();
        tr1 = new javax.swing.JTextField();
        tr2 = new javax.swing.JTextField();
        tr3 = new javax.swing.JTextField();
        tr4 = new javax.swing.JTextField();
        tr5 = new javax.swing.JTextField();
        ts1 = new javax.swing.JTextField();
        ts2 = new javax.swing.JTextField();
        ts3 = new javax.swing.JTextField();
        ts4 = new javax.swing.JTextField();
        ts5 = new javax.swing.JTextField();
        tt1 = new javax.swing.JTextField();
        tt2 = new javax.swing.JTextField();
        tt3 = new javax.swing.JTextField();
        tt4 = new javax.swing.JTextField();
        tt5 = new javax.swing.JTextField();
        tu1 = new javax.swing.JTextField();
        tu2 = new javax.swing.JTextField();
        tu3 = new javax.swing.JTextField();
        tu4 = new javax.swing.JTextField();
        tu5 = new javax.swing.JTextField();
        tv1 = new javax.swing.JTextField();
        tv2 = new javax.swing.JTextField();
        tv3 = new javax.swing.JTextField();
        tv4 = new javax.swing.JTextField();
        tv5 = new javax.swing.JTextField();
        nextButton = new javax.swing.JButton();
        previousButton = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        junctor0 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        junctor1 = new javax.swing.JTextField();
        toneOmitButton = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        showFirstScreen = new javax.swing.JMenuItem();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        exerciseMenu = new javax.swing.JMenu();
        openExercise = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        toneInputHelp = new javax.swing.JMenuItem();
        openFileHelp = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        javax.swing.JMenuItem userGuideMenuItem = new javax.swing.JMenuItem();

        mainPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        mainPanel.setName("mainPanel"); // NOI18N

        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()); // NOI18N
        checkButton.setText(bundle.getString("Overiť")); // NOI18N
        checkButton.setName("checkButton"); // NOI18N
        checkButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkButtonActionPerformed(evt);
            }
        });

        jLabel1.setText(bundle.getString("Predvolené cvičenie:")); // NOI18N
        jLabel1.setName("jLabel1"); // NOI18N

        exerciseChoice.setModel(database);
        exerciseChoice.setSelectedItem(getDefaultExercise());
        exerciseChoice.setName("exerciseChoice"); // NOI18N
        exerciseChoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exerciseChoiceActionPerformed(evt);
            }
        });

        jLabel2.setText(bundle.getString("Tónina:")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(harmony.HarmonyApp.class).getContext().getResourceMap(HarmonyExercise.class);
        keyLabel.setText(resourceMap.getString("keyLabel.text")); // NOI18N
        keyLabel.setName("keyLabel"); // NOI18N

        jLabel3.setText(bundle.getString("1. tón:")); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N

        jLabel4.setText(bundle.getString("2. tón:")); // NOI18N
        jLabel4.setName("jLabel4"); // NOI18N

        jLabel5.setText(bundle.getString("3. tón:")); // NOI18N
        jLabel5.setName("jLabel5"); // NOI18N

        jLabel6.setText(bundle.getString("4. tón:")); // NOI18N
        jLabel6.setName("jLabel6"); // NOI18N

        jLabel7.setText(bundle.getString(" akord:")); // NOI18N
        jLabel7.setName("jLabel7"); // NOI18N

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(13, 91));
        jScrollPane1.setName("jScrollPane1"); // NOI18N

        communication.setColumns(1);
        communication.setEditable(false);
        communication.setFont(resourceMap.getFont("communication.font")); // NOI18N
        communication.setRows(5);
        communication.setText(resourceMap.getString("communication.text")); // NOI18N
        communication.setName("communication"); // NOI18N
        jScrollPane1.setViewportView(communication);

        t11.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t11.setText(resourceMap.getString("t11.text")); // NOI18N
        t11.setName("t11"); // NOI18N

        t12.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t12.setName("t12"); // NOI18N

        t13.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t13.setName("t13"); // NOI18N

        t14.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t14.setName("t14"); // NOI18N

        t15.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t15.setName("t15"); // NOI18N

        t21.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t21.setName("t21"); // NOI18N

        t22.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t22.setName("t22"); // NOI18N

        t23.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t23.setName("t23"); // NOI18N

        t24.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t24.setName("t24"); // NOI18N

        t25.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t25.setName("t25"); // NOI18N

        t31.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t31.setName("t31"); // NOI18N

        t32.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t32.setName("t32"); // NOI18N

        t33.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t33.setName("t33"); // NOI18N

        t34.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t34.setName("t34"); // NOI18N

        t35.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t35.setName("t35"); // NOI18N

        t41.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t41.setName("t41"); // NOI18N

        t42.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t42.setName("t42"); // NOI18N

        t43.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t43.setName("t43"); // NOI18N

        t44.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t44.setName("t44"); // NOI18N

        t45.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t45.setName("t45"); // NOI18N

        t51.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t51.setName("t51"); // NOI18N

        t52.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t52.setName("t52"); // NOI18N

        t53.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t53.setName("t53"); // NOI18N

        t54.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t54.setName("t54"); // NOI18N

        t55.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t55.setName("t55"); // NOI18N

        t61.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t61.setName("t61"); // NOI18N

        t62.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t62.setName("t62"); // NOI18N

        t63.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t63.setName("t63"); // NOI18N

        t64.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t64.setName("t64"); // NOI18N

        t65.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t65.setName("t65"); // NOI18N

        t71.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t71.setName("t71"); // NOI18N

        t72.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t72.setName("t72"); // NOI18N

        t73.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t73.setName("t73"); // NOI18N

        t74.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t74.setName("t74"); // NOI18N

        t75.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t75.setName("t75"); // NOI18N

        t81.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t81.setName("t81"); // NOI18N

        t82.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t82.setName("t82"); // NOI18N

        t83.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t83.setName("t83"); // NOI18N

        t84.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t84.setName("t84"); // NOI18N

        t85.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t85.setName("t85"); // NOI18N

        t91.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t91.setName("t91"); // NOI18N

        t92.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t92.setName("t92"); // NOI18N

        t93.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t93.setName("t93"); // NOI18N

        t94.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t94.setName("t94"); // NOI18N

        t95.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t95.setName("t95"); // NOI18N

        ta1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta1.setName("ta1"); // NOI18N

        ta2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta2.setName("ta2"); // NOI18N

        ta3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta3.setName("ta3"); // NOI18N

        ta4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta4.setName("ta4"); // NOI18N

        ta5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta5.setName("ta5"); // NOI18N

        tb1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb1.setName("tb1"); // NOI18N

        tb2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb2.setName("tb2"); // NOI18N

        tb3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb3.setName("tb3"); // NOI18N

        tb4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb4.setName("tb4"); // NOI18N

        tb5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb5.setName("tb5"); // NOI18N

        tc1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc1.setName("tc1"); // NOI18N

        tc2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc2.setName("tc2"); // NOI18N

        tc3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc3.setName("tc3"); // NOI18N

        tc4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc4.setName("tc4"); // NOI18N

        tc5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc5.setName("tc5"); // NOI18N

        td1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td1.setName("td1"); // NOI18N

        td2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td2.setName("td2"); // NOI18N

        td3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td3.setName("td3"); // NOI18N

        td4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td4.setName("td4"); // NOI18N

        td5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td5.setName("td5"); // NOI18N

        te1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te1.setName("te1"); // NOI18N

        te2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te2.setName("te2"); // NOI18N

        te3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te3.setName("te3"); // NOI18N

        te4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te4.setName("te4"); // NOI18N

        te5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te5.setName("te5"); // NOI18N

        tf1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf1.setName("tf1"); // NOI18N

        tf2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf2.setName("tf2"); // NOI18N

        tf3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf3.setName("tf3"); // NOI18N

        tf4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf4.setName("tf4"); // NOI18N

        tf5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf5.setName("tf5"); // NOI18N

        tg1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg1.setName("tg1"); // NOI18N

        tg2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg2.setName("tg2"); // NOI18N

        tg3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg3.setName("tg3"); // NOI18N

        tg4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg4.setName("tg4"); // NOI18N

        tg5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg5.setName("tg5"); // NOI18N

        th1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th1.setName("th1"); // NOI18N

        th2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th2.setName("th2"); // NOI18N

        th3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th3.setName("th3"); // NOI18N

        th4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th4.setName("th4"); // NOI18N

        th5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th5.setName("th5"); // NOI18N

        ti1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti1.setName("ti1"); // NOI18N

        ti2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti2.setName("ti2"); // NOI18N

        ti3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti3.setName("ti3"); // NOI18N

        ti4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti4.setName("ti4"); // NOI18N

        ti5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti5.setName("ti5"); // NOI18N

        tj1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj1.setName("tj1"); // NOI18N

        tj2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj2.setName("tj2"); // NOI18N

        tj3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj3.setName("tj3"); // NOI18N

        tj4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj4.setName("tj4"); // NOI18N

        tj5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj5.setName("tj5"); // NOI18N

        tk1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk1.setName("tk1"); // NOI18N

        tk2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk2.setName("tk2"); // NOI18N

        tk3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk3.setName("tk3"); // NOI18N

        tk4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk4.setName("tk4"); // NOI18N

        tk5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk5.setName("tk5"); // NOI18N

        tl1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl1.setName("tl1"); // NOI18N

        tl2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl2.setName("tl2"); // NOI18N

        tl3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl3.setName("tl3"); // NOI18N

        tl4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl4.setName("tl4"); // NOI18N

        tl5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl5.setName("tl5"); // NOI18N

        tm1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm1.setName("tm1"); // NOI18N

        tm2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm2.setName("tm2"); // NOI18N

        tm3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm3.setName("tm3"); // NOI18N

        tm4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm4.setName("tm4"); // NOI18N

        tm5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm5.setName("tm5"); // NOI18N

        tn1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn1.setName("tn1"); // NOI18N

        tn2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn2.setName("tn2"); // NOI18N

        tn3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn3.setName("tn3"); // NOI18N

        tn4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn4.setName("tn4"); // NOI18N

        tn5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn5.setName("tn5"); // NOI18N

        to1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to1.setName("to1"); // NOI18N

        to2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to2.setName("to2"); // NOI18N

        to3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to3.setName("to3"); // NOI18N

        to4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to4.setName("to4"); // NOI18N

        to5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to5.setName("to5"); // NOI18N

        tp1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp1.setName("tp1"); // NOI18N

        tp2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp2.setName("tp2"); // NOI18N

        tp3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp3.setName("tp3"); // NOI18N

        tp4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp4.setName("tp4"); // NOI18N

        tp5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp5.setName("tp5"); // NOI18N

        tr1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr1.setName("tr1"); // NOI18N

        tr2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr2.setName("tr2"); // NOI18N

        tr3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr3.setName("tr3"); // NOI18N

        tr4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr4.setName("tr4"); // NOI18N

        tr5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr5.setName("tr5"); // NOI18N

        ts1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts1.setName("ts1"); // NOI18N

        ts2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts2.setName("ts2"); // NOI18N

        ts3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts3.setName("ts3"); // NOI18N

        ts4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts4.setName("ts4"); // NOI18N

        ts5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts5.setName("ts5"); // NOI18N

        tt1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt1.setName("tt1"); // NOI18N

        tt2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt2.setName("tt2"); // NOI18N

        tt3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt3.setName("tt3"); // NOI18N

        tt4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt4.setName("tt4"); // NOI18N

        tt5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt5.setName("tt5"); // NOI18N

        tu1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu1.setName("tu1"); // NOI18N

        tu2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu2.setName("tu2"); // NOI18N

        tu3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu3.setName("tu3"); // NOI18N

        tu4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu4.setName("tu4"); // NOI18N

        tu5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu5.setName("tu5"); // NOI18N

        tv1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv1.setName("tv1"); // NOI18N

        tv2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv2.setName("tv2"); // NOI18N

        tv3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv3.setName("tv3"); // NOI18N

        tv4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv4.setName("tv4"); // NOI18N

        tv5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv5.setName("tv5"); // NOI18N

        nextButton.setText(bundle.getString("Ďalší akord")); // NOI18N
        nextButton.setName("nextButton"); // NOI18N
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });

        previousButton.setText(bundle.getString("Predchádzajúci akord")); // NOI18N
        previousButton.setName("previousButton"); // NOI18N
        previousButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousButtonActionPerformed(evt);
            }
        });

        jLabel8.setText(bundle.getString("Aktuálna spojnica:")); // NOI18N
        jLabel8.setName("jLabel8"); // NOI18N

        junctor0.setName("junctor0"); // NOI18N

        jLabel9.setText(resourceMap.getString("jLabel9.text")); // NOI18N
        jLabel9.setName("jLabel9"); // NOI18N

        junctor1.setName("junctor1"); // NOI18N

        toneOmitButton.setText(bundle.getString("Povoliť akord s vynechanými tónmi")); // NOI18N
        toneOmitButton.setName("toneOmitButton"); // NOI18N
        toneOmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toneOmitButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1149, Short.MAX_VALUE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(checkButton)
                        .addGap(18, 18, 18)
                        .addComponent(nextButton)
                        .addGap(18, 18, 18)
                        .addComponent(previousButton)
                        .addGap(128, 128, 128)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(junctor0, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(junctor1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel7))
                                        .addGap(21, 21, 21)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(t12, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(t11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(t13, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(t14, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(t15, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(t22, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t23, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t24, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t21, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(t25, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(t32, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t33, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t34, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t31, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(t35, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t42, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t43, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t44, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t41, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(t45, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(t52, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t53, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t54, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t51, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(t55, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(8, 8, 8)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(t62, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t63, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t64, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t61, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(t65, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(t72, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t73, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t74, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t71, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(t75, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t82, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t83, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t84, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(mainPanelLayout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(t81, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(t85, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(keyLabel)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(t92, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t93, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t94, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t91, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t95, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(8, 8, 8)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(ta2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(ta3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(ta4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(ta1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(ta5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tb2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tb3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tb4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tb1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tb5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tc5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(td2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(td3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(td4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(td1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(td5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(8, 8, 8)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(te2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(te3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(te4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(te1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(te5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tg5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(th2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(th3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(th4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(th1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(th5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(ti2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(ti3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(ti4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(ti1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(ti5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(10, 10, 10)
                                .addComponent(exerciseChoice, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(toneOmitButton)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tj2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tj3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tj4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tj1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tj5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tk2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tk3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tk4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tk1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tk5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tl2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tl3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tl4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tl1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tl5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tm5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tn2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tn3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tn4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tn1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tn5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(to2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(to3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(to4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(to1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(to5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tp2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tp3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tp4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tp1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tp5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tr5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(ts2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ts3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ts4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ts1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(ts5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tt2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tt3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tt4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tt1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tt5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tu2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tu3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tu4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tu1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tu5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tv5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(exerciseChoice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(keyLabel)
                            .addComponent(jLabel2)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(toneOmitButton)))
                .addGap(18, 18, 18)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t21, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t11, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t22, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t12, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t23, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t13, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t24, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t14, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t31, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t32, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t33, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t34, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t41, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t42, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t43, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t44, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t35, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t25, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t45, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t15, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t51, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t52, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t53, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t54, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t61, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t62, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t63, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t64, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t55, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t71, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t72, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t73, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t74, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t81, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t82, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t83, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t84, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t75, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t65, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t85, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t91, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t92, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t93, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t94, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(ta1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ta2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ta3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ta4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t95, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tb1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tb2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tb3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tb4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tc1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tc2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tc3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tc4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tb5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ta5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tc5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(td1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(td2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(td3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(td4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(te1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(te2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(te3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(te4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(td5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tg1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tg2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tg3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tg4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(te5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tg5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(th1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(th2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(th3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(th4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(ti1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ti2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ti3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ti4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(th5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ti5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tj1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tj2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tj3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tj4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tk1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tk2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tk3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tk4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tj5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tl1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tl2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tl3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tl4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tm1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tm2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tm3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tm4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tl5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tk5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tm5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tn1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tn2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tn3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tn4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(to1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(to2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(to3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(to4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tn5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tp1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tp2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tp3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tp4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tr1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tr2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tr3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tr4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tp5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(to5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tr5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(ts1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ts2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ts3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ts4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tt1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tt2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tt3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tt4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ts5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tu1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tu2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tu3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tu4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tv1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tv2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tv3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tv4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tu5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tt5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tv5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(previousButton)
                    .addComponent(nextButton)
                    .addComponent(checkButton)
                    .addComponent(jLabel8)
                    .addComponent(junctor0, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(junctor1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(bundle.getString("Program")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        showFirstScreen.setText(bundle.getString("Úvodná obrazovka")); // NOI18N
        showFirstScreen.setName("showFirstScreen"); // NOI18N
        showFirstScreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showFirstScreenActionPerformed(evt);
            }
        });
        fileMenu.add(showFirstScreen);

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(harmony.HarmonyApp.class).getContext().getActionMap(HarmonyExercise.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setText(bundle.getString("Koniec")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        exerciseMenu.setText(bundle.getString("Cvičenie")); // NOI18N
        exerciseMenu.setName("exerciseMenu"); // NOI18N

        openExercise.setText(bundle.getString("Otvoriť zo súboru")); // NOI18N
        openExercise.setName("openExercise"); // NOI18N
        openExercise.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openExerciseActionPerformed(evt);
            }
        });
        exerciseMenu.add(openExercise);

        menuBar.add(exerciseMenu);

        helpMenu.setText(bundle.getString("Pomoc")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        toneInputHelp.setText(bundle.getString("Formát tónov")); // NOI18N
        toneInputHelp.setName("toneInputHelp"); // NOI18N
        toneInputHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toneInputHelpActionPerformed(evt);
            }
        });
        helpMenu.add(toneInputHelp);

        openFileHelp.setText(bundle.getString("Otvoriť zo súboru")); // NOI18N
        openFileHelp.setName("openFileHelp"); // NOI18N
        openFileHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openFileHelpActionPerformed(evt);
            }
        });
        helpMenu.add(openFileHelp);

        jSeparator1.setName("jSeparator1"); // NOI18N
        helpMenu.add(jSeparator1);

        userGuideMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        userGuideMenuItem.setText(bundle.getString("Príručka")); // NOI18N
        userGuideMenuItem.setName("userGuideMenuItem"); // NOI18N
        userGuideMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userGuideMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(userGuideMenuItem);

        menuBar.add(helpMenu);

        setComponent(mainPanel);
        setMenuBar(menuBar);
    }// </editor-fold>//GEN-END:initComponents

    private void showFirstScreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showFirstScreenActionPerformed
        superFrame.getFrame().setVisible(true);
        this.getFrame().setVisible(false);
}//GEN-LAST:event_showFirstScreenActionPerformed

    private void exerciseChoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exerciseChoiceActionPerformed
        if(exerciseChoice.getSelectedItem() != null && exerciseChoice.getSelectedIndex() != firstInvalidExercise){
                exercise = database.getExcercise(exerciseChoice.getSelectedIndex());
                keyLabel.setText(exercise.getKey().getInfo());
                firstInvalidExercise = -1;

                int i = 0;

                //fills basses and types of chords with values
                for(; i<exercise.getSize(); i++){
                    tones[eachFive[i]+3].setText(exercise.getBasses().get(i));
                    tones[eachFive[i]+4].setText(exercise.getTypes().get(i).toString());
                }

                //fills rest of basses and types of chords with empty values
                for(; i<30; i++){
                    tones[eachFive[i]+3].setText("");
                    tones[eachFive[i]+4].setText("");
                }

                //first three tones should be empty at start of exercise
                for(int j = 0; j<30; j++){
                    tones[eachFive[j]].setText("");
                    tones[eachFive[j]+1].setText("");
                    tones[eachFive[j]+2].setText("");
                }

                //delete first row from exercise choice, if that havent happened yet
                if (!defaultDeleted){
                    database.removeDefaultExcercise();
                    defaultDeleted = true;
                }

                //only first column should be editable and only first three notes from it
                for (int k = 1; k<151; k++){
                    tones[k].setEditable(false);
                }
                tones[1].setEditable(true);
                tones[2].setEditable(true);
                tones[3].setEditable(true);

                //first column is for edit
                column = 1;

                try {
                        junctor0.setText("");
                        junctor1.setText(exercise.getTypes().get(0).getChordPosition(exercise.getKey(), Tones.getTone(exercise.getBasses().get(0))).toString());
                } catch (GroundNotSupportedException ex) { //this could happen only if predefined exercise was incorrect
                        red();
                        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ BASOVÝ TÓN NEPATRÍ DO ZVOLENEJ TÓNINY."));
                }

                green();
                communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ÚSPEŠNE STE ZVOLILI CVIČENIE. TERAZ ZADAJTE AKORD A STLAČTE TLAČÍTKO \"OVERIŤ\"."));

                checkButton.setEnabled(true);
                nextButton.setEnabled(false);
                previousButton.setEnabled(false);
        }
    }//GEN-LAST:event_exerciseChoiceActionPerformed

    private void checkButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkButtonActionPerformed
        toneOmitButton.setVisible(false);

        Chord chord = new Chord(Tones.getTone(tones[column*5-4].getText()),Tones.getTone(tones[column*5-3].getText()),
                Tones.getTone(tones[column*5-2].getText()),Tones.getTone(tones[column*5-1].getText()));
        String actualErrorText;

        if(chord.areTonesCorrect()!=0){ //then some tone is inputted incorrectly
            red();
            communication.setText(chord.areTonesCorrect()+ java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString(". TÓN JE ZADANÝ V NESPRÁVNOM FORMÁTE.")+"\n"
                    + inputToneFormat());
            nextButton.setEnabled(false);
        }else{ //check musical validity of the chord
            communication.setText("");
            ChordValidity lastResult;
            if(column==1){ //case that this is first chord in the exercise
                try {
                    lastResult = chord.validateFirstChord(exercise.getTypes().get(0), exercise.getKey(), omit, false);
                    if (lastResult.isValid()) {
                        green();
                        if(column!=exercise.getSize()){
                            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VÝBORNE. AKORD JE ZADANÝ SPRÁVNE. MÔŽETE PREJSŤ NA ĎALŠÍ AKORD POMOCOU TLAČÍTKA \"ĎALŠÍ AKORD\".")+"\n"
                                + lastResult.getInfo());
                            nextButton.setEnabled(true);
                        }else{
                            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("GRATULÁCIA! STE NA KONCI CVIČENIA."));
                            nextButton.setEnabled(false);
                        }
                    } else {
                        red();
                        actualErrorText = lastResult.getInfo();
                        communication.setText(actualErrorText);
                        nextButton.setEnabled(false);
                        if(actualErrorText.equals(Chord.getOmissionMessage())){ //then some tone is missing in chord
                            toneOmitButton.setVisible(true);
                        }
                    }
                } catch (GroundNotSupportedException ex) { //this could happen only if predefined exercise was incorrect
                    red();
                    communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ BASOVÝ TÓN NEPATRÍ DO ZVOLENEJ TÓNINY."));
                }
            }else{ //its not first chord
                Chord previousChord = new Chord(Tones.getTone(tones[(column-1)*5-4].getText()),Tones.getTone(tones[(column-1)*5-3].getText()),
                        Tones.getTone(tones[(column-1)*5-2].getText()),Tones.getTone(tones[(column-1)*5-1].getText()));
                try {
                    lastResult = chord.validateChord(previousChord, exercise.getTypes().get(column-1), exercise.getKey(), omit, false);
                    if (lastResult.isValid()) {
                        green();
                        if(column!=exercise.getSize()){
                            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VÝBORNE. AKORD JE ZADANÝ SPRÁVNE. MÔŽETE PREJSŤ NA ĎALŠÍ AKORD POMOCOU TLAČÍTKA \"ĎALŠÍ AKORD\".")+"\n"
                                + lastResult.getInfo());
                            nextButton.setEnabled(true);
                        }else{
                            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("GRATULÁCIA! STE NA KONCI CVIČENIA."));
                            nextButton.setEnabled(false);
                        }
                    } else {
                        red();
                        actualErrorText = lastResult.getInfo();
                        communication.setText(actualErrorText);
                        nextButton.setEnabled(false);
                        if(actualErrorText.equals(Chord.getOmissionMessage())){ //then some tone is missing in chord
                            toneOmitButton.setVisible(true);
                        }
                    }
                } catch (GroundNotSupportedException ex) { //this could happen only if predefined exercise was incorrect
                    red();
                    communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ BASOVÝ TÓN NEPATRÍ DO ZVOLENEJ TÓNINY."));
                }
            }
        }
}//GEN-LAST:event_checkButtonActionPerformed

    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        next();
        nextButton.setEnabled(false);
        previousButton.setEnabled(true);
        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TERAZ ZADAJTE TÓNY ĎALŠIEHO AKORDU A STLAČTE TLAČÍTKO \"OVERIŤ\"."));
         try {
                junctor0.setText(junctor1.getText());
                junctor1.setText(exercise.getTypes().get(column-1).getChordPosition(exercise.getKey(), Tones.getTone(exercise.getBasses().get(column-1))).toString());
        } catch (GroundNotSupportedException ex) { //this could happen only if predefined exercise was incorrect
                red();
                communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ BASOVÝ TÓN NEPATRÍ DO ZVOLENEJ TÓNINY."));
        }
    }//GEN-LAST:event_nextButtonActionPerformed

    private void previousButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousButtonActionPerformed
        previous();
        toneOmitButton.setVisible(false);
        if(column==1){
            previousButton.setEnabled(false);
        }
        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TERAZ MÔŽETE OPRAVIŤ ALEBO UPRAVIŤ NIEKTORÝ ZO SKORŠÍCH AKORDOV."));
    }//GEN-LAST:event_previousButtonActionPerformed

    private void toneOmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toneOmitButtonActionPerformed
        omit.allowToneOmission();
        checkButtonActionPerformed(evt);
        omit.forbidToneOmission();
        toneOmitButton.setVisible(false);
    }//GEN-LAST:event_toneOmitButtonActionPerformed

    private void toneInputHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toneInputHelpActionPerformed
        JOptionPane.showMessageDialog(this.getComponent(), inputToneFormat(), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("FORMÁT TÓNOV"), 1);
    }//GEN-LAST:event_toneInputHelpActionPerformed

    private void openExerciseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openExerciseActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setAcceptAllFileFilterUsed(false);
        MyFileFilter filter = new MyFileFilter();
        fileChooser.setFileFilter(filter);

        int resultVal = fileChooser.showOpenDialog(this.getComponent());
        File file = null;
        if (resultVal == JFileChooser.APPROVE_OPTION) {
            file = fileChooser.getSelectedFile();
        }
        if (resultVal == JFileChooser.CANCEL_OPTION) {
        }

        String extension = "";
        if(file!=null){
            String fileName = file.getName();

            //Remove whitespace.
            fileName = fileName.trim();

            //Find the position of the last dot.  Get extension.
            int dotPos = fileName.lastIndexOf(".");
            if(dotPos!=-1){
                extension = fileName.substring(dotPos);
            }
        }


        FileInputStream fis = null;
        BufferedInputStream bis = null;
        BufferedReader reader = null;


        try {
            if(file!=null){
                fis = new FileInputStream(file);
                bis = new BufferedInputStream(fis);
                reader = new BufferedReader(new InputStreamReader(bis));

                if(!extension.equals(".har")){
                    throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE POVOLENÉ OTVÁRAŤ IBA SÚBORY S PRÍPONOOU \".HAR\"."));
                }

                if(!reader.ready()){
                    throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR JE PRÁZDNY ALEBO NEPRÍSTUPNÝ NA ČÍTANIE:")+" "+file);
                }
                String header = reader.readLine();
                if(header.equals("Harmony")){
                    throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR BOL ZREJME VYTVORENÝ STARŠOU VERZIOU TOHTO PROGRAMU A NEMOŽNO HO OTVORIŤ:")+" "+file);
                }
                if(!header.equals("Harmony 1.1")){
                    throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR JE V NESPRÁVNOM FORMÁTE:")+" "+file);
                }
                String fileSystem = reader.readLine();
                String thisSystem = Translation.getToneSystem().toString();
                Map<String, String> transcodingMap = null;
                String transcodingInfo = "";
                if(!Translation.isToneSystemUsed(fileSystem)){
                    if(Translation.isToneSystemCorrect(fileSystem)){
                        transcodingMap = HarmonyOwnExercise.getTranscodingMap(Translation.getToneSystemFromToStringMethod(fileSystem), Translation.getToneSystemFromToStringMethod(thisSystem));
                        transcodingInfo = "\n"+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SKLADBA BOLA AUTOMATICKY PREVEDENÁ Z TÓNOVÉHO SYSTÉMU:")+" "+fileSystem+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString(" DO VÁŠHO SYSTÉMU:")+" "+thisSystem+"\n"+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PRÍPADNÉ CHYBNE ZADANÉ TÓNY BOLI PONECHANÉ V PÔVODNOM TVARE.");
                        Translation.setToneSystem(Translation.getToneSystemFromToStringMethod(fileSystem)); //needed temporarily for setting musical key
                    }else{
                        throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR JE V NESPRÁVNOM FORMÁTE."));
                    }
                }
                Key key = Key.getKey(reader.readLine()); // key is now correctly set
                Translation.setToneSystem(Translation.getToneSystemFromToStringMethod(thisSystem)); //return to original value
                String keyString = key.getInfo();

                eraseBoxes();

                junctor0.setText("");
                junctor1.setText("");
                toneOmitButton.setVisible(false);
                checkButton.setEnabled(false);
                nextButton.setEnabled(false);
                previousButton.setEnabled(false);

                if(reader.ready()){ //fills the frame
                    if(transcodingMap == null){ //that means no transcoding needed
                        for(int i=1; i<=150; i++){
                            tones[i].setText(reader.readLine());
                            tones[i].setEditable(false);
                        }
                    }else{
                        for(int i=1; i<=150; i++){
                            tones[i].setText(HarmonyOwnExercise.transcode(reader.readLine(), transcodingMap));
                            tones[i].setEditable(false);
                        }
                    }
                }

                for(int i=1; i<=30; i++){ //deletes all but bass and chord type
                    tones[i*5-4].setText("");
                    tones[i*5-3].setText("");
                    tones[i*5-2].setText("");
                }

                List<String> basses = new ArrayList<String>();
                for(int i=1; i<=30; i++){
                    if(!tones[i*5-1].getText().equals("")){
                        basses.add(tones[i*5-1].getText());
                    }
                }
                List<ChordType> types = new ArrayList<ChordType>();
                for(int i=1; i<=30; i++){
                    if(!tones[i*5-1].getText().equals("")){
                        types.add(ChordType.getType(tones[i*5].getText()));
                    }
                }
                exercise = new Exercise(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("<ZO SÚBORU>"), Key.getKey(keyString), basses, types);
                if(!exercise.isValid()){
                    throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE ULOŽENÉ V SÚBORE NIE JE KOREKTNÉ. OPRAVTE HO A SKÚSTE TO ZNOVU."));
                }

                keyLabel.setText(keyString);
                exerciseChoice.setEnabled(false);

                toneOmitButton.setVisible(false);
                checkButton.setEnabled(true);
                nextButton.setEnabled(false);
                previousButton.setEnabled(false);

                tones[1].setEditable(true);
                tones[2].setEditable(true);
                tones[3].setEditable(true);
                tones[4].setEditable(false);
                tones[5].setEditable(false);

                column = 1;

                green();
                String message = java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CVIČENIE BOLO ÚSPEŠNE NAČÍTANÉ ZO SÚBORU:")+" "+file +transcodingInfo;
                if(reader.ready()){
                    communication.setText(message+"\n"+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NAČÍTANÝCH BOLO IBA PRVÝCH 30 AKORDOV. PREDVOLENÉ CVIČENIE NEMÁ BYŤ DLHŠIE."));
                }else{
                    communication.setText(message);
                }

                fis.close();
                bis.close();
                reader.close();

            }
        } catch (IllegalStateException ex) {
            red();
            communication.setText(ex.getMessage());
        } catch (Exception ex) {
            red();
            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VYSKYTLA SA CHYBA PRI NAČÍTANÍ SÚBORU."));
        }
    }//GEN-LAST:event_openExerciseActionPerformed

    private void openFileHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openFileHelpActionPerformed
        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE MOŽNÉ OTVORIŤ AKÝKOĽVEK SÚBOR VYTVORENÝ V ODDIELE \"PRAKTICKÉ CVIČENIE\", KTORÝ OBSAHUJE SPRÁVNE ÚDAJE.")+"\n"
                + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZOBRAZÍ SA VŽDY LEN BASOVÝ TÓN A DRUH AKORDU. CVIČENIE NESMIE PRESIAHNUŤ 30 AKORDOV, INAK BUDE SKRÁTENÉ.")+"\n"
                + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PO OTVORENÍ SÚBORU ZANIKÁ MOŽNOSŤ VOĽBY Z PREDVOLENÝCH CVIČENÍ. PRE JEJ ZNOVUPOVOLENIE SA TREBA VRÁTIŤ NA ÚVODNÚ OBRAZOVKU A SPÄŤ."));
    }//GEN-LAST:event_openFileHelpActionPerformed

    private void userGuideMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userGuideMenuItemActionPerformed
        HarmonyView.showUserGuide();
    }//GEN-LAST:event_userGuideMenuItemActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton checkButton;
    private javax.swing.JTextArea communication;
    private javax.swing.JComboBox exerciseChoice;
    private javax.swing.JMenu exerciseMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JTextField junctor0;
    private javax.swing.JTextField junctor1;
    private javax.swing.JLabel keyLabel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JButton nextButton;
    private javax.swing.JMenuItem openExercise;
    private javax.swing.JMenuItem openFileHelp;
    private javax.swing.JButton previousButton;
    private javax.swing.JMenuItem showFirstScreen;
    private javax.swing.JTextField t11;
    private javax.swing.JTextField t12;
    private javax.swing.JTextField t13;
    private javax.swing.JTextField t14;
    private javax.swing.JTextField t15;
    private javax.swing.JTextField t21;
    private javax.swing.JTextField t22;
    private javax.swing.JTextField t23;
    private javax.swing.JTextField t24;
    private javax.swing.JTextField t25;
    private javax.swing.JTextField t31;
    private javax.swing.JTextField t32;
    private javax.swing.JTextField t33;
    private javax.swing.JTextField t34;
    private javax.swing.JTextField t35;
    private javax.swing.JTextField t41;
    private javax.swing.JTextField t42;
    private javax.swing.JTextField t43;
    private javax.swing.JTextField t44;
    private javax.swing.JTextField t45;
    private javax.swing.JTextField t51;
    private javax.swing.JTextField t52;
    private javax.swing.JTextField t53;
    private javax.swing.JTextField t54;
    private javax.swing.JTextField t55;
    private javax.swing.JTextField t61;
    private javax.swing.JTextField t62;
    private javax.swing.JTextField t63;
    private javax.swing.JTextField t64;
    private javax.swing.JTextField t65;
    private javax.swing.JTextField t71;
    private javax.swing.JTextField t72;
    private javax.swing.JTextField t73;
    private javax.swing.JTextField t74;
    private javax.swing.JTextField t75;
    private javax.swing.JTextField t81;
    private javax.swing.JTextField t82;
    private javax.swing.JTextField t83;
    private javax.swing.JTextField t84;
    private javax.swing.JTextField t85;
    private javax.swing.JTextField t91;
    private javax.swing.JTextField t92;
    private javax.swing.JTextField t93;
    private javax.swing.JTextField t94;
    private javax.swing.JTextField t95;
    private javax.swing.JTextField ta1;
    private javax.swing.JTextField ta2;
    private javax.swing.JTextField ta3;
    private javax.swing.JTextField ta4;
    private javax.swing.JTextField ta5;
    private javax.swing.JTextField tb1;
    private javax.swing.JTextField tb2;
    private javax.swing.JTextField tb3;
    private javax.swing.JTextField tb4;
    private javax.swing.JTextField tb5;
    private javax.swing.JTextField tc1;
    private javax.swing.JTextField tc2;
    private javax.swing.JTextField tc3;
    private javax.swing.JTextField tc4;
    private javax.swing.JTextField tc5;
    private javax.swing.JTextField td1;
    private javax.swing.JTextField td2;
    private javax.swing.JTextField td3;
    private javax.swing.JTextField td4;
    private javax.swing.JTextField td5;
    private javax.swing.JTextField te1;
    private javax.swing.JTextField te2;
    private javax.swing.JTextField te3;
    private javax.swing.JTextField te4;
    private javax.swing.JTextField te5;
    private javax.swing.JTextField tf1;
    private javax.swing.JTextField tf2;
    private javax.swing.JTextField tf3;
    private javax.swing.JTextField tf4;
    private javax.swing.JTextField tf5;
    private javax.swing.JTextField tg1;
    private javax.swing.JTextField tg2;
    private javax.swing.JTextField tg3;
    private javax.swing.JTextField tg4;
    private javax.swing.JTextField tg5;
    private javax.swing.JTextField th1;
    private javax.swing.JTextField th2;
    private javax.swing.JTextField th3;
    private javax.swing.JTextField th4;
    private javax.swing.JTextField th5;
    private javax.swing.JTextField ti1;
    private javax.swing.JTextField ti2;
    private javax.swing.JTextField ti3;
    private javax.swing.JTextField ti4;
    private javax.swing.JTextField ti5;
    private javax.swing.JTextField tj1;
    private javax.swing.JTextField tj2;
    private javax.swing.JTextField tj3;
    private javax.swing.JTextField tj4;
    private javax.swing.JTextField tj5;
    private javax.swing.JTextField tk1;
    private javax.swing.JTextField tk2;
    private javax.swing.JTextField tk3;
    private javax.swing.JTextField tk4;
    private javax.swing.JTextField tk5;
    private javax.swing.JTextField tl1;
    private javax.swing.JTextField tl2;
    private javax.swing.JTextField tl3;
    private javax.swing.JTextField tl4;
    private javax.swing.JTextField tl5;
    private javax.swing.JTextField tm1;
    private javax.swing.JTextField tm2;
    private javax.swing.JTextField tm3;
    private javax.swing.JTextField tm4;
    private javax.swing.JTextField tm5;
    private javax.swing.JTextField tn1;
    private javax.swing.JTextField tn2;
    private javax.swing.JTextField tn3;
    private javax.swing.JTextField tn4;
    private javax.swing.JTextField tn5;
    private javax.swing.JTextField to1;
    private javax.swing.JTextField to2;
    private javax.swing.JTextField to3;
    private javax.swing.JTextField to4;
    private javax.swing.JTextField to5;
    private javax.swing.JMenuItem toneInputHelp;
    private javax.swing.JButton toneOmitButton;
    private javax.swing.JTextField tp1;
    private javax.swing.JTextField tp2;
    private javax.swing.JTextField tp3;
    private javax.swing.JTextField tp4;
    private javax.swing.JTextField tp5;
    private javax.swing.JTextField tr1;
    private javax.swing.JTextField tr2;
    private javax.swing.JTextField tr3;
    private javax.swing.JTextField tr4;
    private javax.swing.JTextField tr5;
    private javax.swing.JTextField ts1;
    private javax.swing.JTextField ts2;
    private javax.swing.JTextField ts3;
    private javax.swing.JTextField ts4;
    private javax.swing.JTextField ts5;
    private javax.swing.JTextField tt1;
    private javax.swing.JTextField tt2;
    private javax.swing.JTextField tt3;
    private javax.swing.JTextField tt4;
    private javax.swing.JTextField tt5;
    private javax.swing.JTextField tu1;
    private javax.swing.JTextField tu2;
    private javax.swing.JTextField tu3;
    private javax.swing.JTextField tu4;
    private javax.swing.JTextField tu5;
    private javax.swing.JTextField tv1;
    private javax.swing.JTextField tv2;
    private javax.swing.JTextField tv3;
    private javax.swing.JTextField tv4;
    private javax.swing.JTextField tv5;
    // End of variables declaration//GEN-END:variables

    private JDialog aboutBox;
    private FrameView superFrame;

    //by default there should be no omitted tones in chord
    OmitErrors omit = new OmitErrors(false, false, false, false, false, false, false, false, false);

    private JTextField[] tones = new JTextField[151];
    private int[] eachFive = {1,6,11,16,21,26,31,36,41,46,51,56,61,66,71,
    76,81,86,91,96,101,106,111,116,121,126,131,136,141,146};

    private DatabaseOfExercises database = new DatabaseOfExercises();
    private Boolean defaultDeleted = false;
    private Exercise exercise;
    private int firstInvalidExercise = 0;

    //actual column
    private int column = 1;

    private String getDefaultExercise(){
        return database.getExcercise(0).getName();
    }
    
    /** Sets console colour to green*/
    private void green(){
        communication.setForeground(Color.getHSBColor((float)0.29, (float)0.6, (float)0.5));
    }

    /** Sets console colour to red*/
    private void red(){
        communication.setForeground(Color.getHSBColor((float)0, (float)0.6, (float)0.5));
    }

    /** Moves to next column*/
    private void next(){
        tones[eachFive[column-1]].setEditable(false);
        tones[eachFive[column-1]+1].setEditable(false);
        tones[eachFive[column-1]+2].setEditable(false);
        column++;
        tones[eachFive[column-1]].setEditable(true);
        tones[eachFive[column-1]+1].setEditable(true);
        tones[eachFive[column-1]+2].setEditable(true);
    }

    /** Moves to previous column*/
    private void previous(){
        tones[eachFive[column-1]].setEditable(false);
        tones[eachFive[column-1]+1].setEditable(false);
        tones[eachFive[column-1]+2].setEditable(false);
        column--;
        tones[eachFive[column-1]].setEditable(true);
        tones[eachFive[column-1]+1].setEditable(true);
        tones[eachFive[column-1]+2].setEditable(true);
    }

    private String inputToneFormat(){
        return java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE MOŽNÉ ZADÁVAŤ TÓNY OD")+" "+java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("C")
                    +" "+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("DO")+" "+java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c,,,")+"\n"
                    + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PRÍKLAD SPRÁVNE ZADANÝCH TÓNOV:")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,,");
    }

    public void eraseBoxes(){
        for(int i=1; i<=150; i++){
            tones[i].setText("");
        }
    }

}
