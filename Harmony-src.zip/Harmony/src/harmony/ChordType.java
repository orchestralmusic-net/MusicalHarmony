/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public enum ChordType {

    _5, _a, _5a, _6, _64, _53, _6a4, _7, _65, _43, _2, _8;

    public boolean chromatic;
    private static boolean nowChromatic; //this is just helper; do not export it

    /**Returns array consisting of 3 elements, in which first is third of chord, second is fifth of chord
     * and third of the array is seventh of the chord. If its triad, then this last element is -1*/
    public Integer[] getChordParameters(Key key, Integer ground) throws GroundNotSupportedException{

        Integer[] p = new Integer[4];

        if (getChordType(key, ground) == DurMoll.DUR){

            switch (this){

            case _5: {p[1]=4; p[2]=7; p[3]=-1; return p;}
            case _a: {p[1]=5; p[2]=7; p[3]=-1; return p;}
            case _5a: {p[1]=4; p[2]=8; p[3]=-1; return p;}
            case _6: {p[1]=3; p[2]=8; p[3]=-1; return p;}
            case _64: {p[1]=5; p[2]=9; p[3]=-1; return p;}
            case _53: {p[1]=4; p[2]=7; p[3]=-1; return p;}
            case _6a4: {p[1]=5; p[2]=10; p[3]=-1; return p;}
            case _7: {p[1]=4; p[2]=7; p[3]=10; return p;}
            case _65: {p[1]=3; p[2]=6; p[3]=8; return p;}
            case _43: {p[1]=3; p[2]=5; p[3]=9; return p;}
            case _2: {p[1]=2; p[2]=6; p[3]=9; return p;}
            case _8: {p[1]=4; p[2]=7; p[3]=12; return p;}

            }
            
        }

        if (getChordType(key, ground) == DurMoll.MOLL){

            switch (this){

            case _5: {p[1]=3; p[2]=7; p[3]=-1; return p;}
            case _a: {p[1]=4; p[2]=7; p[3]=-1; return p;}
            case _5a: {p[1]=3; p[2]=8; p[3]=-1; return p;}      
            case _6: {p[1]=4; p[2]=9; p[3]=-1; return p;}
            case _64: {p[1]=5; p[2]=8; p[3]=-1; return p;}
            case _53: {p[1]=3; p[2]=7; p[3]=-1; return p;}
            case _6a4: {p[1]=5; p[2]=9; p[3]=-1; return p;}
            case _7: {p[1]=3; p[2]=7; p[3]=10; return p;}
            case _65: {p[1]=4; p[2]=7; p[3]=9; return p;}
            case _43: {p[1]=3; p[2]=5; p[3]=8; return p;}
            case _2: {p[1]=2; p[2]=5; p[3]=9; return p;}
            case _8: {p[1]=3; p[2]=7; p[3]=12; return p;}

            }

        }

        if (getChordType(key, ground) == DurMoll.DIMINISHED){

            switch (this){

            case _5: {p[1]=3; p[2]=6; p[3]=-1; return p;}
            case _a: {p[1]=4; p[2]=6; p[3]=-1; return p;}
            case _5a: {p[1]=3; p[2]=7; p[3]=-1; return p;}
            case _6: {p[1]=3; p[2]=9; p[3]=-1; return p;}
            case _64: {p[1]=6; p[2]=9; p[3]=-1; return p;}
            case _53: {p[1]=5; p[2]=7; p[3]=-1; return p;}
            case _6a4: {p[1]=5; p[2]=10; p[3]=-1; return p;}
            case _7: {p[1]=3; p[2]=6; p[3]=10; return p;}
            case _65: {p[1]=3; p[2]=7; p[3]=9; return p;}
            case _43: {p[1]=4; p[2]=6; p[3]=9; return p;}
            case _2: {p[1]=2; p[2]=5; p[3]=8; return p;}
            case _8: {p[1]=3; p[2]=6; p[3]=12; return p;}

            }

        }

        return p;

    }

    public DurMoll getChordType(Key key, Integer ground) throws GroundNotSupportedException{

        if (key.isDurOrMoll()==DurMoll.DUR && getChordPosition(key, ground)==ChordPosition.T){
            return DurMoll.DUR;
        }else if (key.isDurOrMoll()==DurMoll.DUR && getChordPosition(key, ground)==ChordPosition.II){
            return DurMoll.MOLL;
        }else if (key.isDurOrMoll()==DurMoll.DUR && getChordPosition(key, ground)==ChordPosition.III){
            return DurMoll.MOLL;
        }else if (key.isDurOrMoll()==DurMoll.DUR && getChordPosition(key, ground)==ChordPosition.S){
            return DurMoll.DUR;
        }else if (key.isDurOrMoll()==DurMoll.DUR && getChordPosition(key, ground)==ChordPosition.D){
            return DurMoll.DUR;
        }else if (key.isDurOrMoll()==DurMoll.DUR && getChordPosition(key, ground)==ChordPosition.VI){
            return DurMoll.MOLL;
        }else if (key.isDurOrMoll()==DurMoll.DUR && getChordPosition(key, ground)==ChordPosition.VII){
            return DurMoll.DIMINISHED;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && getChordPosition(key, ground)==ChordPosition.T){
            return DurMoll.MOLL;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && getChordPosition(key, ground)==ChordPosition.II){
            return DurMoll.DIMINISHED;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && getChordPosition(key, ground)==ChordPosition.III){
            return DurMoll.DUR;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && getChordPosition(key, ground)==ChordPosition.S){
            return DurMoll.MOLL;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && getChordPosition(key, ground)==ChordPosition.D){
            return DurMoll.MOLL;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && getChordPosition(key, ground)==ChordPosition.VI){
            return DurMoll.DUR;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && getChordPosition(key, ground)==ChordPosition.VII){
            return DurMoll.DUR;
        }else{
            throw new GroundNotSupportedException("Zadaný basový tón je mimo zvolenú tóninu.");
        }

    }


    public ChordPosition getChordPosition(Key key, Integer ground) throws GroundNotSupportedException{

        ChordPosition unshifted;

        if (key.isDurOrMoll()==DurMoll.DUR && ((ground+48)%12==(0+key.getGroundTone())%12)){
            unshifted = ChordPosition.T;
        }else if (key.isDurOrMoll()==DurMoll.DUR && ((ground+48)%12==(2+key.getGroundTone())%12)){
            unshifted = ChordPosition.II;
        }else if (key.isDurOrMoll()==DurMoll.DUR && ((ground+48)%12==(4+key.getGroundTone())%12)){
            unshifted = ChordPosition.III;
        }else if (key.isDurOrMoll()==DurMoll.DUR && ((ground+48)%12==(5+key.getGroundTone())%12)){
            unshifted = ChordPosition.S;
        }else if (key.isDurOrMoll()==DurMoll.DUR && ((ground+48)%12==(7+key.getGroundTone())%12)){
            unshifted = ChordPosition.D;
        }else if (key.isDurOrMoll()==DurMoll.DUR && ((ground+48)%12==(9+key.getGroundTone())%12)){
            unshifted = ChordPosition.VI;
        }else if (key.isDurOrMoll()==DurMoll.DUR && ((ground+48)%12==(11+key.getGroundTone())%12)){
            unshifted = ChordPosition.VII;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && ((ground+48)%12==(0+key.getGroundTone())%12)){
            unshifted = ChordPosition.T;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && ((ground+48)%12==(2+key.getGroundTone())%12)){
            unshifted = ChordPosition.II;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && ((ground+48)%12==(3+key.getGroundTone())%12)){
            unshifted = ChordPosition.III;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && ((ground+48)%12==(5+key.getGroundTone())%12)){
            unshifted = ChordPosition.S;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && ((ground+48)%12==(7+key.getGroundTone())%12)){
            unshifted = ChordPosition.D;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && ((ground+48)%12==(8+key.getGroundTone())%12)){
            unshifted = ChordPosition.VI;
        }else if (key.isDurOrMoll()==DurMoll.MOLL && ((ground+48)%12==(10+key.getGroundTone())%12)){
            unshifted = ChordPosition.VII;
        }else{
            throw new GroundNotSupportedException("Zadaný basový tón je mimo zvolenú tóninu.");
        }

        //if there is a shift
        switch (this){

            case _6: {return unshifted.shiftPosition(-2);}
            case _64: {return unshifted.shiftPosition(-4);}
            case _53: {return unshifted.shiftPosition(-4);}
            case _6a4: {return unshifted.shiftPosition(-4);}
            case _65: {return unshifted.shiftPosition(-2);}
            case _43: {return unshifted.shiftPosition(-4);}
            case _2: {return unshifted.shiftPosition(-6);}

        }

        //if there isnt any shift
        return unshifted;

    }


    /**Tests whether the chord is primary, that means tonic, subdominant or dominant.*/
    public boolean isPrimaryChord(Key key, Integer ground) throws GroundNotSupportedException{
        if(key.isDurOrMoll()==getChordType(key, ground)){
            return true;
        }else{
            return false;
        }
    }


    public Boolean isTriad(){

        switch (this){

            case _5: return true;
            case _a: return true;
            case _5a: return true;
            case _6: return true;
            case _64: return true;
            case _53: return true;
            case _6a4: return true;
            case _7: return false;
            case _65: return false;
            case _43: return false;
            case _2: return false;
            case _8: return false;

        }

        return null;

    }


     public Boolean isTriadWithoutInversion(){

        switch (this){

            case _5: return true;
            case _a: return true;
            case _5a: return true;
            case _6: return false;
            case _64: return false;
            case _53: return false;
            case _6a4: return false;
            case _7: return false;
            case _65: return false;
            case _43: return false;
            case _2: return false;
            case _8: return false;

        }

        return null;

    }


    public Boolean isTriadFirstInversion(){

        switch (this){

            case _5: return false;
            case _a: return false;
            case _5a: return false;
            case _6: return true;
            case _64: return false;
            case _53: return false;
            case _6a4: return false;
            case _7: return false;
            case _65: return false;
            case _43: return false;
            case _2: return false;
            case _8: return false;

        }

        return null;

    }


    public Boolean isTriadSecondInversion(){

        switch (this){

            case _5: return false;
            case _a: return false;
            case _5a: return false;
            case _6: return false;
            case _64: return true;
            case _53: return true;
            case _6a4: return true;
            case _7: return false;
            case _65: return false;
            case _43: return false;
            case _2: return false;
            case _8: return false;

        }

        return null;

    }


    @Override
    public String toString(){

        switch (this){

            case _5: return "5";
            case _a: return "#";
            case _5a: return "5#";
            case _6: return "6";
            case _64: return "64";
            case _53: return "53";
            case _6a4: return "6#4";
            case _7: return "7";
            case _65: return "65";
            case _43: return "43";
            case _2: return "2";
            case _8: return "8";

        }

        return "interná chyba programu 2";

    }


    public static ChordType getType(String text) {

        if(text.endsWith("o") && !text.endsWith("oo")){
            return getType(text.substring(0, text.lastIndexOf("o")));
        }

        if(text.startsWith("ch")){
            nowChromatic = true;
            return getType(text.substring(2));
        }

        ChordType result;

        if(text.equals("5")){
            result = _5;
        }else if(text.equals("#")){
            result = _a;
        }else if(text.equals("5#")){
            result = _5a;
        }else if(text.equals("6")){
            result = _6;
        }else if(text.equals("64")){
            result = _64;
        }else if(text.equals("53")){
            result = _53;
        }else if(text.equals("6#4")){
            result = _6a4;
        }else if(text.equals("7")){
            result = _7;
        }else if(text.equals("65")){
            result = _65;
        }else if(text.equals("43")){
            result = _43;
        }else if(text.equals("2")){
            result = _2;
        }else if(text.equals("8")){
            result = _8;
        }else{
            result = null;
        }

        if(nowChromatic && result!=null){ //needed for recursively invoking chromatic chords
            result.setChromatic(true);
        }
        if(result!=null){
            result.setChromatic(false);
        }
        nowChromatic = false;

        return result;
    }


    public static boolean containsOmit(String chordText){

        if(chordText.endsWith("o")){
            return true;
        }else{
            return false;
        }

    }


    public static boolean containsChromatics(String chordText){

        if(chordText.startsWith("ch")){
            return true;
        }else{
            return false;
        }

    }


    public boolean isChromatic(){
        return chromatic;
    }


    public void setChromatic(boolean isChromatic){
        this.chromatic = isChromatic;
    }

}
