/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

/**
 *
 * @author Dominik Kruppa
 */
public class KeyList extends AbstractListModel implements ComboBoxModel {

    private List<Key> keys = new ArrayList<Key>();
    private String selection = null;

    public KeyList(){

        keys.addAll(Arrays.asList(Key.empty,Key.C, Key.G, Key.D, Key.A, Key.E, Key.H, Key.Fis, Key.Cis,
                Key.F, Key.B, Key.Es, Key.As, Key.Des, Key.Ges, Key.Ces, Key.a, Key.e, Key.h,
                Key.fis, Key.cis, Key.gis, Key.dis, Key.ais, Key.d, Key.g, Key.c, Key.f, Key.b, Key.es, Key.as));

    }

    public Key getKey(Integer numberOfKey){

        return keys.get(numberOfKey);

    }

    public void removeFirstKey(){

        keys.remove(0);

    }

    public Object getElementAt(int index) {

        return keys.get(index).getInfo();

  }

    public int getSize() {

        return keys.size();

  }

    public void setSelectedItem(Object anItem) {

        selection = (String) anItem;

  }


    public Object getSelectedItem() {

        return selection;

  }

    public Integer getIndex(Key key){

        return keys.indexOf(key);

    }
}
