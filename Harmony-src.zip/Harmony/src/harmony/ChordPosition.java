/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public enum ChordPosition {

    T, II, III, S, D, VI, VII;

    public ChordPosition shiftPosition(int value){

        return this.getPosition(getValue() + value);
        
    }


    private Integer getValue(){

        switch (this){

            case T: return 0;
            case II: return 1;
            case III: return 2;
            case S: return 3;
            case D: return 4;
            case VI: return 5;
            case VII: return 6;

        }

        return null;

    }


    private ChordPosition getPosition(int value){

        if (value >= 0){

            switch (value % 7){

                case 0: return T;
                case 1: return II;
                case 2: return III;
                case 3: return S;
                case 4: return D;
                case 5: return VI;
                case 6: return VII;

            }
        }

        if (value < 0){

            switch (Math.abs(value) % 7){

                case 0: return T;
                case 1: return VII;
                case 2: return VI;
                case 3: return D;
                case 4: return S;
                case 5: return III;
                case 6: return II;

            }
        }

        return null;

    }


    @Override
    public String toString(){

        switch (this){

            case T: return "T";
            case II: return "II";
            case III: return "III";
            case S: return "S";
            case D: return "D";
            case VI: return "VI";
            case VII: return "VII";

        }

        return "interná chyba programu 6";

    }

}
