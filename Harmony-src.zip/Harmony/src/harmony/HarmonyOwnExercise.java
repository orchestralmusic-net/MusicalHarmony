/*
 * HarmonyView.java
 */

package harmony;

import java.awt.Color;
import java.awt.Dimension;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.SortedSet;
import java.util.TreeSet;
import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

/**
 * The application's main frame.
 */
public class HarmonyOwnExercise extends FrameView {

    public HarmonyOwnExercise(SingleFrameApplication app, HarmonyView hv, Key key, boolean threeVoices, HarmonyOwnExercise previousFrame, int numberOfFrame) {
        super(app);

        superFrame = hv;

        //sets frame title
        getFrame().setTitle(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + "HarmonyView").getString("HARMÓNIA"));

        this.previousFrame = previousFrame;
        this.numberOfFrame = numberOfFrame;
        frames.add(this);

        initComponents();

        this.getFrame().setMinimumSize(new Dimension(800, 400));

        if(this.previousFrame==null){
            this.getFrame().addWindowListener(listenerWithoutConfirmation);
        }else{
             this.getFrame().addWindowListener(new WindowAdapter() {
                @Override
                 public void windowClosing(WindowEvent e) {
                    if(!hasNextFrame()){
                        getPreviousFrame().closeAllNextFrames();
                    }else{
                        if(JOptionPane.showConfirmDialog(e.getComponent(),
                                           java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZATVORENIE TOHTO OKNA ZATVORÍ AJ VŠETKY OKNÁ NAŇ NADVÄZUJÚCE. PRAJETE SI TOTO?"),
                                           java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("POTVRDIŤ ZATVORENIE VIACERÝCH OKIEN"), 0) == 0){
                                getPreviousFrame().closeAllNextFrames();
                        }
                    }
                    getPreviousFrame().activateFrame();
                    getPreviousFrame().activateCurrentChord();
                    getPreviousFrame().getFrame().toFront();
                 }
             });
        }

        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZVOĽTE NIEKTORÚ Z TÓNIN."));


        //tones[0] will non be used
        tones[1]=t11;
        tones[2]=t12;
        tones[3]=t13;
        tones[4]=t14;
        tones[5]=t15;
        tones[6]=t21;
        tones[7]=t22;
        tones[8]=t23;
        tones[9]=t24;
        tones[10]=t25;
        tones[11]=t31;
        tones[12]=t32;
        tones[13]=t33;
        tones[14]=t34;
        tones[15]=t35;
        tones[16]=t41;
        tones[17]=t42;
        tones[18]=t43;
        tones[19]=t44;
        tones[20]=t45;
        tones[21]=t51;
        tones[22]=t52;
        tones[23]=t53;
        tones[24]=t54;
        tones[25]=t55;
        tones[26]=t61;
        tones[27]=t62;
        tones[28]=t63;
        tones[29]=t64;
        tones[30]=t65;
        tones[31]=t71;
        tones[32]=t72;
        tones[33]=t73;
        tones[34]=t74;
        tones[35]=t75;
        tones[36]=t81;
        tones[37]=t82;
        tones[38]=t83;
        tones[39]=t84;
        tones[40]=t85;
        tones[41]=t91;
        tones[42]=t92;
        tones[43]=t93;
        tones[44]=t94;
        tones[45]=t95;
        tones[46]=ta1;
        tones[47]=ta2;
        tones[48]=ta3;
        tones[49]=ta4;
        tones[50]=ta5;
        tones[51]=tb1;
        tones[52]=tb2;
        tones[53]=tb3;
        tones[54]=tb4;
        tones[55]=tb5;
        tones[56]=tc1;
        tones[57]=tc2;
        tones[58]=tc3;
        tones[59]=tc4;
        tones[60]=tc5;
        tones[61]=td1;
        tones[62]=td2;
        tones[63]=td3;
        tones[64]=td4;
        tones[65]=td5;
        tones[66]=te1;
        tones[67]=te2;
        tones[68]=te3;
        tones[69]=te4;
        tones[70]=te5;
        tones[71]=tf1;
        tones[72]=tf2;
        tones[73]=tf3;
        tones[74]=tf4;
        tones[75]=tf5;
        tones[76]=tg1;
        tones[77]=tg2;
        tones[78]=tg3;
        tones[79]=tg4;
        tones[80]=tg5;
        tones[81]=th1;
        tones[82]=th2;
        tones[83]=th3;
        tones[84]=th4;
        tones[85]=th5;
        tones[86]=ti1;
        tones[87]=ti2;
        tones[88]=ti3;
        tones[89]=ti4;
        tones[90]=ti5;
        tones[91]=tj1;
        tones[92]=tj2;
        tones[93]=tj3;
        tones[94]=tj4;
        tones[95]=tj5;
        tones[96]=tk1;
        tones[97]=tk2;
        tones[98]=tk3;
        tones[99]=tk4;
        tones[100]=tk5;
        tones[101]=tl1;
        tones[102]=tl2;
        tones[103]=tl3;
        tones[104]=tl4;
        tones[105]=tl5;
        tones[106]=tm1;
        tones[107]=tm2;
        tones[108]=tm3;
        tones[109]=tm4;
        tones[110]=tm5;
        tones[111]=tn1;
        tones[112]=tn2;
        tones[113]=tn3;
        tones[114]=tn4;
        tones[115]=tn5;
        tones[116]=to1;
        tones[117]=to2;
        tones[118]=to3;
        tones[119]=to4;
        tones[120]=to5;
        tones[121]=tp1;
        tones[122]=tp2;
        tones[123]=tp3;
        tones[124]=tp4;
        tones[125]=tp5;
        tones[126]=tr1;
        tones[127]=tr2;
        tones[128]=tr3;
        tones[129]=tr4;
        tones[130]=tr5;
        tones[131]=ts1;
        tones[132]=ts2;
        tones[133]=ts3;
        tones[134]=ts4;
        tones[135]=ts5;
        tones[136]=tt1;
        tones[137]=tt2;
        tones[138]=tt3;
        tones[139]=tt4;
        tones[140]=tt5;
        tones[141]=tu1;
        tones[142]=tu2;
        tones[143]=tu3;
        tones[144]=tu4;
        tones[145]=tu5;
        tones[146]=tv1;
        tones[147]=tv2;
        tones[148]=tv3;
        tones[149]=tv4;
        tones[150]=tv5;

        //at start is nothing to edit until is selected a exercise
        for (int i = 1; i<151; i++){
            tones[i].setEditable(false);
        }

        MouseAdapter mouseAdapter = new MouseAdapter() {
                                            @Override
                     public void mouseEntered(MouseEvent e) {e.getComponent().requestFocusInWindow();}};
        for(int i=1; i<=150; i++){
            tones[i].addMouseListener(mouseAdapter);
        }

        activateCheckMenu();
        checkButton.setEnabled(false);
        nextButton.setEnabled(false);
        previousButton.setEnabled(false);
        chromaticsButton.setEnabled(false);
        countButton.setEnabled(false);
        toneOmitButton.setVisible(false);
        errorOmitButton.setVisible(false);

        //junctors should never be editable
        junctor0.setEditable(false);
        junctor1.setEditable(false);

        if(key!=null){
            this.key=key;
            keyChoice.setSelectedIndex(keys.getIndex(key));
            keyChoiceActionPerformed(null);
        }

        if(threeVoices){
            threeVoiceMode.setState(true);
            threeVoiceModeActionPerformed(null);
        }

        if(numberOfFrame!=1){
            exerciseLabel.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VLASTNÁ SKLADBA (")+numberOfFrame+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString(". ČASŤ)"));
        }

        this.getComponent().getInputMap(0).put(KeyStroke.getKeyStroke("ENTER"),
                            "enter");
        this.getComponent().getInputMap(1).put(KeyStroke.getKeyStroke("ENTER"),
                            "enter");
        this.getComponent().getInputMap(2).put(KeyStroke.getKeyStroke("ENTER"),
                            "enter");
        this.getComponent().getActionMap().put("enter",
                             pressCheckButton);
        this.getComponent().getInputMap(0).put(KeyStroke.getKeyStroke("RIGHT"),
                            "next");
        this.getComponent().getInputMap(1).put(KeyStroke.getKeyStroke("RIGHT"),
                            "next");
        this.getComponent().getInputMap(2).put(KeyStroke.getKeyStroke("RIGHT"),
                            "next");
        this.getComponent().getActionMap().put("next",
                             pressNextButton);
        this.getComponent().getInputMap(0).put(KeyStroke.getKeyStroke("LEFT"),
                            "previous");
        this.getComponent().getInputMap(1).put(KeyStroke.getKeyStroke("LEFT"),
                            "previous");
        this.getComponent().getInputMap(2).put(KeyStroke.getKeyStroke("LEFT"),
                            "previous");
        this.getComponent().getActionMap().put("previous",
                             pressPreviousButton);
        this.getComponent().getInputMap(0).put(KeyStroke.getKeyStroke("END"),
                            "chromatics");
        this.getComponent().getInputMap(1).put(KeyStroke.getKeyStroke("END"),
                            "chromatics");
        this.getComponent().getInputMap(2).put(KeyStroke.getKeyStroke("END"),
                            "chromatics");
        this.getComponent().getActionMap().put("chromatics",
                             pressChromaticsButton);

        //translation of JFileChooser
        UIManager.getDefaults().addResourceBundle("harmony/resources/" + Translation.getLanguage() + "/" + "FileDialog");

    }


    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        checkButton = new javax.swing.JButton();
        exerciseLabel = new javax.swing.JLabel();
        keyChoice = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        communication = new javax.swing.JTextArea();
        t11 = new javax.swing.JTextField();
        t12 = new javax.swing.JTextField();
        t13 = new javax.swing.JTextField();
        t14 = new javax.swing.JTextField();
        t15 = new javax.swing.JTextField();
        t21 = new javax.swing.JTextField();
        t22 = new javax.swing.JTextField();
        t23 = new javax.swing.JTextField();
        t24 = new javax.swing.JTextField();
        t25 = new javax.swing.JTextField();
        t31 = new javax.swing.JTextField();
        t32 = new javax.swing.JTextField();
        t33 = new javax.swing.JTextField();
        t34 = new javax.swing.JTextField();
        t35 = new javax.swing.JTextField();
        t41 = new javax.swing.JTextField();
        t42 = new javax.swing.JTextField();
        t43 = new javax.swing.JTextField();
        t44 = new javax.swing.JTextField();
        t45 = new javax.swing.JTextField();
        t51 = new javax.swing.JTextField();
        t52 = new javax.swing.JTextField();
        t53 = new javax.swing.JTextField();
        t54 = new javax.swing.JTextField();
        t55 = new javax.swing.JTextField();
        t61 = new javax.swing.JTextField();
        t62 = new javax.swing.JTextField();
        t63 = new javax.swing.JTextField();
        t64 = new javax.swing.JTextField();
        t65 = new javax.swing.JTextField();
        t71 = new javax.swing.JTextField();
        t72 = new javax.swing.JTextField();
        t73 = new javax.swing.JTextField();
        t74 = new javax.swing.JTextField();
        t75 = new javax.swing.JTextField();
        t81 = new javax.swing.JTextField();
        t82 = new javax.swing.JTextField();
        t83 = new javax.swing.JTextField();
        t84 = new javax.swing.JTextField();
        t85 = new javax.swing.JTextField();
        t91 = new javax.swing.JTextField();
        t92 = new javax.swing.JTextField();
        t93 = new javax.swing.JTextField();
        t94 = new javax.swing.JTextField();
        t95 = new javax.swing.JTextField();
        ta1 = new javax.swing.JTextField();
        ta2 = new javax.swing.JTextField();
        ta3 = new javax.swing.JTextField();
        ta4 = new javax.swing.JTextField();
        ta5 = new javax.swing.JTextField();
        tb1 = new javax.swing.JTextField();
        tb2 = new javax.swing.JTextField();
        tb3 = new javax.swing.JTextField();
        tb4 = new javax.swing.JTextField();
        tb5 = new javax.swing.JTextField();
        tc1 = new javax.swing.JTextField();
        tc2 = new javax.swing.JTextField();
        tc3 = new javax.swing.JTextField();
        tc4 = new javax.swing.JTextField();
        tc5 = new javax.swing.JTextField();
        td1 = new javax.swing.JTextField();
        td2 = new javax.swing.JTextField();
        td3 = new javax.swing.JTextField();
        td4 = new javax.swing.JTextField();
        td5 = new javax.swing.JTextField();
        te1 = new javax.swing.JTextField();
        te2 = new javax.swing.JTextField();
        te3 = new javax.swing.JTextField();
        te4 = new javax.swing.JTextField();
        te5 = new javax.swing.JTextField();
        tf1 = new javax.swing.JTextField();
        tf2 = new javax.swing.JTextField();
        tf3 = new javax.swing.JTextField();
        tf4 = new javax.swing.JTextField();
        tf5 = new javax.swing.JTextField();
        tg1 = new javax.swing.JTextField();
        tg2 = new javax.swing.JTextField();
        tg3 = new javax.swing.JTextField();
        tg4 = new javax.swing.JTextField();
        tg5 = new javax.swing.JTextField();
        th1 = new javax.swing.JTextField();
        th2 = new javax.swing.JTextField();
        th3 = new javax.swing.JTextField();
        th4 = new javax.swing.JTextField();
        th5 = new javax.swing.JTextField();
        ti1 = new javax.swing.JTextField();
        ti2 = new javax.swing.JTextField();
        ti3 = new javax.swing.JTextField();
        ti4 = new javax.swing.JTextField();
        ti5 = new javax.swing.JTextField();
        tj1 = new javax.swing.JTextField();
        tj2 = new javax.swing.JTextField();
        tj3 = new javax.swing.JTextField();
        tj4 = new javax.swing.JTextField();
        tj5 = new javax.swing.JTextField();
        tk1 = new javax.swing.JTextField();
        tk2 = new javax.swing.JTextField();
        tk3 = new javax.swing.JTextField();
        tk4 = new javax.swing.JTextField();
        tk5 = new javax.swing.JTextField();
        tl1 = new javax.swing.JTextField();
        tl2 = new javax.swing.JTextField();
        tl3 = new javax.swing.JTextField();
        tl4 = new javax.swing.JTextField();
        tl5 = new javax.swing.JTextField();
        tm1 = new javax.swing.JTextField();
        tm2 = new javax.swing.JTextField();
        tm3 = new javax.swing.JTextField();
        tm4 = new javax.swing.JTextField();
        tm5 = new javax.swing.JTextField();
        tn1 = new javax.swing.JTextField();
        tn2 = new javax.swing.JTextField();
        tn3 = new javax.swing.JTextField();
        tn4 = new javax.swing.JTextField();
        tn5 = new javax.swing.JTextField();
        to1 = new javax.swing.JTextField();
        to2 = new javax.swing.JTextField();
        to3 = new javax.swing.JTextField();
        to4 = new javax.swing.JTextField();
        to5 = new javax.swing.JTextField();
        tp1 = new javax.swing.JTextField();
        tp2 = new javax.swing.JTextField();
        tp3 = new javax.swing.JTextField();
        tp4 = new javax.swing.JTextField();
        tp5 = new javax.swing.JTextField();
        tr1 = new javax.swing.JTextField();
        tr2 = new javax.swing.JTextField();
        tr3 = new javax.swing.JTextField();
        tr4 = new javax.swing.JTextField();
        tr5 = new javax.swing.JTextField();
        ts1 = new javax.swing.JTextField();
        ts2 = new javax.swing.JTextField();
        ts3 = new javax.swing.JTextField();
        ts4 = new javax.swing.JTextField();
        ts5 = new javax.swing.JTextField();
        tt1 = new javax.swing.JTextField();
        tt2 = new javax.swing.JTextField();
        tt3 = new javax.swing.JTextField();
        tt4 = new javax.swing.JTextField();
        tt5 = new javax.swing.JTextField();
        tu1 = new javax.swing.JTextField();
        tu2 = new javax.swing.JTextField();
        tu3 = new javax.swing.JTextField();
        tu4 = new javax.swing.JTextField();
        tu5 = new javax.swing.JTextField();
        tv1 = new javax.swing.JTextField();
        tv2 = new javax.swing.JTextField();
        tv3 = new javax.swing.JTextField();
        tv4 = new javax.swing.JTextField();
        tv5 = new javax.swing.JTextField();
        nextButton = new javax.swing.JButton();
        previousButton = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        junctor0 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        junctor1 = new javax.swing.JTextField();
        countButton = new javax.swing.JButton();
        toneOmitButton = new javax.swing.JButton();
        errorOmitButton = new javax.swing.JButton();
        chromaticsButton = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        alwaysOnTop = new javax.swing.JCheckBoxMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        showFirstScreen = new javax.swing.JMenuItem();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenu exerciseMenu = new javax.swing.JMenu();
        loadExercise = new javax.swing.JMenuItem();
        saveExercise = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        insertChord = new javax.swing.JMenuItem();
        deleteChord = new javax.swing.JMenuItem();
        eraseFromCurrent = new javax.swing.JMenuItem();
        eraseAllFromCurrent = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        searchChord = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        analyseChord = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        threeVoiceMode = new javax.swing.JCheckBoxMenuItem();
        checkMenu = new javax.swing.JMenu();
        otherChord = new javax.swing.JCheckBoxMenuItem();
        omitTone = new javax.swing.JCheckBoxMenuItem();
        toneCrossing = new javax.swing.JCheckBoxMenuItem();
        notAWideHarmony = new javax.swing.JCheckBoxMenuItem();
        leadingToneDoubled = new javax.swing.JCheckBoxMenuItem();
        leadingToneNotResolved = new javax.swing.JCheckBoxMenuItem();
        notCantabile = new javax.swing.JCheckBoxMenuItem();
        parallelEights = new javax.swing.JCheckBoxMenuItem();
        parallelFifths = new javax.swing.JCheckBoxMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        inputToneFormat = new javax.swing.JMenuItem();
        inputChordFormat = new javax.swing.JMenuItem();
        shortcuts = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        javax.swing.JMenuItem userGuideMenuItem = new javax.swing.JMenuItem();

        mainPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        mainPanel.setName("mainPanel"); // NOI18N
        mainPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mainPanelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                mainPanelMouseEntered(evt);
            }
        });

        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()); // NOI18N
        checkButton.setText(bundle.getString("Overiť")); // NOI18N
        checkButton.setName("checkButton"); // NOI18N
        checkButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkButtonActionPerformed(evt);
            }
        });

        exerciseLabel.setText(bundle.getString("Vlastná skladba")); // NOI18N
        exerciseLabel.setName("exerciseLabel"); // NOI18N

        keyChoice.setModel(keys);
        keyChoice.setSelectedItem(getDefaultExercise());
        keyChoice.setName("keyChoice"); // NOI18N
        keyChoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keyChoiceActionPerformed(evt);
            }
        });

        jLabel2.setText(bundle.getString("Tónina:")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N

        jLabel3.setText(bundle.getString("1. tón:")); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N

        jLabel4.setText(bundle.getString("2. tón:")); // NOI18N
        jLabel4.setName("jLabel4"); // NOI18N

        jLabel5.setText(bundle.getString("3. tón:")); // NOI18N
        jLabel5.setName("jLabel5"); // NOI18N

        jLabel6.setText(bundle.getString("4. tón:")); // NOI18N
        jLabel6.setName("jLabel6"); // NOI18N

        jLabel7.setText(bundle.getString(" akord:")); // NOI18N
        jLabel7.setName("jLabel7"); // NOI18N

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(13, 91));
        jScrollPane1.setName("jScrollPane1"); // NOI18N

        communication.setColumns(1);
        communication.setEditable(false);
        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(harmony.HarmonyApp.class).getContext().getResourceMap(HarmonyOwnExercise.class);
        communication.setFont(resourceMap.getFont("communication.font")); // NOI18N
        communication.setRows(5);
        communication.setText(resourceMap.getString("communication.text")); // NOI18N
        communication.setName("communication"); // NOI18N
        jScrollPane1.setViewportView(communication);

        t11.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t11.setText(resourceMap.getString("t11.text")); // NOI18N
        t11.setName("t11"); // NOI18N

        t12.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t12.setName("t12"); // NOI18N

        t13.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t13.setName("t13"); // NOI18N

        t14.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t14.setName("t14"); // NOI18N

        t15.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t15.setName("t15"); // NOI18N

        t21.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t21.setName("t21"); // NOI18N

        t22.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t22.setName("t22"); // NOI18N

        t23.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t23.setName("t23"); // NOI18N

        t24.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t24.setName("t24"); // NOI18N

        t25.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t25.setName("t25"); // NOI18N

        t31.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t31.setName("t31"); // NOI18N

        t32.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t32.setName("t32"); // NOI18N

        t33.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t33.setName("t33"); // NOI18N

        t34.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t34.setName("t34"); // NOI18N

        t35.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t35.setName("t35"); // NOI18N

        t41.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t41.setName("t41"); // NOI18N

        t42.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t42.setName("t42"); // NOI18N

        t43.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t43.setName("t43"); // NOI18N

        t44.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t44.setName("t44"); // NOI18N

        t45.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t45.setName("t45"); // NOI18N

        t51.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t51.setName("t51"); // NOI18N

        t52.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t52.setName("t52"); // NOI18N

        t53.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t53.setName("t53"); // NOI18N

        t54.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t54.setName("t54"); // NOI18N

        t55.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t55.setName("t55"); // NOI18N

        t61.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t61.setName("t61"); // NOI18N

        t62.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t62.setName("t62"); // NOI18N

        t63.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t63.setName("t63"); // NOI18N

        t64.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t64.setName("t64"); // NOI18N

        t65.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t65.setName("t65"); // NOI18N

        t71.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t71.setName("t71"); // NOI18N

        t72.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t72.setName("t72"); // NOI18N

        t73.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t73.setName("t73"); // NOI18N

        t74.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t74.setName("t74"); // NOI18N

        t75.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t75.setName("t75"); // NOI18N

        t81.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t81.setName("t81"); // NOI18N

        t82.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t82.setName("t82"); // NOI18N

        t83.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t83.setName("t83"); // NOI18N

        t84.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t84.setName("t84"); // NOI18N

        t85.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t85.setName("t85"); // NOI18N

        t91.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t91.setName("t91"); // NOI18N

        t92.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t92.setName("t92"); // NOI18N

        t93.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t93.setName("t93"); // NOI18N

        t94.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t94.setName("t94"); // NOI18N

        t95.setFont(resourceMap.getFont("t11.font")); // NOI18N
        t95.setName("t95"); // NOI18N

        ta1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta1.setName("ta1"); // NOI18N

        ta2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta2.setName("ta2"); // NOI18N

        ta3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta3.setName("ta3"); // NOI18N

        ta4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta4.setName("ta4"); // NOI18N

        ta5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ta5.setName("ta5"); // NOI18N

        tb1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb1.setName("tb1"); // NOI18N

        tb2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb2.setName("tb2"); // NOI18N

        tb3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb3.setName("tb3"); // NOI18N

        tb4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb4.setName("tb4"); // NOI18N

        tb5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tb5.setName("tb5"); // NOI18N

        tc1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc1.setName("tc1"); // NOI18N

        tc2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc2.setName("tc2"); // NOI18N

        tc3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc3.setName("tc3"); // NOI18N

        tc4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc4.setName("tc4"); // NOI18N

        tc5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tc5.setName("tc5"); // NOI18N

        td1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td1.setName("td1"); // NOI18N

        td2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td2.setName("td2"); // NOI18N

        td3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td3.setName("td3"); // NOI18N

        td4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td4.setName("td4"); // NOI18N

        td5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        td5.setName("td5"); // NOI18N

        te1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te1.setName("te1"); // NOI18N

        te2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te2.setName("te2"); // NOI18N

        te3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te3.setName("te3"); // NOI18N

        te4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te4.setName("te4"); // NOI18N

        te5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        te5.setName("te5"); // NOI18N

        tf1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf1.setName("tf1"); // NOI18N

        tf2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf2.setName("tf2"); // NOI18N

        tf3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf3.setName("tf3"); // NOI18N

        tf4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf4.setName("tf4"); // NOI18N

        tf5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tf5.setName("tf5"); // NOI18N

        tg1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg1.setName("tg1"); // NOI18N

        tg2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg2.setName("tg2"); // NOI18N

        tg3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg3.setName("tg3"); // NOI18N

        tg4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg4.setName("tg4"); // NOI18N

        tg5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tg5.setName("tg5"); // NOI18N

        th1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th1.setName("th1"); // NOI18N

        th2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th2.setName("th2"); // NOI18N

        th3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th3.setName("th3"); // NOI18N

        th4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th4.setName("th4"); // NOI18N

        th5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        th5.setName("th5"); // NOI18N

        ti1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti1.setName("ti1"); // NOI18N

        ti2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti2.setName("ti2"); // NOI18N

        ti3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti3.setName("ti3"); // NOI18N

        ti4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti4.setName("ti4"); // NOI18N

        ti5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ti5.setName("ti5"); // NOI18N

        tj1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj1.setName("tj1"); // NOI18N

        tj2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj2.setName("tj2"); // NOI18N

        tj3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj3.setName("tj3"); // NOI18N

        tj4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj4.setName("tj4"); // NOI18N

        tj5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tj5.setName("tj5"); // NOI18N

        tk1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk1.setName("tk1"); // NOI18N

        tk2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk2.setName("tk2"); // NOI18N

        tk3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk3.setName("tk3"); // NOI18N

        tk4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk4.setName("tk4"); // NOI18N

        tk5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tk5.setName("tk5"); // NOI18N

        tl1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl1.setName("tl1"); // NOI18N

        tl2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl2.setName("tl2"); // NOI18N

        tl3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl3.setName("tl3"); // NOI18N

        tl4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl4.setName("tl4"); // NOI18N

        tl5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tl5.setName("tl5"); // NOI18N

        tm1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm1.setName("tm1"); // NOI18N

        tm2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm2.setName("tm2"); // NOI18N

        tm3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm3.setName("tm3"); // NOI18N

        tm4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm4.setName("tm4"); // NOI18N

        tm5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tm5.setName("tm5"); // NOI18N

        tn1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn1.setName("tn1"); // NOI18N

        tn2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn2.setName("tn2"); // NOI18N

        tn3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn3.setName("tn3"); // NOI18N

        tn4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn4.setName("tn4"); // NOI18N

        tn5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tn5.setName("tn5"); // NOI18N

        to1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to1.setName("to1"); // NOI18N

        to2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to2.setName("to2"); // NOI18N

        to3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to3.setName("to3"); // NOI18N

        to4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to4.setName("to4"); // NOI18N

        to5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        to5.setName("to5"); // NOI18N

        tp1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp1.setName("tp1"); // NOI18N

        tp2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp2.setName("tp2"); // NOI18N

        tp3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp3.setName("tp3"); // NOI18N

        tp4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp4.setName("tp4"); // NOI18N

        tp5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tp5.setName("tp5"); // NOI18N

        tr1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr1.setName("tr1"); // NOI18N

        tr2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr2.setName("tr2"); // NOI18N

        tr3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr3.setName("tr3"); // NOI18N

        tr4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr4.setName("tr4"); // NOI18N

        tr5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tr5.setName("tr5"); // NOI18N

        ts1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts1.setName("ts1"); // NOI18N

        ts2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts2.setName("ts2"); // NOI18N

        ts3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts3.setName("ts3"); // NOI18N

        ts4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts4.setName("ts4"); // NOI18N

        ts5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        ts5.setName("ts5"); // NOI18N

        tt1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt1.setName("tt1"); // NOI18N

        tt2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt2.setName("tt2"); // NOI18N

        tt3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt3.setName("tt3"); // NOI18N

        tt4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt4.setName("tt4"); // NOI18N

        tt5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tt5.setName("tt5"); // NOI18N

        tu1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu1.setName("tu1"); // NOI18N

        tu2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu2.setName("tu2"); // NOI18N

        tu3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu3.setName("tu3"); // NOI18N

        tu4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu4.setName("tu4"); // NOI18N

        tu5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tu5.setName("tu5"); // NOI18N

        tv1.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv1.setName("tv1"); // NOI18N

        tv2.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv2.setName("tv2"); // NOI18N

        tv3.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv3.setName("tv3"); // NOI18N

        tv4.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv4.setName("tv4"); // NOI18N

        tv5.setFont(resourceMap.getFont("t11.font")); // NOI18N
        tv5.setName("tv5"); // NOI18N

        nextButton.setText(bundle.getString("Ďalší akord")); // NOI18N
        nextButton.setName("nextButton"); // NOI18N
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });

        previousButton.setText(bundle.getString("Predchádzajúci akord")); // NOI18N
        previousButton.setName("previousButton"); // NOI18N
        previousButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousButtonActionPerformed(evt);
            }
        });

        jLabel8.setText(bundle.getString("Aktuálna spojnica:")); // NOI18N
        jLabel8.setName("jLabel8"); // NOI18N

        junctor0.setName("junctor0"); // NOI18N

        jLabel9.setText(resourceMap.getString("jLabel9.text")); // NOI18N
        jLabel9.setName("jLabel9"); // NOI18N

        junctor1.setName("junctor1"); // NOI18N

        countButton.setText(bundle.getString("Prepočítať")); // NOI18N
        countButton.setName("countButton"); // NOI18N
        countButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countButtonActionPerformed(evt);
            }
        });

        toneOmitButton.setText(bundle.getString("Povoliť akord s vynechanými tónmi")); // NOI18N
        toneOmitButton.setName("toneOmitButton"); // NOI18N
        toneOmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toneOmitButtonActionPerformed(evt);
            }
        });

        errorOmitButton.setText(bundle.getString("Preskočiť túto chybu")); // NOI18N
        errorOmitButton.setName("errorOmitButton"); // NOI18N
        errorOmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                errorOmitButtonActionPerformed(evt);
            }
        });

        chromaticsButton.setText(bundle.getString("Chromatika")); // NOI18N
        chromaticsButton.setName("chromaticsButton"); // NOI18N
        chromaticsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chromaticsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(exerciseLabel))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1149, Short.MAX_VALUE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(checkButton)
                        .addGap(18, 18, 18)
                        .addComponent(nextButton)
                        .addGap(18, 18, 18)
                        .addComponent(previousButton)
                        .addGap(18, 18, 18)
                        .addComponent(chromaticsButton)
                        .addGap(31, 31, 31)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(junctor0, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(junctor1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(countButton))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addGap(21, 21, 21)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(t12, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t13, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t14, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t15, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(t22, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t23, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t24, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t21, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t25, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(t31, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t35, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t34, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t33, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t32, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t42, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t43, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t44, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t41, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t45, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(keyChoice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                                .addComponent(errorOmitButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(toneOmitButton))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(t52, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t53, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t54, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t51, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t55, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(8, 8, 8)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(t62, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t63, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t64, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t61, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t65, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(t72, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t73, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t74, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t71, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t75, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t82, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t83, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t84, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(t81, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t85, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(t92, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t93, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t94, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(t91, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(t95, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(8, 8, 8)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(ta2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(ta3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(ta4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(ta1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(ta5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tb2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tb3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tb4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tb1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tb5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tc1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tc5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(td2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(td3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(td4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(td1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(td5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(8, 8, 8)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(te2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(te3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(te4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(te1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(te5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(tg1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tg5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(th2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(th3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(th4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(th1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(th5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(ti2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(ti3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(ti4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(ti1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(ti5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tj2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tj3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tj4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tj1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tj5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tk2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tk3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tk4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tk1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tk5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tl2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tl3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tl4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tl1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tl5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tm1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tm5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tn2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tn3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tn4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tn1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tn5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(to2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(to3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(to4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(to1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(to5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tp2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tp3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tp4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tp1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tp5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tr1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tr5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(ts2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ts3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ts4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ts1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(ts5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tt2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tt3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tt4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tt1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tt5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tu2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tu3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tu4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tu1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tu5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(tv1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tv5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(exerciseLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(keyChoice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(toneOmitButton)
                            .addComponent(errorOmitButton))))
                .addGap(12, 12, 12)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t21, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t11, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t22, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t12, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t32, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t23, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t13, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t33, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t24, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t14, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t34, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(t31, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t41, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t42, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t43, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t44, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t25, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t45, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t15, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t35, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t51, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t52, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t53, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t54, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t61, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t62, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t63, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t64, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t55, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t71, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t72, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t73, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t74, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t81, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t82, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t83, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t84, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t75, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t65, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t85, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(t91, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t92, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t93, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t94, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(ta1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ta2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ta3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ta4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(t95, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tb1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tb2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tb3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tb4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tc1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tc2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tc3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tc4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tb5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ta5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tc5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(td1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(td2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(td3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(td4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(te1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(te2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(te3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(te4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(td5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tg1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tg2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tg3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tg4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(te5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tg5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(th1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(th2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(th3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(th4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(ti1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ti2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ti3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ti4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(th5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ti5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tj1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tj2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tj3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tj4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tk1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tk2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tk3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tk4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tj5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tl1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tl2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tl3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tl4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tm1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tm2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tm3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tm4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tl5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tk5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tm5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tn1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tn2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tn3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tn4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(to1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(to2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(to3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(to4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tn5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tp1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tp2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tp3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tp4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tr1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tr2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tr3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tr4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tp5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(to5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tr5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(ts1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ts2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ts3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ts4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tt1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tt2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tt3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tt4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ts5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tu1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tu2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tu3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tu4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(tv1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tv2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tv3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tv4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tu5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tt5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tv5, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(previousButton)
                    .addComponent(nextButton)
                    .addComponent(checkButton)
                    .addComponent(jLabel8)
                    .addComponent(junctor0, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(junctor1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(countButton)
                    .addComponent(chromaticsButton))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(bundle.getString("Program")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        alwaysOnTop.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        alwaysOnTop.setText(bundle.getString("Vždy navrchu")); // NOI18N
        alwaysOnTop.setName("alwaysOnTop"); // NOI18N
        alwaysOnTop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alwaysOnTopActionPerformed(evt);
            }
        });
        fileMenu.add(alwaysOnTop);

        jSeparator5.setName("jSeparator5"); // NOI18N
        fileMenu.add(jSeparator5);

        showFirstScreen.setText(bundle.getString("Úvodná obrazovka")); // NOI18N
        showFirstScreen.setName("showFirstScreen"); // NOI18N
        showFirstScreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showFirstScreenActionPerformed(evt);
            }
        });
        fileMenu.add(showFirstScreen);

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(harmony.HarmonyApp.class).getContext().getActionMap(HarmonyOwnExercise.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setText(bundle.getString("Koniec")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        exerciseMenu.setText(bundle.getString("Skladba")); // NOI18N

        loadExercise.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        loadExercise.setText(bundle.getString("Otvoriť")); // NOI18N
        loadExercise.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadExerciseActionPerformed(evt);
            }
        });
        exerciseMenu.add(loadExercise);

        saveExercise.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveExercise.setText(bundle.getString("Uložiť")); // NOI18N
        saveExercise.setEnabled(false);
        saveExercise.setName("saveExercise"); // NOI18N
        saveExercise.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveExerciseActionPerformed(evt);
            }
        });
        exerciseMenu.add(saveExercise);

        jSeparator2.setName("jSeparator2"); // NOI18N
        exerciseMenu.add(jSeparator2);

        insertChord.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        insertChord.setText(bundle.getString("Vsunúť akord")); // NOI18N
        insertChord.setEnabled(false);
        insertChord.setName("insertChord"); // NOI18N
        insertChord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertChordActionPerformed(evt);
            }
        });
        exerciseMenu.add(insertChord);

        deleteChord.setText(bundle.getString("Zmazať akord")); // NOI18N
        deleteChord.setEnabled(false);
        deleteChord.setName("deleteChord"); // NOI18N
        deleteChord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteChordActionPerformed(evt);
            }
        });
        exerciseMenu.add(deleteChord);

        eraseFromCurrent.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        eraseFromCurrent.setText(bundle.getString("Vymazať odtiaľto...")); // NOI18N
        eraseFromCurrent.setEnabled(false);
        eraseFromCurrent.setName("eraseFromCurrent"); // NOI18N
        eraseFromCurrent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eraseFromCurrentActionPerformed(evt);
            }
        });
        exerciseMenu.add(eraseFromCurrent);

        eraseAllFromCurrent.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        eraseAllFromCurrent.setText(bundle.getString("Vymazať všetko odtiaľto")); // NOI18N
        eraseAllFromCurrent.setEnabled(false);
        eraseAllFromCurrent.setName("eraseAllFromCurrent"); // NOI18N
        eraseAllFromCurrent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eraseAllFromCurrentActionPerformed(evt);
            }
        });
        exerciseMenu.add(eraseAllFromCurrent);

        jSeparator1.setName("jSeparator1"); // NOI18N
        exerciseMenu.add(jSeparator1);

        searchChord.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.CTRL_MASK));
        searchChord.setText(bundle.getString("Hľadať akord...")); // NOI18N
        searchChord.setEnabled(false);
        searchChord.setName("searchChord"); // NOI18N
        searchChord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchChordActionPerformed(evt);
            }
        });
        exerciseMenu.add(searchChord);

        jSeparator4.setName("jSeparator4"); // NOI18N
        exerciseMenu.add(jSeparator4);

        analyseChord.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        analyseChord.setText(bundle.getString("Analýza akordu")); // NOI18N
        analyseChord.setEnabled(false);
        analyseChord.setName("analyseChord"); // NOI18N
        analyseChord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                analyseChordActionPerformed(evt);
            }
        });
        exerciseMenu.add(analyseChord);

        jSeparator6.setName("jSeparator6"); // NOI18N
        exerciseMenu.add(jSeparator6);

        threeVoiceMode.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        threeVoiceMode.setText(bundle.getString("Režim trojhlasu")); // NOI18N
        threeVoiceMode.setEnabled(false);
        threeVoiceMode.setName("threeVoiceMode"); // NOI18N
        threeVoiceMode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                threeVoiceModeActionPerformed(evt);
            }
        });
        exerciseMenu.add(threeVoiceMode);

        menuBar.add(exerciseMenu);

        checkMenu.setText(bundle.getString("Kontrolovať")); // NOI18N
        checkMenu.setName("checkMenu"); // NOI18N

        otherChord.setText(bundle.getString("Druh akordu")); // NOI18N
        otherChord.setName("otherChord"); // NOI18N
        otherChord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                otherChordActionPerformed(evt);
            }
        });
        checkMenu.add(otherChord);

        omitTone.setText(bundle.getString("Vynechané tóny")); // NOI18N
        omitTone.setActionCommand(resourceMap.getString("omitTone.actionCommand")); // NOI18N
        omitTone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                omitToneActionPerformed(evt);
            }
        });
        checkMenu.add(omitTone);

        toneCrossing.setText(bundle.getString("Kríženie hlasov")); // NOI18N
        toneCrossing.setName("toneCrossing"); // NOI18N
        toneCrossing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toneCrossingActionPerformed(evt);
            }
        });
        checkMenu.add(toneCrossing);

        notAWideHarmony.setText(bundle.getString("Široká harmónia")); // NOI18N
        notAWideHarmony.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notAWideHarmonyActionPerformed(evt);
            }
        });
        checkMenu.add(notAWideHarmony);

        leadingToneDoubled.setText(bundle.getString("Zdvojený citlivý tón")); // NOI18N
        leadingToneDoubled.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leadingToneDoubledActionPerformed(evt);
            }
        });
        checkMenu.add(leadingToneDoubled);

        leadingToneNotResolved.setText(bundle.getString("Citlivý tón nerozvedený")); // NOI18N
        leadingToneNotResolved.setName("leadingToneNotResolved"); // NOI18N
        leadingToneNotResolved.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leadingToneNotResolvedActionPerformed(evt);
            }
        });
        checkMenu.add(leadingToneNotResolved);

        notCantabile.setText(bundle.getString("Nespevný krok")); // NOI18N
        notCantabile.setName("notCantabile"); // NOI18N
        notCantabile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notCantabileActionPerformed(evt);
            }
        });
        checkMenu.add(notCantabile);

        parallelEights.setText(bundle.getString("Paralelné oktávy")); // NOI18N
        parallelEights.setName("parallelEights"); // NOI18N
        parallelEights.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parallelEightsActionPerformed(evt);
            }
        });
        checkMenu.add(parallelEights);

        parallelFifths.setText(bundle.getString("Paralelné kvinty")); // NOI18N
        parallelFifths.setName("parallelFifths"); // NOI18N
        parallelFifths.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parallelFifthsActionPerformed(evt);
            }
        });
        checkMenu.add(parallelFifths);

        menuBar.add(checkMenu);

        helpMenu.setText(bundle.getString("Pomoc")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        inputToneFormat.setText(bundle.getString("Formát tónov")); // NOI18N
        inputToneFormat.setName("inputToneFormat"); // NOI18N
        inputToneFormat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputToneFormatActionPerformed(evt);
            }
        });
        helpMenu.add(inputToneFormat);

        inputChordFormat.setText(bundle.getString("Formát druhu akordu")); // NOI18N
        inputChordFormat.setName("inputChordFormat"); // NOI18N
        inputChordFormat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputChordFormatActionPerformed(evt);
            }
        });
        helpMenu.add(inputChordFormat);

        shortcuts.setText(bundle.getString("Klávesové skratky")); // NOI18N
        shortcuts.setName("shortcuts"); // NOI18N
        shortcuts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shortcutsActionPerformed(evt);
            }
        });
        helpMenu.add(shortcuts);

        jSeparator3.setName("jSeparator3"); // NOI18N
        helpMenu.add(jSeparator3);

        userGuideMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        userGuideMenuItem.setText(bundle.getString("Príručka")); // NOI18N
        userGuideMenuItem.setName("userGuideMenuItem"); // NOI18N
        userGuideMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userGuideMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(userGuideMenuItem);

        menuBar.add(helpMenu);

        setComponent(mainPanel);
        setMenuBar(menuBar);
    }// </editor-fold>//GEN-END:initComponents

    private void showFirstScreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showFirstScreenActionPerformed
        if(hasNextFrame()){
                if(JOptionPane.showConfirmDialog(this.getComponent(),
                                    java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZATVORIA SA VŠETKY OKNÁ. PRAJETE SI TOTO?"), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("POTVRDIŤ ZATVORENIE VIACERÝCH OKIEN"), 0) == 0){
                                closeAllFrames();
                                superFrame.getFrame().setVisible(true);
                }
        }else{
            superFrame.getFrame().setVisible(true);
            this.getFrame().dispose();
        }
}//GEN-LAST:event_showFirstScreenActionPerformed

    private void keyChoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keyChoiceActionPerformed
        if(keyChoice.getSelectedItem() != null && keyChoice.getSelectedIndex() != firstInvalidKey && !keyOnlyFired){
                key = keys.getKey(keyChoice.getSelectedIndex());
                firstInvalidKey = -1;

                //delete first row from exercise choice, if that havent happened yet
                if (!defaultDeleted){
                    keys.removeFirstKey();
                    defaultDeleted = true;
                }

                if(column==1){ //then its start of an exercise
                    //only first column should be editable
                    for (int k = 1; k<151; k++){
                        tones[k].setEditable(false);
                    }
                    tones[1].setEditable(true);
                    tones[2].setEditable(true);
                    tones[3].setEditable(true);
                    if(!threeVoices){
                        tones[4].setEditable(true);
                    }
                    tones[5].setEditable(true);
                }

                junctor0.setText("");
                junctor1.setText("");

                toneOmitButton.setVisible(false);
                errorOmitButton.setVisible(false);
                activateFrame();

                //each change of key will be fired to all frames
                for(HarmonyOwnExercise frame : frames){
                    frame.keyOnlyFired = true;
                    frame.key = keys.getKey(keyChoice.getSelectedIndex());
                    frame.keyChoice.setSelectedIndex(keyChoice.getSelectedIndex());
                    frame.keyOnlyFired = false;
                }

                if(previousFrame==null){
                    green();
                    communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ÚSPEŠNE STE ZVOLILI TÓNINU. TERAZ ZADAJTE TÓNY AKORDU A JEHO DRUH A STLAČTE TLAČÍTKO \"OVERIŤ\"."));
                }else{
                    green();
                    communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MÔŽETE ZADAŤ ĎALŠÍ AKORD."));
                }
        }
    }//GEN-LAST:event_keyChoiceActionPerformed

    private void checkButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkButtonActionPerformed
        Integer tone4;
        Integer previousTone4;
        if(threeVoices){ //in three voice mode fourth tone will be identical with third tone, and fourth tone will be erased
            tone4 = Tones.getTone(tones[column*5-2].getText());
            actualBass = tones[column*5-2].getText().toString();
            tones[column*5-1].setText("");
        }else{
            tone4 = Tones.getTone(tones[column*5-1].getText());
            actualBass = tones[column*5-1].getText().toString();
        }

        Chord chord = new Chord(Tones.getTone(tones[column*5-4].getText()),Tones.getTone(tones[column*5-3].getText()),
                Tones.getTone(tones[column*5-2].getText()), tone4);

        actualType = ChordType.getType(tones[column*5].getText());
        if(ChordType.containsOmit(tones[column*5].getText())){ //if there is "o" at end of chord mark
            omit.allowToneOmission();
        }
        
        String actualErrorText;

        if(chord.areTonesCorrect()!=0){ //then some tone is inputted incorrectly
            red();
            communication.setText(chord.areTonesCorrect()+ incorrectFormat());
            nextButton.setEnabled(false);
        }else if(actualType == null){
            red();
            if(!threeVoices){
                communication.setText(wrongChord());
                nextButton.setEnabled(false);
            }else{
                communication.setText(wrongChordInThreeTones());
                nextButton.setEnabled(false);
            }
        }else{ //check musical validity of the chord
            nextButton.setEnabled(true);
            communication.setText("");
            if(column==1 && !hasPreviousFrame()){ //case that this is first chord in the exercise
                try {
                    lastResult = chord.validateFirstChord(actualType, key, omit, threeVoices);
                    if (lastResult.isValid()) {
                        green();
                        toneOmitButton.setVisible(false);
                        omit.allowNoError();
                        errorOmitButton.setVisible(false);
                        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VÝBORNE. AKORD JE ZADANÝ SPRÁVNE. MÔŽETE PREJSŤ NA ĎALŠÍ AKORD POMOCOU TLAČÍTKA \"ĎALŠÍ AKORD\".")+"\n"
                                + lastResult.getInfo());
                    } else {
                        red();
                        actualErrorText = lastResult.getInfo();
                        communication.setText(actualErrorText);
                        if(actualErrorText.equals(Chord.getOmissionMessage())){ //then some tone is missing in chord
                            toneOmitButton.setVisible(true);
                            errorOmitButton.setVisible(false);
                        }else{
                            errorOmitButton.setVisible(true);
                            toneOmitButton.setVisible(false);
                        }
                    }
                } catch (GroundNotSupportedException ex) {
                    red();
                    communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ BASOVÝ TÓN NEPATRÍ DO ZVOLENEJ TÓNINY."));
                }
            }else{ //its not first chord

                Chord previousChord;
                if(!hasPreviousFrame()){ //then its first frame and not first chord
                    if(threeVoices){ //in three voice mode fourth tone will be identical with third tone
                        previousTone4 = Tones.getTone(tones[column*5-2].getText());
                    }else{
                        previousTone4 = Tones.getTone(tones[column*5-1].getText());
                    }
                    previousChord = new Chord(Tones.getTone(tones[(column-1)*5-4].getText()),Tones.getTone(tones[(column-1)*5-3].getText()),
                            Tones.getTone(tones[(column-1)*5-2].getText()), previousTone4);
                }else{ //then it is not first frame and is first chord
                    if(threeVoices){ //in three voice mode fourth tone will be identical with third tone
                        previousTone4 = Tones.getTone(getPreviousFrame().tones[148].getText());
                    }else{
                        previousTone4 = Tones.getTone(getPreviousFrame().tones[149].getText());
                    }
                    previousChord = new Chord(Tones.getTone(getPreviousFrame().tones[146].getText()), Tones.getTone(getPreviousFrame().tones[147].getText()),
                            Tones.getTone(getPreviousFrame().tones[148].getText()), previousTone4);
                }

                try {
                    lastResult = chord.validateChord(previousChord, actualType, key, omit, threeVoices);
                    if (lastResult.isValid()) {
                        green();
                        toneOmitButton.setVisible(false);
                        errorOmitButton.setVisible(false);
                        omit.allowNoError();
                        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VÝBORNE. AKORD JE ZADANÝ SPRÁVNE. MÔŽETE PREJSŤ NA ĎALŠÍ AKORD POMOCOU TLAČÍTKA \"ĎALŠÍ AKORD\".")+"\n"
                                + lastResult.getInfo());
                    } else {
                        red();
                        actualErrorText = lastResult.getInfo();
                        communication.setText(actualErrorText);
                        if(actualErrorText.equals(Chord.getOmissionMessage())){ //then some tone is missing in chord
                            toneOmitButton.setVisible(true);
                            errorOmitButton.setVisible(false);
                        }else{
                            errorOmitButton.setVisible(true);
                            toneOmitButton.setVisible(false);
                        }
                    }
                } catch (GroundNotSupportedException ex) {
                    red();
                    communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ BASOVÝ TÓN NEPATRÍ DO ZVOLENEJ TÓNINY."));
                }
            }
        }
}//GEN-LAST:event_checkButtonActionPerformed

    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        Integer tone4;
        if(threeVoices){ //in three voice mode fourth tone will be identical with third tone
            tone4 = Tones.getTone(tones[column*5-2].getText());
            actualBass = tones[column*5-2].getText().toString();
        }else{
            tone4 = Tones.getTone(tones[column*5-1].getText());
            actualBass = tones[column*5-1].getText().toString();
        }

        Chord chord = new Chord(Tones.getTone(tones[column*5-4].getText()),Tones.getTone(tones[column*5-3].getText()),
                Tones.getTone(tones[column*5-2].getText()), tone4);

        actualType = ChordType.getType(tones[column*5].getText());

        if(chord.areTonesCorrect()!=0){ //then some tone is inputted incorrectly
            red();
            communication.setText(chord.areTonesCorrect() + incorrectFormat());
        }else if(actualType == null){
            red();
            if(!threeVoices){
                communication.setText(wrongChord());
            }else{
                communication.setText(wrongChordInThreeTones());
            }
            
        }else if(column==30){ //now the tones are syntactically correct and it is end of frame
            deactivateFrame();
            if(!hasNextFrame()){
                showNewFrame();
            }else{
                deactivateAllBoxes();
                getNextFrame().activateFrame();
                getNextFrame().activateFirstChord();
                getNextFrame().getFrame().toFront();
            }

        }else{ //now the tones are syntactically correct ant it is not end of frame
            tones[eachFive[column-1]].setEditable(false);
            tones[eachFive[column-1]+1].setEditable(false);
            tones[eachFive[column-1]+2].setEditable(false);
            tones[eachFive[column-1]+3].setEditable(false);
            tones[eachFive[column-1]+4].setEditable(false);
            column++;
            tones[eachFive[column-1]].setEditable(true);
            tones[eachFive[column-1]+1].setEditable(true);
            tones[eachFive[column-1]+2].setEditable(true);
            if(!threeVoices){
                tones[eachFive[column-1]+3].setEditable(true);
            }
            tones[eachFive[column-1]+4].setEditable(true);

            previousButton.setEnabled(true);
            toneOmitButton.setVisible(false);
            errorOmitButton.setVisible(false);
            junctor0.setText("");
            junctor1.setText("");

            green();
            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TERAZ ZADAJTE TÓNY ĎALŠIEHO AKORDU A JEHO DRUH A STLAČTE TLAČÍTKO \"OVERIŤ\"."));
        }
    }//GEN-LAST:event_nextButtonActionPerformed

    private void previousButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousButtonActionPerformed
         if(column==1){
            deactivateFrame();
            if(hasPreviousFrame()){
                deactivateAllBoxes();
                getPreviousFrame().activateFrame();
                getPreviousFrame().activateLastChord();
                getPreviousFrame().getFrame().toFront();
            }
        }else{
            tones[eachFive[column-1]].setEditable(false);
            tones[eachFive[column-1]+1].setEditable(false);
            tones[eachFive[column-1]+2].setEditable(false);
            tones[eachFive[column-1]+3].setEditable(false);
            tones[eachFive[column-1]+4].setEditable(false);
            column--;
            tones[eachFive[column-1]].setEditable(true);
            tones[eachFive[column-1]+1].setEditable(true);
            tones[eachFive[column-1]+2].setEditable(true);
            if(!threeVoices){
                tones[eachFive[column-1]+3].setEditable(true);
            }
            tones[eachFive[column-1]+4].setEditable(true);

            toneOmitButton.setVisible(false);
            errorOmitButton.setVisible(false);
            if(previousFrame==null && column==1){
                previousButton.setEnabled(false);
            }
            junctor0.setText("");
            junctor1.setText("");

            green();
            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TERAZ MÔŽETE OPRAVIŤ ALEBO UPRAVIŤ NIEKTORÝ ZO SKORŠÍCH AKORDOV."));
        }
    }//GEN-LAST:event_previousButtonActionPerformed

    private void countButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countButtonActionPerformed
        junctor0.setText("");
        junctor1.setText("");

        actualType = ChordType.getType(tones[column*5].getText());

        if(!threeVoices){
            actualBass = tones[column*5-1].getText().toString();
        }else{
            actualBass = tones[column*5-2].getText().toString();
        }

        if(column!=1){
            lastType = ChordType.getType(tones[(column-1)*5].getText());
            if(!threeVoices){
                lastBass = tones[(column-1)*5-1].getText().toString();
            }else{
                lastBass = tones[(column-1)*5-2].getText().toString();
            }
        }

        Chord chord = new Chord(0,0,0,Tones.getTone(actualBass));
        if(chord.areTonesCorrect()!=0){ //then bass is inputted incorrectly
            red();
            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("BASOVÝ TÓN NIE JE ZADANÝ ALEBO JE ZADANÝ V NESPRÁVNOM FORMÁTE.")+"\n" +inputToneFormat());
            nextButton.setEnabled(false);
        }else if(actualType == null){
            red();
            if(!threeVoices){
                communication.setText(wrongChord());
            }else{
                communication.setText(wrongChordInThreeTones());
            }
        }else{
            try {
                if(column==1){
                    junctor0.setText("");
                    junctor1.setText(actualType.getChordPosition(key, Tones.getTone(actualBass)).toString());
                }else{
                    junctor0.setText(lastType.getChordPosition(key, Tones.getTone(lastBass)).toString());
                    junctor1.setText(actualType.getChordPosition(key, Tones.getTone(actualBass)).toString());
                }
            } catch (GroundNotSupportedException ex) { //this could happen only if predefined exercise was incorrect
                red();
                communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ BASOVÝ TÓN NEPATRÍ DO ZVOLENEJ TÓNINY."));
            }
        }
    }//GEN-LAST:event_countButtonActionPerformed

    private void eraseAllFromCurrentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eraseAllFromCurrentActionPerformed
        closeAllNextFrames();

        for (int k = 150; k>column*5; k--){
            tones[k].setText("");
            tones[k].setEditable(false);
        }

        deactivateFrame();
        activateFrame();
        eraseCurrentChord();
        activateCurrentChord();

        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VŠETKY AKORDY NACHÁDZAJÚCE SA ODTIAĽTO DOPRAVA BOLI VYMAZANÉ.")+"\n");
    }//GEN-LAST:event_eraseAllFromCurrentActionPerformed

    private void toneOmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toneOmitButtonActionPerformed
        omit.allowToneOmission();
        checkButtonActionPerformed(evt);
        toneOmitButton.setVisible(false);
        tones[column*5].setText(tones[column*5].getText()+"o");
}//GEN-LAST:event_toneOmitButtonActionPerformed

    private void loadExerciseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadExerciseActionPerformed
      if(hasPreviousFrame()){
          getFirstFrame().loadExerciseActionPerformed(evt);
      }else{


          JFileChooser fileChooser = new JFileChooser();
          fileChooser.setAcceptAllFileFilterUsed(false);
          MyFileFilter filter = new MyFileFilter();
          fileChooser.setFileFilter(filter);

          int resultVal = fileChooser.showOpenDialog(this.getComponent());
          File file = null;
          if (resultVal == JFileChooser.APPROVE_OPTION) {
            file = fileChooser.getSelectedFile();
          }
          if (resultVal == JFileChooser.CANCEL_OPTION) {
          }

        String extension = "";
        if(file!=null){
              String fileName = file.getName();

              //Remove whitespace.
              fileName = fileName.trim();

              //Find the position of the last dot.  Get extension.
              int dotPos = fileName.lastIndexOf(".");
              if(dotPos!=-1){
                extension = fileName.substring(dotPos);
              }
        }


        FileInputStream fis = null;
        BufferedInputStream bis = null;
        BufferedReader reader = null;


        try {
          if(file!=null){
              fis = new FileInputStream(file);
              bis = new BufferedInputStream(fis);
              reader = new BufferedReader(new InputStreamReader(bis));

              if(!extension.equals(".har")){
                  throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE POVOLENÉ OTVÁRAŤ IBA SÚBORY S PRÍPONOOU \".HAR\"."));
              }

              if(!reader.ready()){
                  throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR JE PRÁZDNY ALEBO NEPRÍSTUPNÝ NA ČÍTANIE:")+" "+file);
              }
              String header = reader.readLine();
              if(header.equals("Harmony")){
                  throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR BOL ZREJME VYTVORENÝ STARŠOU VERZIOU TOHTO PROGRAMU A NEMOŽNO HO OTVORIŤ:")+" "+file);
              }
              if(!header.equals("Harmony 1.1")){
                  throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR JE V NESPRÁVNOM FORMÁTE:")+" "+file);
              }
              String fileSystem = reader.readLine();
              String thisSystem = Translation.getToneSystem().toString();
              Map<String, String> transcodingMap = null;
              String transcodingInfo = "";
              if(!Translation.isToneSystemUsed(fileSystem)){
                    if(Translation.isToneSystemCorrect(fileSystem)){
                        transcodingMap = getTranscodingMap(Translation.getToneSystemFromToStringMethod(fileSystem), Translation.getToneSystemFromToStringMethod(thisSystem));
                        transcodingInfo = "\n"+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SKLADBA BOLA AUTOMATICKY PREVEDENÁ Z TÓNOVÉHO SYSTÉMU:")+" "+fileSystem+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString(" DO VÁŠHO SYSTÉMU:")+" "+thisSystem+"\n"+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PRÍPADNÉ CHYBNE ZADANÉ TÓNY BOLI PONECHANÉ V PÔVODNOM TVARE.");
                        Translation.setToneSystem(Translation.getToneSystemFromToStringMethod(fileSystem)); //needed temporarily for setting musical key
                    }else{
                        throw new IllegalStateException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR JE V NESPRÁVNOM FORMÁTE:")+" "+file);
                    }
                }
              key = Key.getKey(reader.readLine()); // key is now correctly set
              Translation.setToneSystem(Translation.getToneSystemFromToStringMethod(thisSystem)); //return to original value

              closeAllNextFrames();
              eraseBoxes();
              deactivateFrame();

              if(reader.ready()){ //first frame will be filled
                  if(transcodingMap == null){ //that means no transcoding needed
                      for(int i=1; i<=150; i++){
                        tones[i].setText(reader.readLine());
                      }
                  }else{
                      for(int i=1; i<=150; i++){
                        tones[i].setText(transcode(reader.readLine(), transcodingMap));
                      }
                  }
              }

              HarmonyOwnExercise currentFrame;
              while (reader.ready()) {
                currentFrame = getLastFrame().showNewFrame();
                if(transcodingMap == null){ //that means no transcoding needed
                    for(int i=1; i<=150; i++){
                        currentFrame.tones[i].setText(reader.readLine());
                    }
                }else{
                    for(int i=1; i<=150; i++){
                        currentFrame.tones[i].setText(transcode(reader.readLine(), transcodingMap));
                    }
                }
                currentFrame.deactivateFrame();
              }

              
              keyOnlyFired = true;
              keyChoice.setSelectedIndex(keys.getIndex(key));
              keyOnlyFired = false;

              getFirstFrame().activateFrame();
              getFirstFrame().activateFirstChord();
              getFirstFrame().getFrame().toFront();
              getFirstFrame().getFrame().requestFocus();

              if(tones[4].getText().equals("")){
                  threeVoiceMode.setState(true);
                  threeVoiceModeActionPerformed(null);
              }

              green();
              communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SKLADBA BOLA ÚSPEŠNE NAČÍTANÁ ZO SÚBORU:")+" "+file +transcodingInfo);

              fis.close();
              bis.close();
              reader.close();

          }
        } catch (IllegalStateException ex) {
            red();
            communication.setText(ex.getMessage());
        } catch (Exception ex) {
            red();
            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VYSKYTLA SA CHYBA PRI NAČÍTANÍ SÚBORU."));
        }
      }

    }//GEN-LAST:event_loadExerciseActionPerformed

    private void errorOmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_errorOmitButtonActionPerformed
        omit.allowError(lastResult);
        errorOmitButton.setVisible(false);
        checkButtonActionPerformed(evt);
    }//GEN-LAST:event_errorOmitButtonActionPerformed

    private void saveExerciseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveExerciseActionPerformed
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setAcceptAllFileFilterUsed(false);
      MyFileFilter filter = new MyFileFilter();
      fileChooser.setFileFilter(filter);

      int resultVal = fileChooser.showSaveDialog(this.getComponent());
      File file = null;
      if (resultVal == JFileChooser.APPROVE_OPTION) {
        file = fileChooser.getSelectedFile();
      }
      if (resultVal == JFileChooser.CANCEL_OPTION) {
      }

      String extension = "";
      if(file!=null){
          String fileName = file.getName();

          //Remove whitespace.
          fileName = fileName.trim();

          //Find the position of the last dot.  Get extension.
          int dotPos = fileName.lastIndexOf(".");
          if(dotPos!=-1){
            extension = fileName.substring(dotPos);
          }
      }


      try{
        if (file != null) {
            if(file.exists() && !extension.equals(".har")){
              throw new IllegalArgumentException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR UŽ EXISTUJE A JEHO PRÍPONA NIE JE \".HAR\" :")+" "+file.getName()+"\n"
                      + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE DOVOLENÉ PREPÍSAŤ IBA SÚBORY TYPU \".HAR\"."));
            }
            if(file.exists()){
                if(JOptionPane.showConfirmDialog(this.getComponent(),
                        java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR")+" "+file.getName()+" "+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("UŽ EXISTUJE. PRAJETE SI HO PREPÍSAŤ?"), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR EXISTUJE"), 0) == 1){
                    throw new IllegalArgumentException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("OPERÁCIA ZRUŠENÁ."));
                }
            }
            if (!file.exists()) {
               file = new File(file.getPath()+".har");
               file.createNewFile();
            }
            if (!file.isFile()) {
              throw new IllegalArgumentException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MUSÍTE ZVOLIŤ SÚBOR, NIE ZLOŽKU:")+" " + file);
            }
            if (!file.canWrite()) {
              throw new IllegalArgumentException(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SÚBOR SA NEDARÍ ULOŽIŤ:")+" " + file);
            }

            Writer output = new BufferedWriter(new FileWriter(file));
            try {
              output.write("Harmony 1.1");
              output.write("\n"+Translation.getToneSystem().toString());
              output.write("\n"+key.getInfo());

              HarmonyOwnExercise actualFrame = getFirstFrame();
              do{
                  for(int i=1; i<=150; i++){
                      output.write("\n"+actualFrame.tones[i].getText());
                  }
                  actualFrame = actualFrame.getNextFrame();
              }while(actualFrame!=null);
            }
            finally {
              output.close();
              green();
              communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ÚSPEŠNE ULOŽENÉ DO SÚBORU:")+" " + file);
            }
         }
      }catch(Exception ex){
              red();
              communication.setText(ex.getMessage());
          }
    }//GEN-LAST:event_saveExerciseActionPerformed

    private void insertChordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertChordActionPerformed
        HarmonyOwnExercise lastFrame = getLastFrame();

        if(!lastFrame.tones[146].getText().equals("") || !lastFrame.tones[147].getText().equals("") ||
                !lastFrame.tones[148].getText().equals("") || !lastFrame.tones[149].getText().equals("") ||
                !lastFrame.tones[150].getText().equals("")){
            if(lastFrame.nextFrame==null){
                showNewFrame();
            }
            lastFrame.nextFrame.tones[1].setText(lastFrame.tones[146].getText());
            lastFrame.nextFrame.tones[2].setText(lastFrame.tones[147].getText());
            lastFrame.nextFrame.tones[3].setText(lastFrame.tones[148].getText());
            lastFrame.nextFrame.tones[4].setText(lastFrame.tones[149].getText());
            lastFrame.nextFrame.tones[5].setText(lastFrame.tones[150].getText());
            lastFrame.nextFrame.deactivateFrame();
        }

        int target;
        HarmonyOwnExercise targetFrame;

        do{
            if(lastFrame.isActive()){
                target = column*5-4;
            }else{
                target = 1;
            }
            for(int i=145; i>=target; i--){
                lastFrame.tones[i+5].setText(lastFrame.tones[i].getText());
            }
            targetFrame = lastFrame;
            lastFrame = lastFrame.getPreviousFrame();
        }while(lastFrame!=null);

        targetFrame.eraseCurrentChord();
        targetFrame.activateCurrentChord();
        targetFrame.getFrame().toFront();

        targetFrame.green();
        targetFrame.communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("BOLO VYTVORENÉ NOVÉ MIESTO PRE AKORD. VŠETKY STÁVAJÚCE AKORDY BOLI POSUNUTÉ O JEDNO MIESTO DOPRAVA."));
    }//GEN-LAST:event_insertChordActionPerformed

    private void inputToneFormatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputToneFormatActionPerformed
        JOptionPane.showMessageDialog(this.getComponent(), inputToneFormat(), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("FORMÁT TÓNOV"), 1);
    }//GEN-LAST:event_inputToneFormatActionPerformed

    private void inputChordFormatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputChordFormatActionPerformed
        JOptionPane.showMessageDialog(this.getComponent(), inputChordFormat(), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("FORMÁT DRUHU AKORDU"), 1);
    }//GEN-LAST:event_inputChordFormatActionPerformed

    private void shortcutsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shortcutsActionPerformed
        JOptionPane.showMessageDialog(this.getComponent(), shortcuts(), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("KLÁVESOVÉ SKRATKY"), 1);
    }//GEN-LAST:event_shortcutsActionPerformed

    private void eraseFromCurrentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eraseFromCurrentActionPerformed
        Object input = JOptionPane.showInputDialog(this.getComponent(), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("KOĽKO AKORDOV VYMAZAŤ, POČÍNAJÚC TÝMTO AKORDOM?"), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VYMAZAŤ ODTIAĽTO"), 3, null, null, null);
        Integer number = null;
        StringBuilder stringBuild = new StringBuilder("");
        stringBuild.append(input);

        if(stringBuild.toString().equals("null")){
            green();
            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("OPERÁCIA ZRUŠENÁ."));
        }else{
        
           try {
                number = Integer.parseInt((String)input);
            if (number<1 || number>10000){
                red();
                communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZADANÝ POČET ZMAZANÝCH AKORDOV NESMIE BYŤ MENŠÍ NEŽ 1 ALEBO VÄČŠÍ NEŽ 10000."));
            }else{

                int total = number*5;
                boolean wasActive = false;
                int k;

                for(HarmonyOwnExercise frame : frames){
                    if(!frame.isActive() && !wasActive){
                        return;
                    }
                    wasActive = true;

                    if(frame.isActive()){
                        k=column*5-4;
                    }else{
                        k=1;
                    }

                    for (; k<=150; k++){
                        total--;
                        if(total<0){
                            break;
                        }
                        frame.tones[k].setText("");
                        frame.tones[k].setEditable(false);
                    }
                }

                while(getLastFrame().isEmpty() && getLastFrame()!=getFirstFrame()){
                    getLastFrame().getPreviousFrame().closeAllNextFrames();
                }

                activateCurrentChord();

                green();
                communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ÚSPEŠNE ZMAZANÝCH")+" "+number+" "+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("AKORDOV."));
                 }

             }catch(NumberFormatException ex){
             red();
             communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE NUTNÉ ZADAŤ ČÍSLO."));
             }
        }
    }//GEN-LAST:event_eraseFromCurrentActionPerformed

    private void searchChordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchChordActionPerformed
        String numberOfTones_String;
        if(threeVoices){
            numberOfTones_String=java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TROCH");
        }else{
            numberOfTones_String=java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ŠTYROCH");
        }

        String tone1;
        String tone2;
        String tone3;
        String tone4;

        Object input = JOptionPane.showInputDialog(this.getComponent(), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("SEM VLOŽTE NÁZVY")+" "+numberOfTones_String+" "+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TÓNOV ODDELENÉ MEDZERAMI:"), java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("HĽADAŤ AKORD"), 1, null, null, lastSearch);
        StringBuilder stringBuild = new StringBuilder("");
        stringBuild.append(input);

        if(stringBuild.toString().equals("null")){ //operation cancelled by user
            searched.clear();
        }else{

            lastSearch = stringBuild.toString();

            try{
                if(!threeVoices){
                    tone4 = stringBuild.substring(stringBuild.lastIndexOf(" ")+1);
                    stringBuild.delete(stringBuild.lastIndexOf(" "), stringBuild.length());
                    tone3 = stringBuild.substring(stringBuild.lastIndexOf(" ")+1);
                    stringBuild.delete(stringBuild.lastIndexOf(" "), stringBuild.length());
                    tone2 = stringBuild.substring(stringBuild.lastIndexOf(" ")+1);
                    stringBuild.delete(stringBuild.lastIndexOf(" "), stringBuild.length());
                    tone1 = stringBuild.substring(stringBuild.lastIndexOf(" ")+1);
                }else{
                    tone4 = stringBuild.substring(stringBuild.lastIndexOf(" ")+1);
                    stringBuild.delete(stringBuild.lastIndexOf(" "), stringBuild.length());
                    tone3 = tone4;
                    tone2 = stringBuild.substring(stringBuild.lastIndexOf(" ")+1);
                    stringBuild.delete(stringBuild.lastIndexOf(" "), stringBuild.length());
                    tone1 = stringBuild.substring(stringBuild.lastIndexOf(" ")+1);
                }

                Chord chord = new Chord(Tones.getTone(tone1), Tones.getTone(tone2), Tones.getTone(tone3), Tones.getTone(tone4));
                if(chord.areTonesCorrect()!=0){
                    red();
                    communication.setText(chord.areTonesCorrect()+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString(". TÓN BOL ZADANÝ V NESPRÁVNOM FORMÁTE."));
                }else{
                    if(threeVoices){
                        tone4 = "";
                    }
                    if(!search(tone1, tone2, tone3, tone4, searched)){
                        red();
                        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TÓNY ")+tone1+" "+tone2+" "+tone3+" "+tone4+" "+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NEBOLI NÁJDENÉ."));
                        searched.clear();
                    }else{
                        stringBuild = new StringBuilder("");
                        stringBuild.append(input);
                        searched.add(stringBuild.toString());
                        searchChordActionPerformed(evt);
                    }
                }
            }catch(Exception ex){
                 red();
                 communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("REŤAZEC BOL ZADANÝ V NESPRÁVNOM FORMÁTE."));
                 searched.clear();
            }
        }
    }//GEN-LAST:event_searchChordActionPerformed

    private void mainPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseEntered
        this.getComponent().requestFocusInWindow();
    }//GEN-LAST:event_mainPanelMouseEntered

    private void mainPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainPanelMouseClicked
        this.getComponent().requestFocusInWindow();
    }//GEN-LAST:event_mainPanelMouseClicked

    private void alwaysOnTopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alwaysOnTopActionPerformed
        if(alwaysOnTop.getState()==true){
            this.getFrame().setAlwaysOnTop(true);
        }else{
            this.getFrame().setAlwaysOnTop(false);
        }
    }//GEN-LAST:event_alwaysOnTopActionPerformed

    private void threeVoiceModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_threeVoiceModeActionPerformed
        if(threeVoiceMode.getState() == true){
            tones[eachFive[column-1]+3].setText("");
            tones[eachFive[column-1]+3].setEditable(false);
            threeVoices = true;
            for(HarmonyOwnExercise frame : frames){
            frame.threeVoiceMode.setState(true);
            frame.threeVoices = true;
            }
        }else{
            tones[eachFive[column-1]+3].setEditable(true);
            threeVoices = false;
            for(HarmonyOwnExercise frame : frames){
            frame.threeVoiceMode.setState(false);
            frame.threeVoices = false;
            }
        }
    }//GEN-LAST:event_threeVoiceModeActionPerformed

    private void deleteChordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteChordActionPerformed
        HarmonyOwnExercise currentFrame = this;
        int target;
        do{
            if(currentFrame.isActive()){
                target = column*5-4;
            }else{
                target = 1;
            }
            for(int i=target; i<=145; i++){
                currentFrame.tones[i].setText(currentFrame.tones[i+5].getText());
            }
            currentFrame = currentFrame.getNextFrame();
        }while(currentFrame!=null);

        if(getLastFrame()!=this && getLastFrame().isEmpty()){
            getLastFrame().getPreviousFrame().closeAllNextFrames();
        }

        activateCurrentChord();
        getFrame().toFront();

        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("AKTUÁLNY AKORD BOL ZMAZANÝ A VŠETKY OSTATNÉ AKORDY BOLI POSUNUTÉ O JEDNO MIESTO DOĽAVA."));
    }//GEN-LAST:event_deleteChordActionPerformed

    private void otherChordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_otherChordActionPerformed
        if(otherChord.isSelected()){
            OmitErrors.Global.setOtherChord(false);
        }else{
            OmitErrors.Global.setOtherChord(true);
        }
    }//GEN-LAST:event_otherChordActionPerformed

    private void omitToneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_omitToneActionPerformed
        if(omitTone.isSelected()){
            OmitErrors.Global.setOmitTone(false);
        }else{
            OmitErrors.Global.setOmitTone(true);
        }
    }//GEN-LAST:event_omitToneActionPerformed

    private void toneCrossingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toneCrossingActionPerformed
        if(toneCrossing.isSelected()){
            OmitErrors.Global.setToneCrossing(false);
        }else{
            OmitErrors.Global.setToneCrossing(true);
        }
    }//GEN-LAST:event_toneCrossingActionPerformed

    private void notAWideHarmonyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notAWideHarmonyActionPerformed
        if(notAWideHarmony.isSelected()){
            OmitErrors.Global.setNotAWideHarmony(false);
        }else{
            OmitErrors.Global.setNotAWideHarmony(true);
        }
    }//GEN-LAST:event_notAWideHarmonyActionPerformed

    private void leadingToneDoubledActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leadingToneDoubledActionPerformed
        if(leadingToneDoubled.isSelected()){
            OmitErrors.Global.setLeadingToneDoubled(false);
        }else{
            OmitErrors.Global.setLeadingToneDoubled(true);
        }
    }//GEN-LAST:event_leadingToneDoubledActionPerformed

    private void leadingToneNotResolvedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leadingToneNotResolvedActionPerformed
        if(leadingToneNotResolved.isSelected()){
            OmitErrors.Global.setLeadingToneNotResolved(false);
        }else{
            OmitErrors.Global.setLeadingToneNotResolved(true);
        }
    }//GEN-LAST:event_leadingToneNotResolvedActionPerformed

    private void notCantabileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notCantabileActionPerformed
        if(notCantabile.isSelected()){
            OmitErrors.Global.setNotCantabile(false);
        }else{
            OmitErrors.Global.setNotCantabile(true);
        }
    }//GEN-LAST:event_notCantabileActionPerformed

    private void parallelEightsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parallelEightsActionPerformed
        if(parallelEights.isSelected()){
            OmitErrors.Global.setParallelEights(false);
        }else{
            OmitErrors.Global.setParallelEights(true);
        }
    }//GEN-LAST:event_parallelEightsActionPerformed

    private void parallelFifthsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parallelFifthsActionPerformed
        if(parallelFifths.isSelected()){
            OmitErrors.Global.setParallelFifths(false);
        }else{
            OmitErrors.Global.setParallelFifths(true);
        }
    }//GEN-LAST:event_parallelFifthsActionPerformed

    private void chromaticsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chromaticsButtonActionPerformed
        if(areActualTonesCorrect()){
            SortedSet<MyInteger> chromaticsOfTones = new TreeSet<MyInteger>();
            Integer tone;
            int i;
            if(threeVoices){
                i = 2;
            }else{
                i = 1;
            }
            for(; i <= 4; i++){
                tone = Tones.getTone(tones[column*5-i].getText());

                if(key.isChromatic(tone - 1)){
                    chromaticsOfTones.add(new MyInteger(tone - 1, tones[column*5-i].getText() + "↓"));
                }
                if(key.isChromatic(tone + 1)){
                    chromaticsOfTones.add(new MyInteger(tone + 1, tones[column*5-i].getText() + "↑"));
                }
            }

            green();
            communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TERAZ MÔŽETE ZADAŤ CHROMATICKÉ TÓNY.") + "\n");
            communication.append(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MOŽNÉ CHROMATICKÉ ÚPRAVY:") + " ");
            for(MyInteger myInt : chromaticsOfTones){
                communication.append(myInt.originalTone +" ");
            }
            communication.append("\n");
            
            analyseChord();

            String chordType = tones[column*5].getText();
            if(!tones[column*5].getText().startsWith("ch")){
                tones[column*5].setText("ch"+chordType);
            }
            
        }
    }//GEN-LAST:event_chromaticsButtonActionPerformed

    private void analyseChordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_analyseChordActionPerformed
        if(areActualTonesCorrect()){
            green();
            communication.setText("");
            analyseChord();
        }
    }//GEN-LAST:event_analyseChordActionPerformed

    private void userGuideMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userGuideMenuItemActionPerformed
        HarmonyView.showUserGuide();
    }//GEN-LAST:event_userGuideMenuItemActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBoxMenuItem alwaysOnTop;
    private javax.swing.JMenuItem analyseChord;
    private javax.swing.JButton checkButton;
    private javax.swing.JMenu checkMenu;
    private javax.swing.JButton chromaticsButton;
    private javax.swing.JTextArea communication;
    private javax.swing.JButton countButton;
    private javax.swing.JMenuItem deleteChord;
    private javax.swing.JMenuItem eraseAllFromCurrent;
    private javax.swing.JMenuItem eraseFromCurrent;
    private javax.swing.JButton errorOmitButton;
    private javax.swing.JLabel exerciseLabel;
    private javax.swing.JMenuItem inputChordFormat;
    private javax.swing.JMenuItem inputToneFormat;
    private javax.swing.JMenuItem insertChord;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JTextField junctor0;
    private javax.swing.JTextField junctor1;
    private javax.swing.JComboBox keyChoice;
    private javax.swing.JCheckBoxMenuItem leadingToneDoubled;
    private javax.swing.JCheckBoxMenuItem leadingToneNotResolved;
    private javax.swing.JMenuItem loadExercise;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JButton nextButton;
    private javax.swing.JCheckBoxMenuItem notAWideHarmony;
    private javax.swing.JCheckBoxMenuItem notCantabile;
    private javax.swing.JCheckBoxMenuItem omitTone;
    private javax.swing.JCheckBoxMenuItem otherChord;
    private javax.swing.JCheckBoxMenuItem parallelEights;
    private javax.swing.JCheckBoxMenuItem parallelFifths;
    private javax.swing.JButton previousButton;
    private javax.swing.JMenuItem saveExercise;
    private javax.swing.JMenuItem searchChord;
    private javax.swing.JMenuItem shortcuts;
    private javax.swing.JMenuItem showFirstScreen;
    private javax.swing.JTextField t11;
    private javax.swing.JTextField t12;
    private javax.swing.JTextField t13;
    private javax.swing.JTextField t14;
    private javax.swing.JTextField t15;
    private javax.swing.JTextField t21;
    private javax.swing.JTextField t22;
    private javax.swing.JTextField t23;
    private javax.swing.JTextField t24;
    private javax.swing.JTextField t25;
    private javax.swing.JTextField t31;
    private javax.swing.JTextField t32;
    private javax.swing.JTextField t33;
    private javax.swing.JTextField t34;
    private javax.swing.JTextField t35;
    private javax.swing.JTextField t41;
    private javax.swing.JTextField t42;
    private javax.swing.JTextField t43;
    private javax.swing.JTextField t44;
    private javax.swing.JTextField t45;
    private javax.swing.JTextField t51;
    private javax.swing.JTextField t52;
    private javax.swing.JTextField t53;
    private javax.swing.JTextField t54;
    private javax.swing.JTextField t55;
    private javax.swing.JTextField t61;
    private javax.swing.JTextField t62;
    private javax.swing.JTextField t63;
    private javax.swing.JTextField t64;
    private javax.swing.JTextField t65;
    private javax.swing.JTextField t71;
    private javax.swing.JTextField t72;
    private javax.swing.JTextField t73;
    private javax.swing.JTextField t74;
    private javax.swing.JTextField t75;
    private javax.swing.JTextField t81;
    private javax.swing.JTextField t82;
    private javax.swing.JTextField t83;
    private javax.swing.JTextField t84;
    private javax.swing.JTextField t85;
    private javax.swing.JTextField t91;
    private javax.swing.JTextField t92;
    private javax.swing.JTextField t93;
    private javax.swing.JTextField t94;
    private javax.swing.JTextField t95;
    private javax.swing.JTextField ta1;
    private javax.swing.JTextField ta2;
    private javax.swing.JTextField ta3;
    private javax.swing.JTextField ta4;
    private javax.swing.JTextField ta5;
    private javax.swing.JTextField tb1;
    private javax.swing.JTextField tb2;
    private javax.swing.JTextField tb3;
    private javax.swing.JTextField tb4;
    private javax.swing.JTextField tb5;
    private javax.swing.JTextField tc1;
    private javax.swing.JTextField tc2;
    private javax.swing.JTextField tc3;
    private javax.swing.JTextField tc4;
    private javax.swing.JTextField tc5;
    private javax.swing.JTextField td1;
    private javax.swing.JTextField td2;
    private javax.swing.JTextField td3;
    private javax.swing.JTextField td4;
    private javax.swing.JTextField td5;
    private javax.swing.JTextField te1;
    private javax.swing.JTextField te2;
    private javax.swing.JTextField te3;
    private javax.swing.JTextField te4;
    private javax.swing.JTextField te5;
    private javax.swing.JTextField tf1;
    private javax.swing.JTextField tf2;
    private javax.swing.JTextField tf3;
    private javax.swing.JTextField tf4;
    private javax.swing.JTextField tf5;
    private javax.swing.JTextField tg1;
    private javax.swing.JTextField tg2;
    private javax.swing.JTextField tg3;
    private javax.swing.JTextField tg4;
    private javax.swing.JTextField tg5;
    private javax.swing.JTextField th1;
    private javax.swing.JTextField th2;
    private javax.swing.JTextField th3;
    private javax.swing.JTextField th4;
    private javax.swing.JTextField th5;
    private javax.swing.JCheckBoxMenuItem threeVoiceMode;
    private javax.swing.JTextField ti1;
    private javax.swing.JTextField ti2;
    private javax.swing.JTextField ti3;
    private javax.swing.JTextField ti4;
    private javax.swing.JTextField ti5;
    private javax.swing.JTextField tj1;
    private javax.swing.JTextField tj2;
    private javax.swing.JTextField tj3;
    private javax.swing.JTextField tj4;
    private javax.swing.JTextField tj5;
    private javax.swing.JTextField tk1;
    private javax.swing.JTextField tk2;
    private javax.swing.JTextField tk3;
    private javax.swing.JTextField tk4;
    private javax.swing.JTextField tk5;
    private javax.swing.JTextField tl1;
    private javax.swing.JTextField tl2;
    private javax.swing.JTextField tl3;
    private javax.swing.JTextField tl4;
    private javax.swing.JTextField tl5;
    private javax.swing.JTextField tm1;
    private javax.swing.JTextField tm2;
    private javax.swing.JTextField tm3;
    private javax.swing.JTextField tm4;
    private javax.swing.JTextField tm5;
    private javax.swing.JTextField tn1;
    private javax.swing.JTextField tn2;
    private javax.swing.JTextField tn3;
    private javax.swing.JTextField tn4;
    private javax.swing.JTextField tn5;
    private javax.swing.JTextField to1;
    private javax.swing.JTextField to2;
    private javax.swing.JTextField to3;
    private javax.swing.JTextField to4;
    private javax.swing.JTextField to5;
    private javax.swing.JCheckBoxMenuItem toneCrossing;
    private javax.swing.JButton toneOmitButton;
    private javax.swing.JTextField tp1;
    private javax.swing.JTextField tp2;
    private javax.swing.JTextField tp3;
    private javax.swing.JTextField tp4;
    private javax.swing.JTextField tp5;
    private javax.swing.JTextField tr1;
    private javax.swing.JTextField tr2;
    private javax.swing.JTextField tr3;
    private javax.swing.JTextField tr4;
    private javax.swing.JTextField tr5;
    private javax.swing.JTextField ts1;
    private javax.swing.JTextField ts2;
    private javax.swing.JTextField ts3;
    private javax.swing.JTextField ts4;
    private javax.swing.JTextField ts5;
    private javax.swing.JTextField tt1;
    private javax.swing.JTextField tt2;
    private javax.swing.JTextField tt3;
    private javax.swing.JTextField tt4;
    private javax.swing.JTextField tt5;
    private javax.swing.JTextField tu1;
    private javax.swing.JTextField tu2;
    private javax.swing.JTextField tu3;
    private javax.swing.JTextField tu4;
    private javax.swing.JTextField tu5;
    private javax.swing.JTextField tv1;
    private javax.swing.JTextField tv2;
    private javax.swing.JTextField tv3;
    private javax.swing.JTextField tv4;
    private javax.swing.JTextField tv5;
    // End of variables declaration//GEN-END:variables

    private JDialog aboutBox;
    private HarmonyView superFrame;

    OmitErrors omit = new OmitErrors(false, false, false, false, false, false, false, false, false);

    //by default exercise is not only for 3 voices
    private boolean threeVoices = false;

    private JTextField[] tones = new JTextField[151];
    private int[] eachFive = {1,6,11,16,21,26,31,36,41,46,51,56,61,66,71,
    76,81,86,91,96,101,106,111,116,121,126,131,136,141,146};

    private KeyList keys = new KeyList();
    private Boolean defaultDeleted = false;
    private Key key;
    private boolean keyOnlyFired = false; //if its true, then keyChoiseAction wont have effect
    private int firstInvalidKey = 0;

    private ChordType lastType;
    private ChordType actualType;
    private String lastBass;
    private String actualBass;

    private ChordValidity lastResult;

    private String lastSearch = "";
    private List<String> searched = new ArrayList<String>();

    //actual column
    private int column = 1;

    private HarmonyOwnExercise previousFrame;
    private HarmonyOwnExercise nextFrame;
    private int numberOfFrame;
    private static List<HarmonyOwnExercise> frames = new ArrayList<HarmonyOwnExercise>();

    private WindowListener listenerWithoutConfirmation = new MyWindowListenerWithoutConfirmation();
    private WindowListener listenerWithConfirmation = new MyWindowListenerWithConfirmation();


    private String getDefaultExercise(){
        return keys.getKey(0).getInfo();
    }
    
    /** Sets console colour to green*/
    private void green(){
        communication.setForeground(Color.getHSBColor((float)0.29, (float)0.6, (float)0.5));
    }

    /** Sets console colour to red*/
    private void red(){
        communication.setForeground(Color.getHSBColor((float)0, (float)0.6, (float)0.5));
    }

    private String incorrectFormat(){
        return (java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString(". TÓN JE ZADANÝ V NESPRÁVNOM FORMÁTE.")+"\n"
                    + inputToneFormat());
    }

    private String inputToneFormat(){
        return java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE MOŽNÉ ZADÁVAŤ TÓNY OD")+" "+java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("C,,")+" "+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage()
                    + "/" + this.getClass().getSimpleName()).getString("DO")+" "+java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("c,,,,,")+"  "+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("DVE ČIARKY JE VŽDY MOŽNÉ NAHRADIŤ BODKOU.")+"\n"
                    + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PRÍKLAD SPRÁVNE ZADANÝCH TÓNOV:")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES,,")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES,")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("ES")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,,")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,,,")+"  "
                    +java.util.ResourceBundle.getBundle("harmony/resources/Tones"+Translation.getToneSystemString()).getString("es,,,,");
    }

    private String wrongChord(){
        return (java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("DRUH AKORDU NIE JE ZADANÝ ALEBO JE ZADANÝ V NESPRÁVNOM FORMÁTE.")+"\n"
                    + inputChordFormat());
    }

    private String inputChordFormat(){
        return (java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("JE MOŽNÉ ZADAŤ NASLEDOVNÉ DRUHY: 5  #  5#  6  64  53  6#4  7  65  43  2  8"));
    }

    private String wrongChordInThreeTones(){
        return (java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("DRUH AKORDU NIE JE ZADANÝ ALEBO JE ZADANÝ V NESPRÁVNOM FORMÁTE.")+"\n"
                    + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NACHÁDZATE SA V REŽIME TROJHLASU. TU JE MOŽNÉ BEŽNE ZADAŤ KVINTAKORDY, TEDA: 5  #  5#  6  64  53  6#4")+"\n"
                    + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("OKREM TOHO JE TU MOŽNÉ ZADAŤ SEPTAKORDY S JEDNÝM VYNECHANÝM TÓNOM, TEDA: 7  65  43  2  8"));
    }

    private String shortcuts(){
        return (java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("KLÁVESA ENTER SLÚŽI AKO TLAČÍTKO \"OVERIŤ\", ŠÍPKA DOPRAVA JE \"NASLEDUJÚCI AKORD\", ŠÍPKA DOĽAVA \"PREDCHÁDZAJÚCI AKORD\".")+"\n"
                + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TIETO SKRATKY VŠAK Z PODSTATY VECI NEFUNGUJÚ VŽDY, LEBO NAPRÍKLAD AK BLIKÁ KURZOR TEXTOVEJ EDITÁCIE V NEJAKOM OKIENKU, ŠÍPKY PLNIA INÚ ÚLOHU."));
    }

    AbstractAction pressCheckButton = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
            if(checkButton.isEnabled()){
                checkButtonActionPerformed(e);
            }
        }
    };

    AbstractAction pressNextButton = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
            if(nextButton.isEnabled()){
                nextButtonActionPerformed(e);
            }
        }
    };

    AbstractAction pressPreviousButton = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
            if(previousButton.isEnabled()){
                previousButtonActionPerformed(e);
            }
        }
    };

    AbstractAction pressToneOmitButton = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
            if(toneOmitButton.isVisible()){
                toneOmitButtonActionPerformed(e);
            }
        }
    };

    AbstractAction pressErrorOmitButton = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
            if(errorOmitButton.isVisible()){
                errorOmitButtonActionPerformed(e);
            }
        }
    };

    AbstractAction pressChromaticsButton = new AbstractAction() {
    public void actionPerformed(ActionEvent e) {
            if(chromaticsButton.isEnabled()){
                chromaticsButtonActionPerformed(e);
            }
        }
    };

    public HarmonyOwnExercise showNewFrame(){
        if(Arrays.asList(this.getFrame().getWindowListeners()).contains(listenerWithoutConfirmation)){
            this.getFrame().removeWindowListener(listenerWithoutConfirmation);
            this.getFrame().addWindowListener(listenerWithConfirmation);
            this.getFrame().setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        }
        nextFrame = superFrame.showOwnExercise(key, threeVoices, this, numberOfFrame+1);
        return nextFrame;
    }
    
    public HarmonyOwnExercise getFirstFrame(){
        if(previousFrame==null){
            return this;
        }
        HarmonyOwnExercise result = this;
        HarmonyOwnExercise previous = this;
        while(previous!=null){
            result = previous;
            previous = previous.getPreviousFrame();
        }
        return result;
    }

    public HarmonyOwnExercise getLastFrame(){
        if(nextFrame==null){
            return this;
        }
        HarmonyOwnExercise result = this;
        HarmonyOwnExercise next = this;
        while(next!=null){
            result = next;
            next = next.getNextFrame();
        }
        return result;
    }

    public boolean hasNextFrame(){
        if(nextFrame==null){
            return false;
        }else{
            return true;
        }
    }

     public boolean hasPreviousFrame(){
        if(previousFrame==null){
            return false;
        }else{
            return true;
        }
    }

    public HarmonyOwnExercise getNextFrame(){
        return nextFrame;
    }

    public HarmonyOwnExercise getPreviousFrame(){
        return previousFrame;
    }

    private List<String> getChordTones(){
        List<String> result = new ArrayList<String>();
        for(int i=1; i<=30; i++){
            result.add(tones[i*5-4].getText());
            result.add(tones[i*5-3].getText());
            result.add(tones[i*5-2].getText());
            result.add(tones[i*5-1].getText());
        }
        return result;
    }

    public boolean search(String tone1, String tone2, String tone3, String tone4, List<String> searched){
        Object[] search = searched.toArray();
        int count = 0;
        for(int i=0; i<search.length; i++){
            if(((String)search[i]).equals(tone1+" "+tone2+" "+tone3+" "+tone4)){
                count++;
            }
        }

        List<String> chordTones = new ArrayList<String>();
        for(HarmonyOwnExercise frame : frames){
            chordTones.clear();
            chordTones.addAll(frame.getChordTones());
            for(int i=0 ; i<=chordTones.size()-4 ; i=i+4){
                if(chordTones.get(i).equals(tone1) && chordTones.get(i+1).equals(tone2) &&
                        chordTones.get(i+2).equals(tone3) && chordTones.get(i+3).equals(tone4)){
                    if(count==0){
                        deactivateAllFrames();
                        frame.activateFrame();
                        frame.getFrame().toFront();
                        frame.tones[i+1+(i/4)].setEditable(true);
                        frame.tones[i+2+(i/4)].setEditable(true);
                        frame.tones[i+3+(i/4)].setEditable(true);
                        if(!threeVoices){
                            frame.tones[i+4+(i/4)].setEditable(true);
                        }
                        frame.tones[i+5+(i/4)].setEditable(true);
                        frame.column = (i+4)/4;
                        frame.green();
                        frame.communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ÚSPEŠNE NÁJDENÉ."));
                        return true;
                    }else{
                        count--;
                    }
                }
            }
        }
        return false;
    }

    public void deactivateAllBoxes(){
        for(HarmonyOwnExercise frame : frames){
            for(int i=1; i<=150; i++){
                frame.tones[i].setEditable(false);
            }
        }
    }

    public boolean isActive(){
        for(int i=1; i<=150; i++){
            if (tones[i].isEditable()){
                return true;
            }
        }
        return false;
    }

    public void eraseBoxes(){
        for(int i=1; i<=150; i++){
            tones[i].setText("");
        }
    }

    public boolean isEmpty(){
        for(int i=1; i<=150; i++){
            if (!tones[i].getText().equals("")){
                return false;
            }
        }
        return true;
    }

    private void eraseCurrentChord(){
        tones[column*5-4].setText("");
        tones[column*5-3].setText("");
        tones[column*5-2].setText("");
        tones[column*5-1].setText("");
        tones[column*5].setText("");
    }

    private void activateCurrentChord(){
        tones[column*5-4].setEditable(true);
        tones[column*5-3].setEditable(true);
        tones[column*5-2].setEditable(true);
        if(!threeVoices){
            tones[column*5-1].setEditable(true);
        }
        tones[column*5].setEditable(true);
        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MÔŽETE ZADAŤ AKORD."));
    }

    public void activateFrame(){
        activateCheckMenu();
        loadExercise.setEnabled(true);
        saveExercise.setEnabled(true);
        insertChord.setEnabled(true);
        deleteChord.setEnabled(true);
        eraseFromCurrent.setEnabled(true);
        eraseAllFromCurrent.setEnabled(true);
        searchChord.setEnabled(true);
        analyseChord.setEnabled(true);
        threeVoiceMode.setEnabled(true);
        checkButton.setEnabled(true);
        nextButton.setEnabled(true);
        if(column!=1 || !(previousFrame==null)){
            previousButton.setEnabled(true);
        }
        chromaticsButton.setEnabled(true);
        countButton.setEnabled(true);
        keyChoice.setEnabled(true);
        this.getFrame().requestFocusInWindow();
   }

    private void activateCheckMenu(){
        checkMenu.setEnabled(true);
        otherChord.setSelected(!OmitErrors.Global.otherChord());
        omitTone.setSelected(!OmitErrors.Global.omitTone());
        toneCrossing.setSelected(!OmitErrors.Global.toneCrossing());
        notAWideHarmony.setSelected(!OmitErrors.Global.notAWideHarmony());
        leadingToneDoubled.setSelected(!OmitErrors.Global.leadingToneDoubled());
        leadingToneNotResolved.setSelected(!OmitErrors.Global.leadingToneNotResolved());
        notCantabile.setSelected(!OmitErrors.Global.notCantabile());
        parallelEights.setSelected(!OmitErrors.Global.parallelEights());
        parallelFifths.setSelected(!OmitErrors.Global.parallelFifths());
    }
    
    public void activateFirstChord(){
        tones[1].setEditable(true);
        tones[2].setEditable(true);
        tones[3].setEditable(true);
        if(!threeVoices){
            tones[4].setEditable(true);
        }
        tones[5].setEditable(true);
        column = 1;
        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MÔŽETE ZADAŤ AKORD."));
    }

    public void activateLastChord(){
        tones[146].setEditable(true);
        tones[147].setEditable(true);
        tones[148].setEditable(true);
        if(!threeVoices){
            tones[149].setEditable(true);
        }
        tones[150].setEditable(true);
        column = 30;
        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TERAZ MÔŽETE OPRAVIŤ ALEBO UPRAVIŤ NIEKTORÝ ZO SKORŠÍCH AKORDOV."));
    }

    public void deactivateFrame(){
        checkMenu.setEnabled(false);
        loadExercise.setEnabled(false);
        saveExercise.setEnabled(false);
        insertChord.setEnabled(false);
        deleteChord.setEnabled(false);
        eraseFromCurrent.setEnabled(true);
        eraseAllFromCurrent.setEnabled(false);
        searchChord.setEnabled(true);
        analyseChord.setEnabled(false);
        threeVoiceMode.setEnabled(false);
        checkButton.setEnabled(false);
        nextButton.setEnabled(false);
        previousButton.setEnabled(false);
        chromaticsButton.setEnabled(false);
        countButton.setEnabled(false);
        keyChoice.setEnabled(false);
        toneOmitButton.setVisible(false);
        errorOmitButton.setVisible(false);
        for(int i=1; i<=150; i++){
            tones[i].setEditable(false);
        }
        junctor0.setText("");
        junctor1.setText("");
        green();
        communication.setText(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("TOTO OKNO NIE JE AKTÍVNE."));
    }

    public void deactivateAllFrames(){
        for(HarmonyOwnExercise frame : frames){
            frame.deactivateFrame();
        }
    }

    public void closeAllNextFrames(){
        HarmonyOwnExercise current = this;
        while(current.hasNextFrame()){
            current.getNextFrame().getFrame().dispose();
            current = current.getNextFrame();
        }
        while(frames.size()>frames.indexOf(this)+1){
            frames.remove(frames.size()-1);
        }
        nextFrame=null;
        if(!hasPreviousFrame()){
            this.getFrame().removeWindowListener(listenerWithConfirmation);
            this.getFrame().addWindowListener(listenerWithoutConfirmation);
        }
    }

    public void closeAllFrames(){
        HarmonyOwnExercise current = getFirstFrame();
        while(current.hasNextFrame()){
            current.getNextFrame().getFrame().dispose();
            current = current.getNextFrame();
        }
    }

    public static Map<String, String> getTranscodingMap(Translation.ToneSystem from, Translation.ToneSystem to){
        ResourceBundle rbFrom = java.util.ResourceBundle.getBundle("harmony/resources/Tones"+from.getToneSystemString());
        ResourceBundle rbTo = java.util.ResourceBundle.getBundle("harmony/resources/Tones"+to.getToneSystemString());
        List<String> valuesFrom = new ArrayList<String>();
        for(String key : rbFrom.keySet()){
            valuesFrom.add(rbFrom.getString(key));
        }
        List<String> valuesTo = new ArrayList<String>();
        for(String key : rbTo.keySet()){
            valuesTo.add(rbTo.getString(key));
        }
        Map<String, String> result = new HashMap<String, String>();
        int i = 0;
        for(String value : valuesFrom){
            result.put(value, valuesTo.get(i));
            i++;
        }
        return result;
    }

    public static String transcode(String what, Map<String, String> transcodingMap){
        String result = transcodingMap.get(what);
        return result==null ? what : result;
    }


    /** This method deos not check correctness of inputted chord type.*/
    private boolean areActualTonesCorrect(){
        Integer tone4;
        if(threeVoices){ //in three voice mode fourth tone will be identical with third tone, and fourth tone will be erased
            tone4 = Tones.getTone(tones[column*5-2].getText());
            actualBass = tones[column*5-2].getText().toString();
            tones[column*5-1].setText("");
        }else{
            tone4 = Tones.getTone(tones[column*5-1].getText());
            actualBass = tones[column*5-1].getText().toString();
        }

        Chord chord = new Chord(Tones.getTone(tones[column*5-4].getText()),Tones.getTone(tones[column*5-3].getText()),
                Tones.getTone(tones[column*5-2].getText()), tone4);

        actualType = ChordType.getType(tones[column*5].getText());
        if(ChordType.containsOmit(tones[column*5].getText())){ //if there is "o" at end of chord mark
            omit.allowToneOmission();
        }

        if(chord.areTonesCorrect()!=0){ //then some tone is inputted incorrectly
            red();
            communication.setText(chord.areTonesCorrect()+ incorrectFormat());
            nextButton.setEnabled(false);
            return false;
        }else{
            return true;
        }
    }

    private void analyseChord(){
        SortedSet<MyInteger> intervalsBetweenTones = new TreeSet<MyInteger>();
        Integer tone;
        int i;
        if(threeVoices){
            i = 2;
        }else{
            i = 1;
        }
        int baseTone = Tones.getTone(tones[column*5-i].getText());
        for(; i <= 4; i++){
            tone = Tones.getTone(tones[column*5-i].getText());

            intervalsBetweenTones.add(new MyInteger(tone, tones[column*5-i].getText(), baseTone));
        }

        communication.append(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("INTERVALY MEDZI TÓNMI AKORDU:") + " ");

        Iterator<MyInteger> it = intervalsBetweenTones.iterator();
        MyInteger current;
        MyInteger next;
        List<Integer> intervals = new ArrayList<Integer>();
        int interval;
        if(!intervalsBetweenTones.isEmpty()){
            current = it.next();
            communication.append(current.getOriginalTone());
            while(it.hasNext()){
                next = it.next();
                communication.append(" - ");
                interval = Math.abs(Key.getRelativeTonePosition(current.getValue(), baseTone)-Key.getRelativeTonePosition(next.getValue(), baseTone));
                intervals.add(interval);
                communication.append(String.valueOf(interval) + " - " + next.getOriginalTone());
                current = next;
            }
        }

        communication.append(" ");
        if(intervals.size()==2 && intervals.get(0)==4 && intervals.get(1)==3){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("DUROVÝ KVINTAKORD")+")");
        }else if(intervals.size()==2 && intervals.get(0)==3 && intervals.get(1)==4){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MOLLOVÝ KVINTAKORD")+")");
        }else if(intervals.size()==2 && intervals.get(0)==3 && intervals.get(1)==5){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("DUROVÝ SEXTAKORD")+")");
        }else if(intervals.size()==2 && intervals.get(0)==4 && intervals.get(1)==5){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MOLLOVÝ SEXTAKORD")+")");
        }else if(intervals.size()==2 && intervals.get(0)==5 && intervals.get(1)==4){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("DUROVÝ KVARTSEXTAKORD")+")");
        }else if(intervals.size()==2 && intervals.get(0)==5 && intervals.get(1)==3){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MOLLOVÝ KVARTSEXTAKORD")+")");
        }else if(intervals.size()==2 && intervals.get(0)==4 && intervals.get(1)==4){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZVÄČŠENÝ KVINTAKORD")+")");
        }else if(intervals.size()==2 && intervals.get(0)==3 && intervals.get(1)==3){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZMENŠENÝ KVINTAKORD")+")");
        }else if(intervals.size()==3 && intervals.get(0)==4 && intervals.get(1)==3 && intervals.get(2)==4){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VEĽKÝ DUROVÝ SEPTAKORD")+")");
        }else if(intervals.size()==3 && intervals.get(0)==4 && intervals.get(1)==3 && intervals.get(2)==3){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MALÝ DUROVÝ (DOMINANTNÝ) SEPTAKORD")+")");
        }else if(intervals.size()==3 && intervals.get(0)==3 && intervals.get(1)==4 && intervals.get(2)==4){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VEĽKÝ MOLLOVÝ SEPTAKORD")+")");
        }else if(intervals.size()==3 && intervals.get(0)==3 && intervals.get(1)==4 && intervals.get(2)==3){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MALÝ MOLLOVÝ SEPTAKORD")+")");
        }else if(intervals.size()==3 && intervals.get(0)==3 && intervals.get(1)==3 && intervals.get(2)==4){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("MALÝ ZMENŠENÝ SEPTAKORD")+")");
        }else if(intervals.size()==3 && intervals.get(0)==3 && intervals.get(1)==3 && intervals.get(2)==3){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZMENŠENÝ SEPTAKORD")+")");
        }else if(intervals.size()==3 && intervals.get(0)==4 && intervals.get(1)==4 && intervals.get(2)==3){
            communication.append("("+java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZVÄČŠENÝ SEPTAKORD")+")");
        }
    }




    private static class MyInteger implements Comparable<MyInteger>{
        private int value;
        private int baseTone;
        private String originalTone = null;

        private MyInteger(){
        }

        public MyInteger(int value, String originalTone){
            this.value = value;
            this.originalTone = originalTone;
        }

        public MyInteger(int value, String originalTone, int baseTone){
            this.value = value;
            this.originalTone = originalTone;
            this.baseTone = baseTone;
        }

        public int getValue(){
            return value;
        }

        public String getOriginalTone(){
            return originalTone;
        }

        public int getBaseTone(){
            return baseTone;
        }

        public void setOriginalTone(String originalTone){
            this.originalTone = originalTone;
        }

        @Override
        public String toString(){
            return String.valueOf(value);
        }

        @Override
        public int compareTo(MyInteger myInt){
            return Key.getRelativeTonePosition(getValue(), getBaseTone()) - Key.getRelativeTonePosition(myInt.getValue(), myInt.getBaseTone());
        }
    }

}
