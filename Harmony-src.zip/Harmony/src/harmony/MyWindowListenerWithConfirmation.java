/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JOptionPane;

/**
 *
 * @author Dominik Kruppa
 */
public class MyWindowListenerWithConfirmation implements WindowListener {

  public void windowClosing(WindowEvent arg0) {

      if(JOptionPane.showConfirmDialog(arg0.getComponent(),
                        "Zatvorenie tohto okna ukončí celý program. Prajete si toto?", "Potvrdiť ukončenie programu", 0) == 0){
                    System.exit(0);
      }
  }

  public void windowOpened(WindowEvent arg0) {
  }

  public void windowClosed(WindowEvent arg0) {
  }

  public void windowIconified(WindowEvent arg0) {
  }

  public void windowDeiconified(WindowEvent arg0) {
  }

  public void windowActivated(WindowEvent arg0) {
  }

  public void windowDeactivated(WindowEvent arg0) {
  }

}
