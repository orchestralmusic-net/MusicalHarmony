/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public enum DurMoll {

    DUR, MOLL, DIMINISHED;

    @Override
    public String toString(){

        switch (this){

            case DUR: return "Dur";
            case MOLL: return "Moll";
            case DIMINISHED: return "Diminished";

        }

        return "interná chyba programu 5";

    }

}
