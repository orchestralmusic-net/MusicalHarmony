/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package harmony;

/**
 *
 * @author Dominik Kruppa
 */
public class Chord {

    /** Natural number from 0 to 96 representing pitch of note, where 0 is C,, and 96 is c'''''*/
    private Integer tone1;
    /** Natural number from 0 to 96 representing pitch of note, where 0 is C,, and 96 is c'''''*/
    private Integer tone2;
    /** Natural number from 0 to 96 representing pitch of note, where 0 is C,, and 96 is c'''''*/
    private Integer tone3;
    /** Natural number from 0 to 96 representing pitch of note, where 0 is C,, and 96 is c'''''*/
    private Integer tone4;
    
    public Chord(Integer tone1, Integer tone2, Integer tone3, Integer tone4){
        this.tone1 = tone1;
        this.tone2 = tone2;
        this.tone3 = tone3;
        this.tone4 = tone4;
    }

    /** Call this on the first chord in the exercise to check whether is correct.*/
    public ChordValidity validateFirstChord(ChordType type, Key key, OmitErrors omit, boolean threeVoices) throws GroundNotSupportedException{

        if ((!omit.otherChord() && otherChord(type, key, omit, threeVoices)) ||
                (!omit.omitTone() && otherChord(type, key, omit, threeVoices) && ChordValidity.OTHERCHORD.getInfo().equals(getOmissionMessage()))) // tone omission should be returned also if there is otherChord omit active, but not omitTone omit
                        {return ChordValidity.OTHERCHORD;}
        else if(!omit.toneCrossing() && toneCrossing()) {return ChordValidity.TONECROSSING;}
        else if(!omit.notAWideHarmony() && notAWideHarmony(threeVoices)) {return ChordValidity.NOTAWIDEHARMONY;}
        else if(!omit.leadingToneDoubled() && leadingToneDoubled(key, threeVoices)) {return ChordValidity.LEADINGTONEDOUBLED;}
        else {return ChordValidity.VALID;}

    }

    /** Call this on chord and give it its preceeding chord to check whether is correct.*/
    public ChordValidity validateChord(Chord previousChord, ChordType type, Key key, OmitErrors omit, boolean threeVoices) throws GroundNotSupportedException{

        if ((!omit.otherChord() && otherChord(type, key, omit, threeVoices)) ||
                (!omit.omitTone() && otherChord(type, key, omit, threeVoices) && ChordValidity.OTHERCHORD.getInfo().equals(getOmissionMessage()))) // tone omission should be returned also if there is otherChord omit active, but not omitTone omit
                        {return ChordValidity.OTHERCHORD;}
        else if(!omit.toneCrossing() && toneCrossing()) {return ChordValidity.TONECROSSING;}
        else if(!omit.notAWideHarmony() && notAWideHarmony(threeVoices)) {return ChordValidity.NOTAWIDEHARMONY;}
        else if(!omit.leadingToneDoubled() && leadingToneDoubled(key, threeVoices)) {return ChordValidity.LEADINGTONEDOUBLED;}
        else if(!omit.leadingToneNotResolved() && leadingToneNotResolved(previousChord, key)) {return ChordValidity.LEADINGTONENOTRESOLVED;}
        else if(!omit.notCantabile() && notCantabile(previousChord, key)) {return ChordValidity.NOTCANTABILE;}
        else if(!omit.parallelEights() && parallelEights(previousChord)) {return ChordValidity.PARALLELEIGHTS;}
        else if(!omit.parallelFifths() && parallelFifths(previousChord)) {return ChordValidity.PARALLELFIFTHS;}
        else {return ChordValidity.VALID;}

    }


    private boolean otherChord(ChordType type, Key key, OmitErrors omit, boolean threeVoices) throws GroundNotSupportedException{

        if(type.isChromatic()){
            return false;
        }

        int c1 = 1; //counter of a musical lowest tone in a chord
        int c2 = 0; //counter of a musical second lowest tone in a chord
        int c3 = 0; //counter of a musical third lowest tone in a chord
        int c4 = 0; //counter of a musical fourth lowest tone in a chord

        Integer[] p = type.getChordParameters(key, getTone4());

        if (p[3] == -1){ //its triad
            if ((getTone1()+48 - getTone4()) % 12 == 0){
                c1++;
            }
            else if((getTone1()+48 - getTone4()) % 12 == p[1])
            {
                c2++;
            }
            else if((getTone1()+48 - getTone4()) % 12 == p[2])
            {
                c3++;
            }else{ //tone1 is incorrect
                ChordValidity.OTHERCHORD.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("1. TÓN NEPATRÍ DO AKORDU.")
                        + "\n" + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NEZABUDNITE, V AKEJ SA NACHÁDZATE TÓNINE, A TIEŽ SI VŠIMNITE DRUH AKORDU."));
                return true;
            }
            if ((getTone2()+48 - getTone4()) % 12 == 0){
                c1++;
            }
            else if((getTone2()+48 - getTone4()) % 12 == p[1])
            {
                c2++;
            }
            else if((getTone2()+48 - getTone4()) % 12 == p[2])
            {
                c3++;
            }else{ //tone2 is incorrect
                ChordValidity.OTHERCHORD.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("2. TÓN NEPATRÍ DO AKORDU.")
                        + "\n" + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NEZABUDNITE, V AKEJ SA NACHÁDZATE TÓNINE, A TIEŽ SI VŠIMNITE DRUH AKORDU."));
                return true;
            }
            if ((getTone3()+48 - getTone4()) % 12 == 0){
                c1++;
            }
            else if((getTone3()+48 - getTone4()) % 12 == p[1])
            {
                c2++;
            }
            else if((getTone3()+48 - getTone4()) % 12 == p[2])
            {
                c3++;
            }else{ //tone3 is incorrect
                ChordValidity.OTHERCHORD.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("3. TÓN NEPATRÍ DO AKORDU.")
                        + "\n" + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NEZABUDNITE, V AKEJ SA NACHÁDZATE TÓNINE, A TIEŽ SI VŠIMNITE DRUH AKORDU."));
                return true;
            }
            if( (c1==1||c1==2) && (c2==1||c2==2) && (c3==1||c3==2) ){
                return false;
            }else{ //some requied tone is missing in a chord
                if(!omit.omitTone()){
                    ChordValidity.OTHERCHORD.setErrMessage(getOmissionMessage());
                    return true;
                }else{
                    return false;
                }
            }

        }else{//its seventh chord
            if ((getTone1()+48 - getTone4()) % 12 == p[1]){
                c2++;
            }
            else if((getTone1()+48 - getTone4()) % 12 == p[2])
            {
                c3++;
            }
            else if((getTone1()+48 - getTone4()) % 12 == p[3])
            {
                c4++;
            }else{ //tone1 is incorrect
                ChordValidity.OTHERCHORD.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("1. TÓN NEPATRÍ DO SEPTAKORDU.")
                        + "\n" + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NEZABUDNITE, V AKEJ SA NACHÁDZATE TÓNINE, A TIEŽ SI VŠIMNITE DRUH AKORDU."));
                return true;
            }
            if ((getTone2()+48 - getTone4()) % 12 == p[1]){
                c2++;
            }
            else if((getTone2()+48 - getTone4()) % 12 == p[2])
            {
                c3++;
            }
            else if((getTone2()+48 - getTone4()) % 12 == p[3])
            {
                c4++;
            }else{ //tone2 is incorrect
                ChordValidity.OTHERCHORD.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("2. TÓN NEPATRÍ DO SEPTAKORDU.")
                        + "\n" + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NEZABUDNITE, V AKEJ SA NACHÁDZATE TÓNINE, A TIEŽ SI VŠIMNITE DRUH AKORDU."));
                return true;
            }
            if ((getTone3()+48 - getTone4()) % 12 == p[1]){
                c2++;
            }
            else if((getTone3()+48 - getTone4()) % 12 == p[2])
            {
                c3++;
            }
            else if((getTone3()+48 - getTone4()) % 12 == p[3])
            {
                c4++;
            }else{ //tone3 is incorrect
                if(!threeVoices){
                    ChordValidity.OTHERCHORD.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("3. TÓN NEPATRÍ DO SEPTAKORDU.")
                        + "\n" + java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NEZABUDNITE, V AKEJ SA NACHÁDZATE TÓNINE, A TIEŽ SI VŠIMNITE DRUH AKORDU."));
                    return true;
                }
            }
            if(c2==1 && c3==1 && c4==1){
                return false;
            }else if (threeVoices && ((c2 == 1 && c3 == 1) || (c2 == 1 && c4 == 1) || (c3 == 1 && c4 == 1)) ){
                return false;
            }else{ //some requied tone is missing in a chord
                if(!omit.omitTone()){
                    ChordValidity.OTHERCHORD.setErrMessage(getOmissionMessage());
                    return true;
                }else{
                    return false;
                }
            }
        }

    }


    private boolean toneCrossing() {

        if (getTone1()<getTone2()){
            ChordValidity.TONECROSSING.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("1. TÓN JE POD 2. TÓNOM."));
            return true;
        }else if (getTone1()<getTone3()){
            ChordValidity.TONECROSSING.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("1. TÓN JE POD 3. TÓNOM."));
            return true;
        }else if (getTone1()<getTone4()){
            ChordValidity.TONECROSSING.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("1. TÓN JE POD 4. TÓNOM."));
            return true;
        }else if (getTone2()<getTone3()){
            ChordValidity.TONECROSSING.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("2. TÓN JE POD 3. TÓNOM."));
            return true;
        }else if (getTone2()<getTone4()){
            ChordValidity.TONECROSSING.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("2. TÓN JE POD 4. TÓNOM."));
            return true;
        }else if (getTone3()<getTone4()){
            ChordValidity.TONECROSSING.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("3. TÓN JE POD 4. TÓNOM."));
            return true;
        }else{
            return false;
        }
    }

    private boolean notAWideHarmony(boolean threeVoices) {

        if (!threeVoices){
            if (getTone3() - getTone4() > 19){
                ChordValidity.NOTAWIDEHARMONY.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VZDIALENOSŤ MEDZI 3. A 4. TÓNOM JE VÄČŠIA AKO OKTÁVA + KVINTA."));
                return true;
            }else if (getTone2() - getTone3() > 12){
                ChordValidity.NOTAWIDEHARMONY.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VZDIALENOSŤ MEDZI 2. A 3. TÓNOM JE VÄČŠIA AKO OKTÁVA."));
                return true;
            }else if (getTone1() - getTone2() > 12){
                ChordValidity.NOTAWIDEHARMONY.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VZDIALENOSŤ MEDZI 1. A 2. TÓNOM JE VÄČŠIA AKO OKTÁVA."));
                return true;
            }else{
                return false;
            }
        }else{
            if (getTone2() - getTone3() > 19){
                ChordValidity.NOTAWIDEHARMONY.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VZDIALENOSŤ MEDZI 2. A 3. TÓNOM JE VÄČŠIA AKO OKTÁVA + KVINTA."));
                return true;
            }else if (getTone1() - getTone2() > 12){
                ChordValidity.NOTAWIDEHARMONY.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("VZDIALENOSŤ MEDZI 1. A 2. TÓNOM JE VÄČŠIA AKO OKTÁVA."));
                return true;
            }else{
                return false;
            }
        }
    }


    private boolean leadingToneDoubled(Key key, boolean threeVoices) {

        //leading tone cannot be doubled in only three voice harmony
        if(threeVoices){
            return false;
        }

        int counter = 0;

        if((tone1+48)%12==key.getLeadingTone()){
            counter++;
        }
        if((tone2+48)%12==key.getLeadingTone()){
            counter++;
        }
        if((tone3+48)%12==key.getLeadingTone()){
            counter++;
        }
        if((tone4+48)%12==key.getLeadingTone()){
            counter++;
        }

        if(counter>1){
            ChordValidity.LEADINGTONEDOUBLED.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("ZDVOJENÝ CITLIVÝ TÓN."));
            return true;
        }else{
            return false;
        }
    }


    private boolean leadingToneNotResolved(Chord previousChord, Key key) {

        int voice; //voice, which contains the leading tone; could be only one
        int tone; //tone, in which is leading tone actually resolving

        if(previousChord.contains(key.getLeadingTone())){
            voice = previousChord.getVoice(key.getLeadingTone());
            tone = getTone(voice);
            if(key.getTonePosition(tone) != 0){
                ChordValidity.LEADINGTONENOTRESOLVED.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("CITLIVÝ TÓN NIE JE ROZVEDENÝ DO TÓNIKY."));
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }

    }


    private boolean notCantabile(Chord previousChord, Key key) {

        if(Math.abs(tone1-previousChord.getTone1()) == 6){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 1. TÓNE, A TO TRITONUS."));
            return true;
        }else if(Math.abs(tone1-previousChord.getTone1()) == 3 && key.isDurOrMoll()==DurMoll.MOLL &&
                (key.isChromatic(tone1) || key.isChromatic(previousChord.getTone1()))){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 1. TÓNE, A TO ZVÄČŠENÁ SEKUNDA."));
            return true;
        }else if(tone1-previousChord.getTone1() > 12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("1. TÓN STÚPOL O VIAC NEŽ OKTÁVU."));
            return true;
        }else if(tone1-previousChord.getTone1() < -12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("1. TÓN KLESOL O VIAC NEŽ OKTÁVU."));
            return true;
        }else  if(Math.abs(tone2-previousChord.getTone2()) == 6){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 2. TÓNE, A TO TRITONUS."));
            return true;
        }else if(Math.abs(tone2-previousChord.getTone2()) == 3 && key.isDurOrMoll()==DurMoll.MOLL
                && (key.isChromatic(tone2) || key.isChromatic(previousChord.getTone2()))){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 2. TÓNE, A TO ZVÄČŠENÁ SEKUNDA."));
            return true;
        }else if(tone2-previousChord.getTone2() > 12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("2. TÓN STÚPOL O VIAC NEŽ OKTÁVU."));
            return true;
        }else if(tone2-previousChord.getTone2() < -12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("2. TÓN KLESOL O VIAC NEŽ OKTÁVU."));
            return true;
         }else  if(Math.abs(tone3-previousChord.getTone3()) == 6){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 3. TÓNE, A TO TRITONUS."));
            return true;
        }else if(Math.abs(tone3-previousChord.getTone3()) == 3 && key.isDurOrMoll()==DurMoll.MOLL
                && (key.isChromatic(tone3) || key.isChromatic(previousChord.getTone3()))){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 3. TÓNE, A TO ZVÄČŠENÁ SEKUNDA."));
            return true;
        }else if(tone3-previousChord.getTone3() > 12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("3. TÓN STÚPOL O VIAC NEŽ OKTÁVU."));
            return true;
        }else if(tone3-previousChord.getTone3() < -12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("3. TÓN KLESOL O VIAC NEŽ OKTÁVU."));
            return true;
             }else  if(Math.abs(tone4-previousChord.getTone4()) == 6){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 4. TÓNE, A TO TRITONUS."));
            return true;
        }else if(Math.abs(tone4-previousChord.getTone4()) == 3 && key.isDurOrMoll()==DurMoll.MOLL
                && (key.isChromatic(tone4) || key.isChromatic(previousChord.getTone4()))){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("NESPEVNÝ KROK NA 4. TÓNE, A TO ZVÄČŠENÁ SEKUNDA."));
            return true;
        }else if(tone4-previousChord.getTone4() > 12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("4. TÓN STÚPOL O VIAC NEŽ OKTÁVU."));
            return true;
        }else if(tone4-previousChord.getTone4() < -12){
            ChordValidity.NOTCANTABILE.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("4. TÓN KLESOL O VIAC NEŽ OKTÁVU."));
            return true;
        }else{
            return false;
        }

    }


    private boolean parallelEights(Chord previousChord) {

        if(getTone1()!=tone1 && previousChord.getTone1()-previousChord.getTone2()==12 && tone1-tone2==12){
            ChordValidity.PARALLELEIGHTS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ OKTÁVY MEDZI 1. A 2. TÓNOM."));
            return true;
        }else if(getTone1()!=tone1 && previousChord.getTone1()-previousChord.getTone3()==12 && tone1-tone3==12){
            ChordValidity.PARALLELEIGHTS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ OKTÁVY MEDZI 1. A 3. TÓNOM."));
            return true;
        }else if(getTone1()!=tone1 && previousChord.getTone1()-previousChord.getTone4()==12 && tone1-tone4==12){
            ChordValidity.PARALLELEIGHTS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ OKTÁVY MEDZI 1. A 4. TÓNOM."));
            return true;
        }else if(getTone2()!=tone2 && previousChord.getTone2()-previousChord.getTone3()==12 && tone2-tone3==12){
            ChordValidity.PARALLELEIGHTS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ OKTÁVY MEDZI 2. A 3. TÓNOM."));
            return true;
        }else if(getTone2()!=tone2 && previousChord.getTone2()-previousChord.getTone4()==12 && tone2-tone4==12){
            ChordValidity.PARALLELEIGHTS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ OKTÁVY MEDZI 2. A 4. TÓNOM."));
            return true;
        }else if(getTone3()!=tone3 && previousChord.getTone3()-previousChord.getTone4()==12 && tone3-tone4==12){
            ChordValidity.PARALLELEIGHTS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ OKTÁVY MEDZI 3. A 4. TÓNOM."));
            return true;
        }else{
            return false;
        }

    }


    private boolean parallelFifths(Chord previousChord) {

         if(getTone1()!=tone1 && previousChord.getTone1()-previousChord.getTone2()==7 && tone1-tone2==7){
            ChordValidity.PARALLELFIFTHS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ KVINTY MEDZI 1. A 2. TÓNOM."));
            return true;
        }else if(getTone1()!=tone1 && previousChord.getTone1()-previousChord.getTone3()==7 && tone1-tone3==7){
            ChordValidity.PARALLELFIFTHS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ KVINTY MEDZI 1. A 3. TÓNOM."));
            return true;
        }else if(getTone1()!=tone1 && previousChord.getTone1()-previousChord.getTone4()==7 && tone1-tone4==7){
            ChordValidity.PARALLELFIFTHS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ KVINTY MEDZI 1. A 4. TÓNOM."));
            return true;
        }else if(getTone2()!=tone2 && previousChord.getTone2()-previousChord.getTone3()==7 && tone2-tone3==7){
            ChordValidity.PARALLELFIFTHS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ KVINTY MEDZI 2. A 3. TÓNOM."));
            return true;
        }else if(getTone2()!=tone2 && previousChord.getTone2()-previousChord.getTone4()==7 && tone2-tone4==7){
            ChordValidity.PARALLELFIFTHS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ KVINTY MEDZI 2. A 4. TÓNOM."));
            return true;
        }else if(getTone3()!=tone3 && previousChord.getTone3()-previousChord.getTone4()==7 && tone3-tone4==7){
            ChordValidity.PARALLELFIFTHS.setErrMessage(java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + this.getClass().getSimpleName()).getString("PARALELNÉ KVINTY MEDZI 3. A 4. TÓNOM."));
            return true;
        }else{
            return false;
        }

    }


    /**Check whether chord contains the tone in any octave*/
    public boolean contains(int tone){

        if(tone<0){ //incorrect input
            return false;
        }

        if(tone1%12 == tone%12){
            return true;
        }else if(tone2%12 == tone%12){
            return true;
        }else if(tone3%12 == tone%12){
            return true;
        }else if(tone4%12 == tone%12){
            return true;
        }else{
            return false;
        }

    }


    /**Returns number of voice (1-4), which contains the tone, or 0 if no one, or -1 if incorrect input*/
    public int getVoice(int tone){

        if(tone<0){ //incorrect input
            return -1;
        }

        if(tone1%12 == tone%12){
            return 1;
        }else if(tone2%12 == tone%12){
            return 2;
        }else if(tone3%12 == tone%12){
            return 3;
        }else if(tone4%12 == tone%12){
            return 4;
        }else{
            return 0;
        }

    }


    /** Checks whether tones after input are correct
        @returns 0 if they are, otherwise number of the first wrong tone*/
    public int areTonesCorrect(){

        if(getTone1()==null){
            return 1;
        }
        if(getTone2()==null){
            return 2;
        }
        if(getTone3()==null){
            return 3;
        }
        if(getTone4()==null){
            return 4;
        }else{
            return 0;
        }

    }

     /**
     * @return selected tone
     */
    public Integer getTone(int number) {

        if(number == 1){
            return tone1;
        }else if(number == 2){
            return tone2;
        }else if(number == 3){
            return tone3;
        }else if(number == 4){
            return tone4;
        }else{
            return null;
        }
    }

    /**
     * @return the first tone of a chord
     */
    public Integer getTone1() {
        return tone1;
    }

    /**
     * @return the second tone of a chord
     */
    public Integer getTone2() {
        return tone2;
    }

    /**
     * @return the third tone of a chord
     */
    public Integer getTone3() {
        return tone3;
    }

    /**
     * @return the fourth tone of a chord
     */
    public Integer getTone4() {
        return tone4;
    }

    /**This string of message will appear, if some tone is missing in chord*/
    public static String getOmissionMessage(){
        return java.util.ResourceBundle.getBundle("harmony/resources/" + Translation.getLanguage() + "/" + Chord.class.getSimpleName()).getString("NIEKTORÝ TÓN V AKORDE CHÝBA. AK STE SI ISTÍ, ŽE TAKÝTO AKORD CHCETE ZADAŤ, MÔŽETE HO POVOLIŤ.");
    }

}
